<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
/* ZarinPal is the only gateway. payment.php (Zibal) has been deleted along with
   its branch through checkout and through payment_callback, so there is one
   code path to keep correct rather than two kept correct in parallel. */
require __DIR__ . '/zarinpal.php';
require __DIR__ . '/includes/geo.php';
/* The postal wrapper needs velora_postal_valid() from geo.php, so it is loaded
   after it rather than beside it. Loading it before would fatal on the
   checksum not existing yet. */
require __DIR__ . '/includes/postal.php';

/* The checkout-integrity helpers (idempotency claims, stock restoration,
   payment log) and the address-book validators were extracted from this file
   into includes/checkout.php and includes/addresses.php — one home per
   concern. They used to live here as well as there, byte-for-byte identical;
   two copies of the same claim machine is exactly the drift that costs an
   afternoon.

   They are required exactly once, from includes/api-handlers.php (loaded at
   the bottom of this file), which is the only code that calls them. api.php
   used to require them here as well, and because both paths use plain
   `require` rather than `require_once`, every request parsed both files
   twice — a duplicate-declaration fatal in strict_types that was avoided
   only by accident of load order. One importer, one require. */

header('Content-Type: application/json; charset=utf-8');
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex, nofollow, noarchive');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-XSS-Protection: 0');

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    $o = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($o !== '' && $o !== APP_ORIGIN) { http_response_code(403); exit; }
    header('Access-Control-Allow-Origin: ' . APP_ORIGIN);
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token, X-Requested-With');
    header('Vary: Origin');
    http_response_code(204);
    exit;
}

/* ═══════════════════════════════════════════════════════════════════════════
   ORIGIN GATE — same-site only. CSRF token remains the primary guarantee.
   ═══════════════════════════════════════════════════════════════════════════ */
$__req_origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$__req_method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($__req_origin !== '' && $__req_method === 'POST') {
    $__proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    if (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') $__proto = 'https';
    $__host_origin = $__proto . '://' . ($_SERVER['HTTP_HOST'] ?? '');

    if ($__req_origin !== APP_ORIGIN && $__req_origin !== $__host_origin) {
        log_action('ORIGIN_DENIED', [
            'sent'         => $__req_origin,
            'expected'     => APP_ORIGIN,
            'host_derived' => $__host_origin,
        ]);
        jresp(['ok' => false, 'error' => 'ORIGIN_DENIED'], 403);
    }
}
unset($__req_origin, $__req_method, $__proto, $__host_origin);

$action = req_str('action');

/* ── Admin IP allow-list ────────────────────────────────────────────────────── */
if ($action !== '' && str_starts_with($action, 'admin_') && !admin_ip_allowed(get_client_ip())) {
    log_action('ADMIN_IP_DENIED', [
        'action' => $action,
        'ip'     => get_client_ip(),
    ]);
    jresp([
        'ok'      => false,
        'error'   => 'ADMIN_IP_DENIED',
        'message' => 'دسترسی از این آی‌پی مجاز نیست',
    ], 403);
}

/* ═══════════════════════════════════════════════════════════════════════════
   NO DATABASE, NO ACTION
   ═══════════════════════════════════════════════════════════════════════════
   config.php no longer ends the request when the connection fails — the
   storefront has to be able to render without one. Every action in the switch
   below does need one, and reaching it with a null handle would fatal into an
   HTML error page, which the client cannot read and reports as a bodyless
   HTTP_500 with no message.

   So the outage is answered once, here, in the same shape the client already
   understands: DB_FAIL with the classified sentence, which is what puts
   "check VELORA_DB_HOST and VELORA_DB_PORT" in the banner instead of a blank
   page. Nothing retries; a retry cannot succeed until someone fixes the
   server.

   VELORA_DB_INDEPENDENT_ACTIONS — the short list of actions that provably touch
   no table, and so stay answerable without a connection — is declared in
   config.php next to the database configuration it qualifies, so the allow-list
   and the thing it is an exception to are read together. geo_regions is the one
   that matters: its data is a literal in includes/geo.php and it is what fills
   the checkout's province picker, so refusing it emptied step two of checkout
   with an error that said "database" rather than anything about addresses.
   me is on it for the same reason in reverse: it is the probe js/auth.js fires
   twice at boot, and for a signed-out visitor it reads $_SESSION alone — gating
   it put two DB_FAIL 500s in the console of a page that was working fine. Its
   signed-in branch does query, and answers DB_FAIL on its own from inside
   includes/api/auth.php. */
/* ── The action is resolved BEFORE the database gate ────────────────────────
   This order was the other way round, and it made both answers wrong.

   The gate ran first, so with the database down EVERY request — including one
   asking for an action that does not exist, or for no action at all — was
   answered DB_FAIL 500. A client with a typo in an action name was told the
   shop's database was unreachable, which is not a thing the client can act on
   and is not a thing that is true: the request was never going to reach a query.

   And the reverse held too. `me` is on VELORA_DB_INDEPENDENT_ACTIONS and
   answered 200 while every action around it returned 500, so a storefront with
   a dead database showed a signed-out session rather than a broken one.

   Resolving first means the two cases answer themselves: an action nobody
   publishes is refused as such whatever the database is doing, and only a real
   handler is allowed to find out whether it has a connection. */
require_once __DIR__ . '/includes/api-handlers.php';

$__handler = velora_api_handler($action);

if ($__handler === null) {
    $diag = [
        'method'         => $_SERVER['REQUEST_METHOD'] ?? '?',
        'content_type'   => $_SERVER['CONTENT_TYPE']   ?? '',
        'content_length' => (int) ($_SERVER['CONTENT_LENGTH'] ?? 0),
        'post_keys'      => array_keys($_POST),
        'json_keys'      => array_keys(req_parse_json()),
        'get_keys'       => array_keys($_GET),
    ];
    log_action($action === '' ? 'NO_ACTION' : 'UNKNOWN_ACTION', $diag + ['action_raw' => $action]);

    /* Two different faults, and they used to arrive as one body.

       `action: ""` means the request reached api.php with no action at all
       — the body never arrived, or it arrived in a shape PHP could not parse
       into $_POST. That is a transport problem: a proxy that stripped it, a
       Content-Type that is not form data, a service worker that replayed the
       request without the body.

       `action: "somethin"` means the client asked for an action that does not
       exist, which is a bug in the caller.

       Reporting both as UNKNOWN_ACTION made the first indistinguishable from the
       second, and the first is the one that costs an afternoon: the log line
       reads "a client sent a typo" when what actually happened is that nothing
       was sent. So the empty case gets its own code and carries the two facts
       that settle it — the Content-Type that arrived, and every key that did
       make it into the request.

       400 for both, and always has been: this is the one branch in api.php
       where the fault is provably the caller's. (401 here would be actively
       wrong — it means credentials were presented and rejected, and nothing
       about a missing action name involves credentials.)

       diag stays behind APP_DEBUG, because it echoes the request's own key
       names back to whoever sent them. */
    $noAction = trim($action) === '';

    $unknown = [
        'ok'     => false,
        'error'  => $noAction ? 'NO_ACTION' : 'UNKNOWN_ACTION',
        'action' => $action,
    ];

    if ($noAction) {
        $unknown['message'] = 'اکشن درخواست مشخص نشده است.';
        $unknown['hint']    = 'no action reached api.php — the body was empty or not form-encoded';
        $unknown['content_type'] = $diag['content_type'];
        $unknown['received_keys'] = array_merge($diag['post_keys'], $diag['json_keys'], $diag['get_keys']);
    }

    if (APP_DEBUG) $unknown['diag'] = $diag;
    jresp($unknown, 400);
}

if (!($pdo instanceof PDO) && !in_array($action, VELORA_DB_INDEPENDENT_ACTIONS, true)) {
    $down = velora_db_down() ?? [
        'error'   => 'DB_FAIL',
        'message' => 'اتصال به پایگاه داده برقرار نشد.',
    ];
    log_action('API_NO_DATABASE', ['action' => $action]);
    jresp(['ok' => false, 'error' => $down['error'], 'message' => $down['message']], 500);
}

try {
    /* The former 2.6k-line switch lives in includes/api/<domain>.php, one
       file per domain, resolved above through an allow-list built from the
       directory itself (includes/api-handlers.php). Handlers run in this same
       global scope; they answer via jresp() (which exits) or return. */
    include $__handler;
} catch (PDOException $e) {
    /* A query that failed is a different animal from a query that was wrong.
       In production the message below was the only thing the customer saw, and
       "خطای سرور" says nothing about whether they should retry, fix their form,
       or fix the server. velora_db_fail_message() classifies without leaking the
       driver's text (it carries the username), and the classification is what
       the customer acts on — chiefly the missing table, which is what a site
       looks like when db.sql was never imported and is indistinguishable from a
       bug in the save otherwise. */
    log_action('API_DB_ERROR', [
        'action' => $action,
        'sqlstate' => (string) $e->getCode(),
        'driver'   => (int) ($e->errorInfo[1] ?? 0),
        'file'   => $e->getFile(),
        'line'   => $e->getLine(),
    ]);
    $missing = $e->errorInfo[1] ?? null;
    $missingTable = ((int) ($missing ?? 0) === 1146)
        || (string) $e->getCode() === '42S02'
        || stripos($e->getMessage(), "doesn't exist") !== false;
    jresp([
        'ok'      => false,
        'error'   => $missingTable ? 'TABLE_MISSING' : 'DB_QUERY_FAIL',
        'message' => velora_db_fail_message($e),
        /* Field the inline form error reads first, so a 500 on the address form
           names the table instead of the generic "نشانی ذخیره نشد". */
        'detail'  => velora_db_fail_message($e),
    ], 500);
} catch (Throwable $e) {
    log_action('API_ERROR', [
        'action' => $action,
        'error'  => $e->getMessage(),
        'file'   => $e->getFile(),
        'line'   => $e->getLine(),
    ]);
    jresp([
        'ok'      => false,
        'error'   => 'INTERNAL_ERROR',
        'message' => APP_DEBUG ? $e->getMessage() : 'خطای سرور',
    ], 500);
}