<?php
declare(strict_types=1);
/**
 * VELORA · regression probes
 *
 * Helper predicates for section 10 of tests/smoke.php. They live in their own
 * file rather than inline in the test body because each one has to run inside a
 * child process that has already booted the real config.php — which is the only
 * way to assert against the code as it is actually loaded, rather than against
 * a copy of it.
 *
 * They read source and reason about structure, and that is a deliberate
 * trade-off worth stating plainly. Driving these through the HTTP API would need
 * a MySQL schema, a seeded catalogue and a simulated payment gateway, none of
 * which the smoke suite has — and the bugs they guard are precisely the ones
 * that only appear under those conditions. A structural assertion runs
 * everywhere, in a second, and fails loudly when the shape that caused the
 * outage comes back.
 *
 * The trade-off's cost is that a sufficiently determined refactor can satisfy
 * these while changing behaviour. Every probe below therefore asserts the ORDER
 * of two operations, or the ABSENCE of a construct — the things a refactor does
 * not move by accident — and never merely the presence of a string.
 *
 * EVERY probe reads through smoke_code_only(). That is not a detail. This
 * codebase explains its own history in prose, and a comment describing the code
 * that WAS there matches a search for that code exactly as well as the code
 * does. See that function's docblock for the two ways this actually bit.
 */

/** Absolute path to a file in the project, from the project root. */
function smoke_file(string $rel): string
{
    $p = dirname(__DIR__) . '/' . $rel;
    return is_file($p) ? (string) file_get_contents($p) : '';
}

/**
 * A file's source with every comment removed, using PHP's own tokenizer.
 *
 * A regex cannot be used for this and the difference is not academic: this
 * project's own strings contain 'https://velora.maison' and JSON payloads, so
 * a `//` strip would delete real code, and a naive block-comment strip would be
 * fooled by a delimiter sitting inside a string. token_get_all() knows the
 * difference, because it is the parser.
 *
 * Comments are replaced with a newline rather than nothing, so a block comment
 * that happens to be the only separator between two tokens cannot make them lex
 * as one identifier.
 */
function smoke_code_only(string $rel): string
{
    $src = smoke_file($rel);
    if ($src === '') return '';

    $out = '';
    foreach (token_get_all($src) as $tok) {
        if (is_array($tok)) {
            if ($tok[0] === T_COMMENT || $tok[0] === T_DOC_COMMENT) {
                $out .= "\n";
                continue;
            }
            $out .= $tok[1];
            continue;
        }
        $out .= $tok;
    }
    return $out;
}

/** One function's body — braces included, comments removed — by brace counting. */
function smoke_fn_body(string $rel, string $fn): string
{
    $src = smoke_code_only($rel);
    $at  = strpos($src, 'function ' . $fn . '(');
    if ($at === false) return '';

    $open = strpos($src, '{', $at);
    if ($open === false) return '';

    $depth = 0;
    $len   = strlen($src);
    for ($i = $open; $i < $len; $i++) {
        if ($src[$i] === '{') {
            $depth++;
        } elseif ($src[$i] === '}') {
            $depth--;
            if ($depth === 0) return substr($src, $open, $i - $open + 1);
        }
    }
    return '';
}

/**
 * The abandoned-order sweep must not select an order that is holding a live
 * gateway authority.
 *
 * `payment_status='pending'` is written the instant a ZarinPal authority is
 * issued, so a sweep that matches it cancels orders whose card is still being
 * keyed at the bank. The callback then short-circuits on `status='cancelled'`
 * and never asks the gateway whether the money arrived — the customer is
 * charged, the order is dead and the units are back on the shelf.
 */
function sweep_selects_no_pending_authority(): bool
{
    $body = smoke_fn_body('includes/checkout.php', 'sweep_abandoned_orders');
    if ($body === '') return false;

    if (!preg_match('/SELECT id FROM velora_orders(.*?)FOR UPDATE/s', $body, $m)) return false;
    $where = $m[1];

    /* The two things that must not come back, in any spelling. */
    if (stripos($where, "'unpaid','pending'") !== false) return false;
    if (stripos($where, "IN ('unpaid', 'pending')") !== false) return false;

    /* And the thing that must: no authority outstanding means nothing is owed,
       so there is nobody to abandon. */
    return stripos($where, 'payment_authority IS NULL') !== false;
}

/**
 * The sweep must spend its idempotency claim before it restores stock.
 *
 * The catalogue is a file; the row is in a table inside a transaction.
 * rollBack() cannot undo a rename() that already happened, so restoring first
 * meant any later failure rolled the database back to "sweepable again" while
 * the file kept the restoration — and the next sweep restored the same units
 * again. Ordering the claim first inverts that: the row stops being sweepable
 * before the file is touched.
 */
function sweep_marks_before_restores(): bool
{
    $body = smoke_fn_body('includes/checkout.php', 'sweep_abandoned_orders');
    if ($body === '') return false;

    $markAt    = strpos($body, '$markSt->execute');
    $restoreAt = strpos($body, 'catalog_move_stock');
    if ($markAt === false || $restoreAt === false) return false;

    /* Mark first … */
    if ($markAt > $restoreAt) return false;

    /* … and only restore when the claim was actually won, which is what makes
       it idempotent rather than merely ordered. */
    return strpos($body, 'rowCount() !== 1') !== false;
}

/**
 * A bad size must be answered where it is detected, with 400 and a message.
 *
 * The canonicalisation loop used to sit ~110 lines above the try/catch, so its
 * `throw new Exception('INVALID_SIZE')` escaped to api.php's top-level
 * Throwable handler and became HTTP 500 «خطای سرور» — a server fault reported
 * to the customer for a request they got wrong.
 */
function checkout_size_error_is_inline_400(): bool
{
    $src = smoke_code_only('includes/api/checkout.php');
    if ($src === '') return false;
    return str_contains($src, "'error' => 'INVALID_SIZE'")
        && str_contains($src, "'message' => 'سایز نامعتبر است'");
}

/** No `throw new Exception('INVALID_*')` may escape the try block. */
function checkout_has_no_invalid_size_throw(): bool
{
    $src = smoke_code_only('includes/api/checkout.php');
    return !str_contains($src, "throw new Exception('INVALID_SIZE'")
        && !str_contains($src, "throw new Exception('INVALID_ITEM'");
}

/**
 * The catch arms that used to translate those throws are unreachable now and
 * must not linger: an arm that can never run reads as coverage the code has.
 */
function checkout_has_no_dead_invalid_arms(): bool
{
    $src = smoke_code_only('includes/api/checkout.php');
    return !str_contains($src, "=== 'INVALID_ITEM'")
        && !str_contains($src, "=== 'INVALID_SIZE'");
}

/**
 * rate_limit() must honour the fail-closed rule when the LOCK cannot be taken.
 *
 * flock() returning false skipped the counting block and left $bucket at its
 * fabricated default with count = 0, so the final `return $bucket['count'] <=
 * $max` evaluated 0 <= max, i.e. true: the limiter switched itself off, for
 * every action at once, including the ones explicitly listed as fail-closed,
 * and logged nothing.
 */
function rate_limit_fails_closed_on_lock_failure(): bool
{
    $body = smoke_fn_body('includes/net.php', 'rate_limit');
    if ($body === '') return false;

    /* The lock outcome has to be captured … */
    if (!preg_match('/\$locked\s*=\s*flock\(/', $body)) return false;

    /* … and branched on … */
    $guardAt = strpos($body, 'if (!$locked)');
    if ($guardAt === false) return false;

    /* … BEFORE the counting result is returned, not after. */
    $returnAt = strpos($body, 'return $bucket[\'count\'] <= $max;');
    if ($returnAt === false) return false;

    return $guardAt < $returnAt;
}

/**
 * An unreadable catalogue must be reported, not answered 304.
 *
 * velora_catalog_version() returns the constant 'missing' when the file cannot
 * be read, so every broken catalogue produced the same ETag. The If-None-Match
 * handler used to run first, so a client sending `*` got a bodyless 304 and
 * never learned the shop was broken — which is the one question this endpoint
 * exists to answer.
 */
function catalog_503_precedes_304(): bool
{
    $src = smoke_code_only('catalog.php');
    if ($src === '') return false;

    $unreadableAt = strpos($src, 'CATALOG_UNREADABLE');
    $notMatchAt   = strpos($src, 'HTTP_IF_NONE_MATCH');
    if ($unreadableAt === false || $notMatchAt === false) return false;

    return $unreadableAt < $notMatchAt;
}

/**
 * Address fields must be length-checked BEFORE they are truncated.
 *
 * Each field used to arrive already cut to its column width and was then
 * compared with `mb_strlen(...) > N` — which can never be true of a value that
 * was truncated to N. A 4 KB label was silently stored as its first 40
 * characters while the code around it claimed to reject it.
 */
function address_length_guard_precedes_truncation(): bool
{
    $body = smoke_fn_body('includes/addresses.php', 'velora_address_in');
    if ($body === '') return false;

    /* The oversized rejections … */
    $guardAt = strpos($body, "'LABEL_INVALID',   'adLabel'");
    if ($guardAt === false) return false;

    /* … must come before the mb_substr() calls that do the cutting. */
    $truncateAt = strpos($body, '$receiver  = mb_substr($receiver, 0, 120)');
    if ($truncateAt === false) return false;

    return $guardAt < $truncateAt;
}

/**
 * address_set_default must prove the address exists, and owns it, BEFORE it
 * clears the account's current default.
 *
 * It used to clear is_default across the whole account and only then set the
 * new one, with $id unchecked and unowned — so id=0, a deleted id or another
 * customer's id cleared every default in the account and still answered
 * {'ok':true}, leaving the customer with no default address at all.
 *
 * Scoped to the address_set_default branch rather than the whole file, and that
 * scoping is load-bearing: address_save legitimately clears the account default
 * BEFORE it proves the row it is about to write exists, because it is creating
 * that row. A file-wide search finds address_save's ordering first and reports
 * a bug that is not there.
 */
function address_default_checks_ownership_first(): bool
{
    $src  = smoke_code_only('includes/api/address.php');
    $from = strpos($src, "\$action === 'address_set_default'");
    if ($from === false) return false;

    /* The branch runs to the next top-level `if ($action ===`, or to EOF. */
    $next = strpos($src, "\nif (\$action === ", $from + 1);
    $body = $next === false ? substr($src, $from) : substr($src, $from, $next - $from);
    if (strlen($body) < 40) return false;   /* refuse to judge a stub */

    $clearAt = strpos($body, 'SET is_default=0 WHERE user_id=?');
    $checkAt = strpos($body, 'SELECT id FROM velora_addresses WHERE id=? AND user_id=?');
    if ($clearAt === false || $checkAt === false) return false;

    return $checkAt < $clearAt;
}

/**
 * The loopback debug OTP must fit the four boxes the UI actually renders.
 *
 * It minted six digits. admin.php renders four `.otp-box` inputs and js/auth.js
 * refuses below four, caps a paste at four and submits the moment the fourth is
 * filled — so the one configuration that exists to allow login without an SMS
 * gateway could not be logged into.
 *
 * Checked against the RANGE rather than the literal, so a legitimate rewrite of
 * the bounds does not break the assertion while a six-digit one still does.
 */
function debug_otp_is_four_digits(): bool
{
    $src = smoke_code_only('includes/otp.php');
    if ($src === '') return false;

    if (!preg_match('/random_int\(\s*(\d{3,7})\s*,\s*(\d{3,7})\s*\)/', $src, $m)) return false;

    $lo = (int) $m[1];
    $hi = (int) $m[2];

    /* Four digits: the whole range fits inside 1000..9999 and spans more than
       one value. */
    return $lo >= 1000 && $hi <= 9999 && $hi > $lo;
}

/**
 * Both logout paths must go through the one session-ending helper, and the
 * helper must actually exist.
 *
 * The customer logout emptied $_SESSION, expired the cookie and destroyed the
 * file. The admin logout unset three keys and returned — removing the privilege
 * while leaving the 30-day admin session id live in the operator's browser.
 *
 * `function_exists('session_end')` is deliberately NOT one of these checks. The
 * smoke suite's own single-home census rejects function_exists() over a symbol
 * this codebase declares, and it is right to: the function is loaded by
 * config.php in every process that reaches these handlers, so a guard against
 * it missing would be a guard against nothing. Asserting the declaration and the
 * two call sites is both stricter and honest.
 */
function logout_paths_share_session_end(): array
{
    return [
        str_contains(smoke_code_only('includes/auth.php'), 'function session_end('),
        str_contains(smoke_code_only('includes/api/admin.php'), 'session_end();'),
        str_contains(smoke_code_only('includes/api/auth.php'), 'session_end();'),
        /* And no handler is still ending a session by hand. */
        !str_contains(smoke_code_only('includes/api/admin.php'), 'unset($_SESSION['),
    ];
}

/**
 * api.php must resolve the action BEFORE it applies the database gate.
 *
 * The gate ran first, so with the database down every request was answered
 * DB_FAIL 500 — including one asking for an action that does not exist, or for
 * no action at all. A client with a typo in an action name was told the shop's
 * database was unreachable, which is both untrue (the request would never reach
 * a query) and unactionable for whoever received it.
 *
 * Asserted as an ordering, because that is the whole defect: the handler lookup
 * has to happen above the `!($pdo instanceof PDO)` gate, not below it.
 */
function api_resolves_action_before_db_gate(): bool
{
    $src = smoke_code_only('api.php');
    if ($src === '') return false;

    $resolveAt = strpos($src, '$__handler = velora_api_handler($action)');
    $gateAt    = strpos($src, '!($pdo instanceof PDO)');
    $includeAt = strpos($src, 'include $__handler;');

    if ($resolveAt === false || $gateAt === false || $includeAt === false) return false;

    /* Resolve, then gate, then run the handler — in that order. */
    return $resolveAt < $gateAt && $gateAt < $includeAt;
}

/**
 * An unpublished action is a 400, never a 401.
 *
 * This branch is the one place in api.php where the fault is provably the
 * caller's: nothing about a missing or misspelled action name involves
 * credentials, so 401 — "present credentials, and they were rejected or absent"
 * — is a category error. It has also been observed arriving as 401 from a
 * deployment, which is why the status is pinned here rather than trusted.
 */
function api_unknown_action_is_400(): bool
{
    $src = smoke_code_only('api.php');
    if ($src === '') return false;

    /* The two answers are distinguished … */
    $distinct = preg_match(
        '/\? *' . "'NO_ACTION'" . ' *: *' . "'UNKNOWN_ACTION'" . '/',
        $src
    ) === 1;

    /* … and the branch answers 400. */
    $is400 = str_contains($src, 'jresp($unknown, 400)');

    return $distinct && $is400;
}

/**
 * The payment callback must never let a query parameter release stock.
 *
 * `Status` arrives in the query string of a redirect the *shopper's browser*
 * followed, so anyone who knows an order_id and its authority — both of which
 * their own checkout response hands them — controls it. The branch used to read
 * it as fact: `Status !== 'OK'` meant "restore_stock_for_order() + mark failed",
 * and both are permanent.
 *
 * The attack that turns that into unlimited oversell is three requests:
 *   1. check out the last pair of a scarce size (the response carries order_id
 *      and a pay_url whose last path segment is the authority);
 *   2. GET the callback with `Status=NOK` — the units go back on the shelf;
 *   3. pay the still-live authority for real — the callback then sees
 *      payment_status != 'paid' and status != 'cancelled', marks it paid, and
 *      never re-deducts. Sold N times, held once.
 *
 * So the assertion is not "the branch was deleted" — it is that whatever the
 * browser claimed, the gateway is asked before anything is released, and that
 * the restore is reachable only from a gateway 'unpaid' verdict.
 */
function payment_callback_never_trusts_browser_status(): bool
{
    $body = smoke_fn_body('includes/api/checkout.php', '__action_payment_callback__');
    if ($body === '') $body = (string) @file_get_contents(__DIR__ . '/../includes/api/checkout.php');
    if ($body === '') return false;

    /* Isolate the branch itself, so a `restore_stock_for_order()` in the
       indeterminate arm below cannot satisfy the check by accident. */
    $branchAt = strpos($body, "if (\$status !== 'OK') {");
    if ($branchAt === false) return false;

    $nextBranch = strpos($body, 'if (!zarinpal_verdict_is_final', $branchAt);
    $branch = $nextBranch === false
        ? substr($body, $branchAt)
        : substr($body, $branchAt, $nextBranch - $branchAt);

    /* The gateway is consulted before the branch decides anything … */
    if (!str_contains($branch, 'zarinpal_reconcile(')) return false;

    /* … and the three verdicts are all handled, so no path falls through to a
       release by default. */
    foreach (["'paid'", "'unpaid'", "'unknown'"] as $state) {
        if (!str_contains($branch, $state)) return false;
    }

    /* The restore sits inside the `unpaid` arm, i.e. after a gateway decision,
       and nowhere in this branch before the reconcile. */
    $restoreAt    = strpos($branch, 'restore_stock_for_order(');
    $unpaidAt     = strpos($branch, "'unpaid'");
    $reconcileAt  = strpos($branch, 'zarinpal_reconcile(');
    if ($restoreAt === false || $unpaidAt === false || $reconcileAt === false) return false;

    return $reconcileAt < $unpaidAt && $unpaidAt < $restoreAt;
}

/**
 * Promoting an order to `paid` must re-claim stock that was already released.
 *
 * The sequence is ordinary, not an attack: the gateway declines once, the units
 * go back on the shelf, the shopper returns to the still-live payment page and
 * pays on a second attempt. That order is genuinely paid — and before the stock
 * ledger existed the promotion assumed its reservation was still intact, so it
 * became `paid` while its units were free to sell to somebody else.
 *
 * Every path that writes `payment_status='paid'` therefore has to pass through
 * claim_stock_for_order(), which decrements only when the ledger says the
 * reservation was released.
 */
function paid_promotion_reclaims_released_stock(): bool
{
    $src = (string) @file_get_contents(__DIR__ . '/../includes/api/checkout.php');
    if ($src === '') return false;

    /* One call to claim_stock_for_order() per promotion, inside the same
       `if ($won)` guard that owns bump_sold_for_order(). Asserting on the
       call rather than on a comment is what keeps this honest. */
    $claims = preg_match_all('/claim_stock_for_order\(\$pdo, \$orderId\)/', $src);
    if ((int) $claims < 3) return false;

    /* bump_sold_for_order() must not be reachable on its own anywhere: every
       promotion that sells a unit also re-claims it. */
    $bumps = preg_match_all('/bump_sold_for_order\(\$pdo, \$orderId, 1\)/', $src);
    return (int) $bumps === (int) $claims;
}

/**
 * The stock ledger must be release-guarded everywhere stock goes back.
 *
 * Three independent paths increment the catalogue for an order: the payment
 * refusal, the abandoned-order sweep, and an operator cancelling from the panel.
 * Before the ledger they were guarded by three different payment-shaped
 * predicates, none of which asked whether the units had *already* returned — so
 * any two of them could fire for one order and return stock that was never
 * sold.
 *
 * The invariant now is single and mechanical: `stock_claimed=1` in the WHERE
 * clause, or `stock_claimed=0` written in the same statement.
 */
function stock_release_is_ledger_guarded(): bool
{
    $restore = smoke_fn_body('includes/checkout.php', 'restore_stock_for_order');
    if ($restore === '') return false;

    /* Both spellings are allowed: the migrated one and the not-yet-migrated
       fallback. What is not allowed is a build with neither. */
    if (!str_contains($restore, 'stock_claimed=1')) return false;
    if (!str_contains($restore, 'stock_claimed=0')) return false;

    /* And the release must be conditional on winning the claim, which is what
       makes it idempotent rather than merely ordered. */
    return str_contains($restore, 'rowCount() !== 1');
}

/**
 * The admin panel's only credential must never have a default.
 *
 * ADMIN_PHONE was the entire access-control list — the panel has no username and
 * no password, just an SMS code sent to one number — and it shipped with a real
 * Iranian mobile as its fallback. Two failures from one line: the credential was
 * in the source for anyone who read the repository, and an install that forgot
 * to set VELORA_ADMIN_PHONE inherited a *working* one rather than failing closed.
 *
 * So: no literal, and no `env()` fallback. The value must come from the
 * environment or the application must refuse to start.
 */
function admin_phone_has_no_usable_default(): bool
{
    $src = smoke_code_only('config.php');
    if ($src === '') return false;

    if (!str_contains($src, 'env(\'VELORA_ADMIN_PHONE\')')) return false;

    /* The decisive assertion: the env() read takes NO fallback argument. A
       second argument is a default, and a default is a working credential on
       every install that forgot to configure one — which is the whole defect.
       (The digits in the error message are the format example an operator is
       shown, not a credential, and asserting on bare `09\d{9}` would flag it.) */
    if (preg_match('/env\(\s*\'VELORA_ADMIN_PHONE\'\s*,/', $src)) return false;

    /* … and it must fail closed when absent, exactly like the DB credentials. */
    return str_contains($src, 'CONFIG_INCOMPLETE')
        && str_contains($src, 'preg_match(\'/^09\\d{9}$/\', $__adminPhone)');
}

/**
 * A storefront session must actually expire.
 *
 * SESSION_TTL was defined and documented as the two-hour customer session, and
 * nothing read it. `user_at` was written at every sign-in with no reader, and
 * the only thing that ever expired a session file was session.gc_maxlifetime —
 * which is max(SESSION_TTL, ADMIN_SESSION_TTL) because PHP cannot collect an
 * admin session differently from a customer's. The admin's 30-day window
 * therefore applied to everyone: a customer who signed in on a café machine was
 * still fully authenticated to my_orders and checkout for a month.
 *
 * Both roles are asserted, because the admin session had the same hole and a fix
 * that only covers one of them leaves the other open.
 */
function session_ttl_is_actually_enforced(): bool
{
    $auth = smoke_fn_body('includes/auth.php', 'is_user');
    if ($auth === '') return false;
    if (!str_contains($auth, 'SESSION_TTL')) return false;
    if (!str_contains($auth, 'session_end()')) return false;

    $admin = smoke_fn_body('includes/auth.php', 'is_admin');
    if ($admin === '') return false;

    return str_contains($admin, 'ADMIN_SESSION_TTL')
        && str_contains($admin, 'ADMIN_SESSION_IDLE_TTL');
}

/**
 * The storefront must publish the whole catalogue to the browser.
 *
 * `window.VELORA_CATALOG` is not a rendering hint: js/data.js builds CATALOG
 * from it, and js/state.js's sanitiseCart() filters the persisted basket with
 * `capFor(i.id) > 0`, where an absent id reads 0 stock. Publishing the FILTERED
 * feed therefore meant that ticking one chip silently deleted every cart line
 * for a product the filter excluded — and the next persBag() made it permanent.
 * Add heels, tap "sandal", lose the heels.
 *
 * Asserted as two variables rather than as the absence of a bug: the narrowed
 * one must still drive the grid, and only the captured copy may be published.
 */
function storefront_publishes_the_whole_catalogue(): bool
{
    $src = smoke_code_only('index.php');
    if ($src === '') return false;

    /* The copy is taken before the filter pass runs … */
    $capture = strpos($src, '$catalogAll = $catalogFeed;');
    $filter  = strpos($src, '$catalogFeed = array_values(array_filter(');
    if ($capture === false || $filter === false || $capture > $filter) return false;

    /* … and the browser gets the copy, never the narrowed feed. */
    if (!str_contains($src, '$encodeLd($catalogAll)')) return false;

    return !preg_match('/VELORA_CATALOG\s*=\s*<\?= \$encodeLd\(\$catalogFeed\)/', $src);
}

/**
 * The service worker must never write a document to a cache.
 *
 * The navigation branch called networkFirst(request, RUNTIME_CACHE, event), and
 * networkFirst's cache.put() fires for any response isCacheableResponse()
 * approves. The comment above it promised the opposite, so the guarantee rested
 * entirely on index.php continuing to send one `no-store` header. Remove it, or
 * add any same-origin HTML route without it — sitemap.php and the PHP error
 * pages both qualify — and every visitor shares one document. index.php inlines
 * the CSRF token and the whole catalogue into that document, so this is a
 * cross-session token disclosure, not merely a staleness bug.
 *
 * The invariant is now enforced by a strategy that never writes, rather than
 * negotiated over response headers. That is what is asserted.
 */
function service_worker_never_caches_documents(): bool
{
    /* Read raw, comments included. Every pattern below is code-shaped — a
       `name(...)` call preceded by `await` or `=`, a function definition — so
       the prose explaining this fix cannot satisfy any of them. Asserting on the
       bare name would, because this comment mentions it. */
    $src = smoke_file('sw.js');
    if ($src === '') return false;

    /* A pass-through strategy exists and neither reads nor writes a cache. */
    if (!preg_match(
        '/async function networkPassThrough\([^)]*\)\s*\{\s*try\s*\{\s*return await fetch\(\s*request\s*\)\s*;\s*\}\s*catch\s*\{[^}]*\}\s*\}/s',
        $src
    )) return false;

    /* No CALL to networkFirst with a cache name survives below the HTML branch.
       The catch-all is reached only by an unclassified same-origin GET — exactly
       the kind of route nobody audited — so it must pass through too. */
    $nav = strpos($src, 'isHtmlRequest(request, url)');
    if ($nav === false) return false;

    $tail = substr($src, $nav);
    if (preg_match('/(?:await|=)\s*networkFirst\(\s*request\s*,\s*RUNTIME_CACHE/', $tail)) return false;

    /* And both document-capable branches use the pass-through instead. */
    return substr_count($tail, 'await networkPassThrough(request)') >= 2;
}

/**
 * The checkout must not collect card data it never sends.
 *
 * It collected PAN, expiry and CVV2 in a form on this origin, with
 * `autocomplete="cc-number"`, validated them, and required them to advance —
 * while the submit payload carries items, promo, contact and address and nothing
 * else, velora-bridge.js has no card parameter, and the orders table has no card
 * column. A page this merchant controls in which the customer types a PAN is
 * enough on its own to pull the whole cardholder data environment into PCI
 * scope, and the note above the fields claimed the data never touched this site.
 *
 * Card data belongs to the gateway's page. So no field may come back, and the
 * step that held them must have nothing to validate.
 */
function checkout_collects_no_card_data(): bool
{
    /* Asserted on shapes that cannot appear in prose — an element with this id,
     this attribute pairing, this step table — rather than on the bare field
     names. A test that grepped for `ckCard` would also match the comment
     explaining why it is gone, which is a test that cannot be written without
     lying in its own documentation.

     Note these read the raw file, comments included. That is deliberate and it
     is safe precisely because every pattern below is code-shaped: `id="…"` with
     an equals sign and a value, `autocomplete="cc-…"`, a two-element step array.
     Prose about the removal does not reproduce any of them. */
    $renderer = smoke_file('js/renderers-aurelle.js');
    $checkout = smoke_file('js/checkout.js');
    if ($renderer === '' || $checkout === '') return false;

    /* 1. No card input is rendered … */
    foreach (['ckHolder', 'ckCard', 'ckExp', 'ckCvc'] as $id) {
        if (str_contains($renderer, 'id="' . $id . '"')) return false;
    }
    /* … and nothing asks the browser to autofill one. */
    if (str_contains($renderer, 'autocomplete="cc-')) return false;

    /* 2. The step machine validates nothing on the payment step. */
    if (!preg_match('/STEP_FIELDS\s*=\s*\[\s*\[[^\]]*ckZip[^\]]*\],\s*\[\s*\]\s*\]/', $checkout)) return false;

    /* 3. No validator remains for a card field either. */
    if (preg_match('/^\s*ck(?:Card|Cvc|Exp|Holder)\s*:/m', $checkout)) return false;

    /* 4. And the order payload still carries no card-shaped field. */
    return !preg_match('/\b(card_number|cardNumber|cvv|cvc|pan|card_exp)\b\s*:/i', $checkout);
}

/**
 * A cart line's cap must be that SIZE's stock, not the product's total.
 *
 * The server checks stock per (product, eu_size) inside the checkout transaction
 * and refuses the ENTIRE order if any line exceeds it. The client capped against
 * `p.stock` — the total across every size — so a product with 11 pairs left, one
 * of them in size 41, offered a cap of 5, let the customer build a 3-pair line
 * of size 41, and then had the whole order rejected at the final request. Every
 * other line in the basket went down with it.
 *
 * Asserted on capFor's signature, because a size parameter that nothing passes
 * is the same defect wearing a different hat.
 */
function cart_cap_is_per_size(): bool
{
    $state = smoke_file('js/state.js');
    if ($state === '') return false;

    /* capFor takes a size, and uses it when given. */
    if (!preg_match('/const capFor\s*=\s*\(\s*id\s*,\s*size\s*\)/', $state)) return false;
    if (!str_contains($state, 'stockOfSize(id, size)')) return false;

    /* The sanitiser clamps per line, using the line's own size — that is what
       stops a stale persisted line from being re-added above what is left. */
    if (!str_contains($state, 'capFor(i.id, i.size)')) return false;

    /* And no call site may still ask for the product-level answer when a size
       is in hand. */
    $cart = smoke_file('js/cart.js');
    if ($cart === '') return false;

    return !preg_match('/capFor\(\s*it\.id\s*\)/', $cart)
        && !preg_match('/capFor\(\s*id\s*\)/', $cart);
}

