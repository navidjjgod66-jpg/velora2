<?php
declare(strict_types=1);
/**
 * VELORA · Checkout & order-integrity helpers
 *
 * Extracted verbatim from api.php during the monolith split — same code, same
 * behaviour, one home per concern. Covers the checkout idempotency claim
 * machine (velora_checkout_attempts), the abandoned-order sweep, stock and
 * sold-counter restoration, the payment audit log, and the gateway-callback
 * field extractor.
 */

if (!defined('VELORA_CONFIG_LOADED')) {
    http_response_code(500);
    exit('includes/checkout.php requires config.php to be loaded first.');
}

/* ═══════════════════════════════════════════════════════════════════════════
   IMAGE KEY SANITIZING
   ═══════════════════════════════════════════════════════════════════════════ */
/**
 * The one home for image-key validation.
 *
 * This body used to exist twice — once here, once inline at the top of
 * api.php — byte-for-byte identical copies of the same rule ("a key is either
 * an https-safe URL or a <name>.webp upload"). The api.php copy was removed;
 * every caller now reaches this one through api.php's require of this file.
 * If the two copies had drifted, admin uploads would have validated by one
 * rule and checkout snapshots by the other.
 */
function sanitize_image_key(string $input): string {
    $input = trim($input);
    if ($input === '' || strlen($input) > 512) return '';
    if (preg_match('#^https?://#i', $input)) {
        if (preg_match('/["\'<>\s|]/', $input)) return '';
        if (preg_match('#^http://#i', $input) && is_https()) return '';
        return filter_var($input, FILTER_VALIDATE_URL) ? $input : '';
    }
    if (preg_match('#^[a-zA-Z0-9_-]{1,80}\.webp$#', $input)) return $input;
    return '';
}

/* ═══════════════════════════════════════════════════════════════════════════
   CHECKOUT IDEMPOTENCY
   ═══════════════════════════════════════════════════════════════════════════ */
const CKO_REPLAY_TTL = 90;
const CKO_CLAIM_TTL  = 300;
const CKO_RETENTION_HOURS = 24;

function &cko_claim_slot(): array {
    static $slot = ['id' => 0, 'token' => '', 'settled' => false];
    return $slot;
}

function cko_claim(PDO $pdo, int $userId, string $fingerprint): array {
    $slot = &cko_claim_slot();
    $slot = ['id' => 0, 'token' => '', 'settled' => false];

    $token = bin2hex(random_bytes(16));

    try {
        $steal = "((state = 'pending' AND created_at < NOW() - INTERVAL " . CKO_CLAIM_TTL . " SECOND)"
               . " OR (state = 'settled' AND created_at < NOW() - INTERVAL " . CKO_REPLAY_TTL . " SECOND))";

        $stmt = $pdo->prepare(
            "INSERT INTO velora_checkout_attempts
                (user_id, fingerprint, minute_bucket, state, claim_token, order_id, pay_url, total, gateway)
             VALUES (?, ?, FLOOR(UNIX_TIMESTAMP(NOW()) / 60), 'pending', ?, '', '', 0, '')
             ON DUPLICATE KEY UPDATE
                minute_bucket = IF($steal, VALUES(minute_bucket), minute_bucket),
                state         = IF($steal, 'pending', state),
                claim_token   = IF($steal, VALUES(claim_token), claim_token),
                order_id      = IF($steal, '', order_id),
                pay_url       = IF($steal, '', pay_url),
                total         = IF($steal, 0, total),
                gateway       = IF($steal, '', gateway),
                created_at    = IF($steal, NOW(), created_at),
                id            = LAST_INSERT_ID(id)"
        );
        $stmt->execute([$userId, $fingerprint, $token]);
        $claimId = (int) $pdo->lastInsertId();
        if ($claimId <= 0) return ['ok' => false, 'reason' => 'unavailable'];

        $row = $pdo->prepare(
            "SELECT state, claim_token, pay_url, order_id, total, gateway,
                    UNIX_TIMESTAMP(NOW() - created_at) AS age_s
               FROM velora_checkout_attempts WHERE id = ? LIMIT 1"
        );
        $row->execute([$claimId]);
        $r = $row->fetch();
        if (!is_array($r)) {
            return ['ok' => false, 'reason' => 'unavailable'];
        }

        $slot['id'] = $claimId;

        $owned = (string) $r['state'] === 'pending' && (string) $r['claim_token'] === $token;
        if ($owned) {
            $slot['token'] = $token;
            return ['ok' => true];
        }

        $age = (int) ($r['age_s'] ?? 0);
        if ((string) $r['state'] === 'settled' && (string) $r['pay_url'] !== '' && $age <= CKO_REPLAY_TTL) {
            return [
                'ok'       => false,
                'reason'   => 'settled',
                'order_id' => (string) $r['order_id'],
                'pay_url'  => (string) $r['pay_url'],
                'total'    => (int) $r['total'],
                'gateway'  => (string) $r['gateway'],
            ];
        }

        return ['ok' => false, 'reason' => 'in_flight'];
    } catch (Throwable $e) {
        log_action('CHECKOUT_IDEMPOTENCY_UNAVAILABLE', ['error' => $e->getMessage()]);
        $slot = ['id' => 0, 'token' => '', 'settled' => false];
        return ['ok' => false, 'reason' => 'unavailable'];
    }
}

function cko_settle(PDO $pdo, string $orderId, string $payUrl, int $total, string $gateway): void {
    $slot = &cko_claim_slot();
    if ($slot['id'] <= 0 || $slot['settled']) return;
    try {
        $pdo->prepare(
            "UPDATE velora_checkout_attempts
                SET state = 'settled', order_id = ?, pay_url = ?, total = ?, gateway = ?, settled_at = NOW()
              WHERE id = ? AND claim_token = ? AND state = 'pending'"
        )->execute([
            $orderId,
            mb_substr($payUrl, 0, 1024),
            $total,
            $gateway,
            $slot['id'],
            $slot['token'],
        ]);
        $slot['settled'] = true;
    } catch (Throwable $e) {
        log_action('CHECKOUT_IDEMPOTENCY_SETTLE_FAIL', [
            'order_id' => $orderId,
            'error'    => $e->getMessage(),
        ]);
    }
}

function cko_register_release_guard(PDO $pdo): void {
    $slot = &cko_claim_slot();
    register_shutdown_function(static function () use ($pdo, &$slot): void {
        if ($slot['id'] <= 0 || $slot['settled'] || $slot['token'] === '') return;
        try {
            $pdo->prepare(
                "DELETE FROM velora_checkout_attempts
                  WHERE id = ? AND claim_token = ? AND state = 'pending'"
            )->execute([$slot['id'], $slot['token']]);
        } catch (Throwable $e) {
        }
    });
}

function cko_drop_claim(PDO $pdo): void {
    $slot = &cko_claim_slot();
    if ($slot['id'] <= 0) return;
    try {
        $pdo->prepare("DELETE FROM velora_checkout_attempts WHERE id = ? AND state = 'settled'")
            ->execute([$slot['id']]);
    } catch (Throwable $e) {
        log_action('CHECKOUT_IDEMPOTENCY_DROP_FAIL', [
            'id'    => $slot['id'],
            'error' => $e->getMessage(),
        ]);
    }
    $slot = ['id' => 0, 'token' => '', 'settled' => false];
}

/* ═══════════════════════════════════════════════════════════════════════════
   STOCK MOVEMENT — the two shapes every stock write is made of
   ═══════════════════════════════════════════════════════════════════════════

   Four functions in this file used to open with the same SELECT over
   velora_order_items and the same accumulation loop, and then write the result
   into the catalogue inside a velora_catalog_transaction() whose body was
   copied each time. Two of them applied the delta with the opposite sign from
   the other two and neither said so in its name, so a change to how a size key
   is built — or to whether stock may go negative — had to be found and made in
   four places, two of them inverted.

   There are only two reads and two writes, so that is what is here. */

/** Every line of an order as "productId|euSize" => qty. Sizes 0 and below are
 *  not storable and are skipped, which is the one rule all four callers shared. */
function order_size_demand(PDO $pdo, string $orderId): array {
    $st = $pdo->prepare("SELECT product_id, eu_size, qty FROM velora_order_items WHERE order_id=?");
    $st->execute([$orderId]);
    $demand = [];
    foreach ($st->fetchAll() as $r) {
        $eu = (int) $r['eu_size'];
        if ($eu <= 0) continue;
        $k = (string) $r['product_id'] . '|' . $eu;
        $demand[$k] = ($demand[$k] ?? 0) + (int) $r['qty'];
    }
    return $demand;
}

/** Every line of an order as productId => qty, size collapsed away — the
 *  shape the `sold` counter is keyed on. */
function order_product_totals(PDO $pdo, string $orderId): array {
    $st = $pdo->prepare("SELECT product_id, qty FROM velora_order_items WHERE order_id=?");
    $st->execute([$orderId]);
    $totals = [];
    foreach ($st->fetchAll() as $r) {
        $p = (string) $r['product_id'];
        $totals[$p] = ($totals[$p] ?? 0) + (int) $r['qty'];
    }
    return $totals;
}

/**
 * Move size stock by a signed delta.
 *
 * +1 puts units back (a failed payment, an abandoned cart); -1 takes them
 * back out (an order being cancelled). $requireStock is what separates the
 * two callers that differ in kind rather than in sign: a cancellation may not
 * drive a size below zero, so when any size would come up short the whole
 * write is skipped and the shortage is reported, while a restoration never
 * refuses to restore.
 *
 * @param array<string, int> $demand  "productId|euSize" => qty
 * @return array{applied: int, short: int}  units touched, units unavailable
 */
function catalog_move_stock(array $demand, int $sign, bool $requireStock = false): array {
    if (!$demand) return ['applied' => 0, 'short' => 0];
    $applied = 0;
    $short   = 0;
    velora_catalog_transaction(function (array $data, array &$out) use ($demand, $sign, $requireStock, &$applied, &$short): bool {
        if ($requireStock && $sign < 0) {
            foreach ($out['products'] as $prod) {
                $pid = (string) ($prod['id'] ?? '');
                if (!is_array($prod['sizes'] ?? null)) continue;
                foreach ($prod['sizes'] as $sz) {
                    $k = $pid . '|' . (int) ($sz['eu'] ?? 0);
                    if (!isset($demand[$k])) continue;
                    if ((int) ($sz['stock'] ?? 0) < (int) $demand[$k]) $short += (int) $demand[$k];
                }
            }
            if ($short > 0) return true;
        }
        foreach ($out['products'] as &$prod) {
            $pid = (string) ($prod['id'] ?? '');
            if (!is_array($prod['sizes'] ?? null)) continue;
            foreach ($prod['sizes'] as &$sz) {
                $k = $pid . '|' . (int) ($sz['eu'] ?? 0);
                if (!isset($demand[$k])) continue;
                $want = (int) $demand[$k];
                $sz['stock'] = $sign > 0
                    ? (int) ($sz['stock'] ?? 0) + $want
                    : (int) ($sz['stock'] ?? 0) - $want;
                $applied += $want;
            }
            unset($sz);
        }
        unset($prod);
        return true;
    });
    return ['applied' => $applied, 'short' => $short];
}

/** Move the per-product `sold` counter by a signed delta. Same sign
 *  convention as catalog_move_stock(); +1 on payment, -1 on cancellation. */
function catalog_move_sold(array $totals, int $sign): void {
    if (!$totals) return;
    velora_catalog_transaction(function (array $data, array &$out) use ($totals, $sign): bool {
        foreach ($out['products'] as &$prod) {
            $pid = (string) ($prod['id'] ?? '');
            if (!isset($totals[$pid])) continue;
            $have = (int) ($prod['sold'] ?? 0);
            $prod['sold'] = $sign > 0
                ? $have + (int) $totals[$pid]
                : max(0, $have - (int) $totals[$pid]);
        }
        unset($prod);
        return true;
    });
}

/* ═══════════════════════════════════════════════════════════════════════════
   ABANDONED-ORDER SWEEP
   ═══════════════════════════════════════════════════════════════════════════ */
function sweep_abandoned_orders(PDO $pdo): void {
    if (mt_rand(1, 20) !== 1) return;

    try {
        $pdo->prepare("DELETE FROM velora_checkout_attempts
                        WHERE created_at < NOW() - INTERVAL " . CKO_RETENTION_HOURS . " HOUR")
            ->execute();
    } catch (Throwable $e) {
    }

    try {
        $removed = velora_catalog_sweep_tmp();
        if ($removed > 0) log_action('CATALOG_TMP_SWEEP', ['removed' => $removed]);
    } catch (Throwable $e) {
    }

    try {
        $pdo->beginTransaction();

        /* ONLY orders that never reached the gateway.

           This swept `payment_status IN ('unpaid','pending')`, and
           `pending` is not "awaiting payment" — it is set the instant a live
           ZarinPal authority is issued (includes/api/checkout.php, the
           UPDATE that stores payment_authority). So this query selected
           orders whose card was being keyed at the bank right now, cancelled
           them, and handed their units back to the shelf.

           The customer then returned from the gateway to a row that is
           already `cancelled`, and payment_callback short-circuits on that
           status BEFORE calling zarinpal_verify() — so it never found out
           the money had arrived. Card charged, order dead, stock resold, and
           the only evidence a log line naming the order id.

           Any customer slower than 30 minutes on the payment page — a mobile
           connection, a card transfer, a bank app — lost the order. The
           window is not generous; it is the entire population of slow
           checkouts.

           An order with an authority outstanding is never abandoned by
           definition: nobody has said no. The gateway's own reconciliation
           (zarinpal_reconcile) is what resolves an order nobody came back
           for, and the callback does that on the next real hit. An order
           still `pending` with an authority ages into the admin's order list,
           which is the right place for a human to look. */
        $st = $pdo->prepare(
            "SELECT id FROM velora_orders
              WHERE payment_status = 'unpaid'
                AND payment_authority IS NULL
                AND status = 'pending'
                AND created_at < NOW() - INTERVAL 30 MINUTE
              ORDER BY id ASC
              LIMIT 25
              FOR UPDATE"
        );
        $st->execute();
        $ids = $st->fetchAll(PDO::FETCH_COLUMN);
        if (!$ids) { $pdo->commit(); return; }

        /* Mark FIRST, restore second, and only if the mark was won.

           The order was: catalog_move_stock() then the row update, justified
           in a comment as "the safe direction, because a failure between the
           two leaves stock higher than reality rather than lower". The
           reasoning was sound and the conclusion was backwards, because the
           catalogue is a FILE and the row is in a TABLE inside a transaction.

           rollBack() undoes the UPDATE. It cannot undo a rename() that already
           happened. So on any failure after the restore — the rename retry
           giving up, $pdo->commit() itself throwing — the catch rolled the
           database back to `payment_status='unpaid'`, leaving the row eligible
           for this very sweep again on its next 1-in-20 roll. Stock went up by
           one, and went up again, monotonically, for as long as the order sat
           unmatched. The same file, restored N times.

           Ordering it the way restore_stock_for_order() already does (line ~345)
           inverts the failure: the mark commits first, so the row is no longer
           sweepable, and the restore runs exactly once for the one row that
           won the claim. If the restore then throws, the rollback undoes the
           mark and the next sweep simply tries that one order again — at most
           one duplicate, never unbounded, and never a silent inflation. */
        $markSt = $pdo->prepare(velora_stock_ledger_ready($pdo)
            ? "UPDATE velora_orders SET status='cancelled', payment_status='failed', stock_claimed=0, updated_at=NOW()
                                     WHERE id=? AND payment_status = 'unpaid' AND payment_authority IS NULL AND stock_claimed=1"
            : "UPDATE velora_orders SET status='cancelled', payment_status='failed', updated_at=NOW()
                                     WHERE id=? AND payment_status = 'unpaid' AND payment_authority IS NULL");
        $restored = 0;
        foreach ($ids as $oid) {
            $demand = order_size_demand($pdo, $oid);
            $markSt->execute([$oid]);
            if ($markSt->rowCount() !== 1) continue;
            catalog_move_stock($demand, +1);
            $restored++;
        }
        $pdo->commit();
        log_action('SWEEP_ABANDONED', ['count' => $restored]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        log_action('SWEEP_FAIL', ['error' => $e->getMessage()]);
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
   STOCK LEDGER PROBE
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Does `velora_orders.stock_claimed` exist yet?
 *
 * The ledger is a migration, and a deployment that has not run it yet must keep
 * taking payments — a schema change is not a reason to fail an order. Every
 * query that mentions the column is guarded by this, so an un-migrated install
 * behaves exactly as it did before the column was introduced rather than
 * throwing a PDOException at the one place that must not fail.
 *
 * Cached per request, like every other capability probe in this project: the
 * answer cannot change between two calls inside a single order.
 */
function velora_stock_ledger_ready(PDO $pdo): bool {
    static $ready = null;
    if ($ready !== null) return $ready;
    try {
        $st = $pdo->prepare(
            "SELECT COUNT(*) FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'velora_orders'
                AND COLUMN_NAME = 'stock_claimed'"
        );
        $st->execute();
        $ready = ((int) $st->fetchColumn()) > 0;
    } catch (Throwable $e) {
        $ready = false;
    }
    return $ready;
}

/* ═══════════════════════════════════════════════════════════════════════════
   STOCK RESTORATION
   ═══════════════════════════════════════════════════════════════════════════ */
function restore_stock_for_order(PDO $pdo, string $orderId, string $gateway): bool {
    try {
        $pdo->beginTransaction();

        /* `stock_claimed=1` is the guard, and it is what makes this idempotent
           against its own history.

           The old predicate was `payment_status IN ('unpaid','pending')`. That
           is a payment-shaped question asked to protect a stock-shaped fact:
           it says nothing about whether the units have *already* gone back, so
           two paths that both decide an order failed — the gateway refusing a
           payment, and an operator cancelling from the panel — each incremented
           the catalogue for the same order, and the second one returned pairs
           that were never sold.

           `stock_claimed=0` in the WHERE clause is the whole fix: the increment
           happens at most once per order, whoever asks for it, in any order. A
           caller that loses the race gets rowCount() 0 and is told it did
           nothing, which is true.

           On an install that has not run the migration the column does not
           exist, so the statement falls back to the original payment-shaped
           predicate. That is the pre-fix behaviour verbatim — no worse than the
           build being deployed — and it keeps the endpoint serving. */
        $ledger = velora_stock_ledger_ready($pdo);
        $mark = $ledger
            ? $pdo->prepare(
                "UPDATE velora_orders
                    SET payment_status='failed', stock_claimed=0, updated_at=NOW()
                  WHERE id=? AND payment_status IN ('unpaid','pending') AND stock_claimed=1"
            )
            : $pdo->prepare(
                "UPDATE velora_orders
                    SET payment_status='failed', updated_at=NOW()
                  WHERE id=? AND payment_status IN ('unpaid','pending')"
            );
        $mark->execute([$orderId]);
        if ($mark->rowCount() !== 1) {
            $pdo->commit();
            return false;
        }

        catalog_move_stock(order_size_demand($pdo, $orderId), +1);

        $pdo->commit();
        log_action('STOCK_RESTORED', [
            'order_id' => $orderId,
            'gateway'  => $gateway,
            'reason'   => 'payment_verify_failed',
        ]);
        return true;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        log_action('STOCK_RESTORE_FAIL', [
            'order_id' => $orderId,
            'gateway'  => $gateway,
            'error'    => $e->getMessage(),
        ]);
        return false;
    }
}

/**
 * Take this order's units off the shelf if they are not already off it.
 *
 * The second half of the invariant restore_stock_for_order() broke.
 *
 * Releasing stock and later discovering the customer paid anyway is an ordinary
 * sequence, not an attack: the gateway declines, the units go back, the shopper
 * returns to the still-live payment page and pays on the second attempt. That
 * order is genuinely paid and must be honoured — but its units are now on the
 * shelf and may already belong to somebody else, so promoting it to `paid`
 * without re-taking them is exactly the oversell this column exists to prevent.
 *
 * Nothing could detect that before, because nothing remembered the release.
 * Now the flag is the memory:
 *
 *   1 → the reservation is intact; the caller must NOT decrement again.
 *   0 → the units were returned; they are taken again here, under the same
 *       `catalog_move_stock(..., requireStock: true)` guard the checkout uses,
 *       so a shelf that cannot cover the order records a shortfall for an
 *       operator instead of silently going negative.
 *
 * The rowCount() guard is the concurrency point, exactly as it is in the paid
 * path: whichever callback reaches the UPDATE first claims the right to
 * re-claim, and the other one does nothing. Returns whether it had to re-claim
 * and whether the shelf could cover it.
 *
 * @return array{reclaimed:bool, short:int}
 */
function claim_stock_for_order(PDO $pdo, string $orderId): array {
    if (!velora_stock_ledger_ready($pdo)) {
        /* Not migrated yet. The old behaviour was to assume the reservation
           was intact, so assuming it again is a faithful no-op rather than a
           new failure mode — and the payment path keeps working while an
           operator runs the migration in db_schema.sql. */
        return ['reclaimed' => false, 'short' => 0];
    }

    $st = $pdo->prepare(
        "UPDATE velora_orders SET stock_claimed=1, updated_at=NOW()
          WHERE id=? AND stock_claimed=0"
    );
    $st->execute([$orderId]);
    if ($st->rowCount() !== 1) {
        return ['reclaimed' => false, 'short' => 0];
    }

    /* The units are gone from the shelf already, so this is a claim, not a
       cancellation: sign -1, and $wasPaid false because bump_sold_for_order()
       is the caller's job, driven by the payment guard that runs alongside this. */
    $info = adjust_order_stock($pdo, $orderId, -1, false);

    if ($info['short'] > 0) {
        /* The money is in and the goods are gone to another customer. The order
           stays paid — that is not this function's to undo — and the row carries
           a shortfall an operator settles by hand. */
        log_action('STOCK_RECLAIM_SHORT', [
            'order_id' => $orderId,
            'short'    => $info['short'],
            'items'    => $info['items'],
            'note'     => 'paid after stock had been released — shelf could not cover it',
        ]);
    }
    return ['reclaimed' => true, 'short' => $info['short']];
}

/* ═══════════════════════════════════════════════════════════════════════════
   PAYMENT AUDIT LOG
   ═══════════════════════════════════════════════════════════════════════════ */
function log_payment(PDO $pdo, array $row): void {
    $orderId = (string) ($row['order_id'] ?? '');
    $gateway = (string) ($row['gateway'] ?? '');
    if ($orderId === '' || $gateway === '') return;

    /* Only log against an order that exists.

       payment_callback is reachable by anyone who can guess a well-formed
       order id, and it wrote a velora_payment_logs row on every path —
       including the rejection paths, which are the cheap ones to trigger. With
       a valid id and a wrong trackId, one GET produced a row; the rate limit
       bounds requests per minute but not rows per month, so the table grows
       from unauthenticated traffic alone.

       The trade: a genuine rejection of a real order is still recorded in full
       (this function returns early only when the order is absent), and the
       absence itself is written to the file log, which is append-only, is
       rotated at 8 MB, and is not something a visitor can grow by guessing. */
    static $known = [];
    if (!isset($known[$orderId])) {
        try {
            $probe = $pdo->prepare("SELECT 1 FROM velora_orders WHERE id = ? LIMIT 1");
            $probe->execute([$orderId]);
            $known[$orderId] = $probe->fetchColumn() !== false;
        } catch (Throwable $e) {
            /* If the probe itself fails, allow the write: a missing payment log
               on a real order is worse than an extra row on a bad one. */
            $known[$orderId] = true;
        }
    }
    if (!$known[$orderId]) {
        log_action('PAYMENT_LOG_UNKNOWN_ORDER', ['order_id' => $orderId, 'gateway' => $gateway]);
        return;
    }

    $amount = $row['amount'] ?? null;
    if ($amount === null) {
        try {
            $q = $pdo->prepare("SELECT total FROM velora_orders WHERE id=? LIMIT 1");
            $q->execute([$orderId]);
            $total = $q->fetchColumn();
            $amount = $total === false ? 0 : ((int) $total) * 10;
        } catch (Throwable $e) {
            $amount = 0;
        }
    }

    $response = $row['response'] ?? null;
    try {
        $pdo->prepare("INSERT INTO velora_payment_logs
            (order_id, gateway, authority, ref_id, amount, status, response, ip_address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)")
            ->execute([
                $orderId,
                $gateway,
                $row['authority'] ?? null,
                $row['ref_id']     ?? null,
                (int) $amount,
                (string) ($row['status'] ?? 'unknown'),
                $response === null ? null : (is_string($response) ? $response : json_encode($response, JSON_UNESCAPED_UNICODE)),
                $row['ip'] ?? get_client_ip(),
            ]);
    } catch (Throwable $e) {
        log_action('PAYMENT_LOG_FAIL', [
            'order_id' => $orderId,
            'gateway'  => $gateway,
            'error'    => $e->getMessage(),
        ]);
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
   GATEWAY CALLBACK FIELD EXTRACTOR
   ═══════════════════════════════════════════════════════════════════════════ */
const CKO_CB_FIELDS_ZARINPAL = ['Status' => 128, 'Authority' => 128];
const CKO_CB_SEEN_KEYS_MAX   = 12;

function callback_response_fields(array $source, array $allow): array {
    $out  = [];
    $seen = [];

    foreach ($source as $k => $v) {
        $key = (string) $k;

        if (!isset($allow[$key])) {
            if (count($seen) < CKO_CB_SEEN_KEYS_MAX) {
                $trimmed = preg_replace('/[^\x20-\x7E]/', '', $key);
                if (is_string($trimmed) && $trimmed !== '') $seen[] = mb_substr($trimmed, 0, 64);
            }
            continue;
        }

        if (!is_scalar($v)) {
            $out[$key] = '[non-scalar]';
            continue;
        }
        $s = is_bool($v) ? ($v ? '1' : '0') : (string) $v;
        $out[$key] = mb_substr($s, 0, $allow[$key]);
    }

    if ($seen) $out['seen_keys'] = $seen;
    return $out;
}

/* ═══════════════════════════════════════════════════════════════════════════
   ORDER CANCELLATION — stock + sold counter
   ═══════════════════════════════════════════════════════════════════════════ */
function adjust_order_stock(PDO $pdo, string $orderId, int $sign, bool $wasPaid): array {
    $demand = order_size_demand($pdo, $orderId);
    if (!$demand) return ['items' => 0, 'restored' => 0, 'short' => 0];

    /* $sign < 0 is a cancellation taking units back, so it is the only path
       that must refuse to run rather than clamp — see catalog_move_stock(). */
    $move = catalog_move_stock($demand, $sign, $requireStock = $sign < 0);

    if ($wasPaid && $move['short'] === 0) {
        catalog_move_sold(order_product_totals($pdo, $orderId), -$sign);
    }

    return ['items' => count($demand), 'restored' => $move['applied'], 'short' => $move['short']];
}

function bump_sold_for_order(PDO $pdo, string $orderId, int $sign): void {
    try {
        catalog_move_sold(order_product_totals($pdo, $orderId), $sign);
    } catch (Throwable $e) {
        log_action('SOLD_COUNTER_FAIL', [
            'order_id' => $orderId,
            'sign'     => $sign,
            'error'    => $e->getMessage(),
        ]);
    }
}
