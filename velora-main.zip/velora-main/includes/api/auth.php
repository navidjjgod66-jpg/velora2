<?php
declare(strict_types=1);
/**
 * VELORA · API handlers — auth
 *
 * Actions handled here: send_otp, verify_otp, logout, me
 *
 * Procedural code extracted verbatim from api.php's action switch.
 * It runs in the request's global scope via velora_api_handler()
 * (includes/api-handlers.php), so $pdo, $_SESSION, req_*(), jresp()
 * and log_action() behave exactly as they did inside the switch.
 * Each case-terminating `break;` became `return;`; jresp() exits on
 * its own, so the return only matters where the original break was.
 */

/* ---- send_otp ----
   The customer's door. Everything that happens after the number is validated
   — the hourly cap for that number, the gateway call, the digest, the row —
   lives in otp_deliver(), because the panel's login performs exactly the same
   steps and two copies of a code path that sends SMS and writes credentials
   is two code paths that drift. What stays here is what is specific to this
   door: the per-IP budget and the shape of the answer. */
if ($action === 'send_otp') {
csrf_check();
if (!rate_limit('otp', 3, 60)) {
    jresp(['ok' => false, 'error' => 'RATE_LIMIT', 'message' => 'لطفاً ۶۰ ثانیه صبر کنید'], 429);
}
$phone = normalize_phone(req_str('phone'));
if (!$phone) {
    jresp(['ok' => false, 'error' => 'PHONE_INVALID', 'message' => 'شماره معتبر نیست'], 400);
}

if (!rate_limit('otp_phone_hour', 5, 3600, $phone)) {
    log_action('OTP_PHONE_HOURLY_CAP', ['phone' => $phone]);
    jresp([
        'ok'      => false,
        'error'   => 'RATE_LIMIT',
        'message' => 'تعداد درخواست‌های این شماره زیاد است — بعداً تلاش کنید',
    ], 429);
}

$r = otp_deliver($pdo, $phone);
jresp($r['body'], $r['status']);
    return;
}

/* ---- verify_otp ---- */
if ($action === 'verify_otp') {
csrf_check();
if (!rate_limit('verify', 8, 60)) {
    jresp(['ok' => false, 'error' => 'RATE_LIMIT'], 429);
}
$phone = normalize_phone(req_str('phone'));
/* normalize_digits, like every other numeric field on the wire.

   This was the only one that did not: `/^\d{4,10}$/` is ASCII-only, so a code
   typed on a Persian keyboard — which is what `inputmode="numeric"` produces
   for a customer whose keyboard is Persian — arrived as «۱۲۳۴» and was refused
   with INVALID_INPUT before any comparison against the stored digest. js/auth.js
   folds with asciiDigits() before submitting, which is why it worked in the
   browser and this was invisible; the failure only appeared for a client that
   did not go through that path.

   The server has to agree with itself: the digest was minted from a normalized
   code, so an un-normalized one can never match it regardless. */
$code  = trim(normalize_digits(req_str('code')));
if (!$phone || !preg_match('/^\d{4,10}$/', $code)) {
    jresp(['ok' => false, 'error' => 'INVALID_INPUT'], 400);
}

if (!rate_limit('otp_attempt', 5, 900, $phone)) {
    log_action('OTP_PHONE_LOCKED', ['phone' => $phone]);
    jresp([
        'ok'      => false,
        'error'   => 'PHONE_LOCKED',
        'message' => 'تلاش بیش از حد برای این شماره — ۱۵ دقیقه صبر کنید',
    ], 429);
}

$st = $pdo->prepare("SELECT id, code FROM velora_otp WHERE phone=? AND used=0 AND expires_at > ? ORDER BY id DESC LIMIT 1");
$st->execute([$phone, time()]);
$matched = $st->fetch();

if (!$matched || !otp_matches($phone, $code, (string) $matched['code'])) {
    log_action('OTP_INVALID', ['phone' => $phone]);
    jresp(['ok' => false, 'error' => 'OTP_INVALID', 'message' => 'کد نامعتبر یا منقضی شده'], 401);
}
rate_limit_reset('otp_attempt', $phone);
$pdo->prepare("UPDATE velora_otp SET used=1 WHERE id=?")->execute([(int) $matched['id']]);

/* ── Two different things share this one OTP challenge ────────────
   Signing in, and adding a second number to an account that is
   already signed in. They look identical from here — a phone and a
   code — and they are told apart by `intent`, which is why the
   client must send it. Getting this wrong is the bug the whole
   phone feature exists to prevent: without the branch, verifying a
   code for someone else's number while signed in would silently log
   you in as them. */
$intent = req_str('intent');

if ($intent === 'add_phone') {
    if (!is_user()) {
        jresp(['ok' => false, 'error' => 'LOGIN_REQUIRED',
               'message' => 'برای افزودن شماره باید وارد حساب خود شوید'], 401);
    }
    require_addressbook();
    if ($phone === (current_user_phone() ?? '')) {
        jresp(['ok' => false, 'error' => 'PHONE_ALREADY_PRIMARY',
               'message' => 'این همان شمارهٔ اصلی حساب شماست'], 400);
    }
    $st = $pdo->prepare("SELECT id FROM velora_users WHERE phone=? LIMIT 1");
    $st->execute([$phone]);
    if ($st->fetchColumn() !== false) {
        /* The number is somebody's *login*. Registering it here
           would make this account able to deliver to, and be
           reached as, an identity that already exists elsewhere. */
        jresp(['ok' => false, 'error' => 'PHONE_TAKEN',
               'message' => 'این شماره به حساب دیگری تعلق دارد'], 409);
    }
    user_phone_remember(current_user_id(), $phone);
    $pdo->prepare("UPDATE velora_user_phones SET last_used_at=NOW() WHERE user_id=? AND phone=?")
        ->execute([current_user_id(), $phone]);
    log_action('PHONE_ADDED', ['user_id' => current_user_id(), 'phone' => $phone]);
    jresp([
        'ok'      => true,
        'message' => 'شمارهٔ همراه تأیید و ذخیره شد',
        'phone'   => $phone,
        'intent'  => 'add_phone',
    ]);
    return;
}

$st = $pdo->prepare("SELECT id, name FROM velora_users WHERE phone=? LIMIT 1");
$st->execute([$phone]);
$user = $st->fetch();
if (!$user) {
    $pdo->prepare("INSERT INTO velora_users (phone) VALUES (?)")->execute([$phone]);
    $uid = (int) $pdo->lastInsertId();
    $uname = null;
} else {
    $uid = (int) $user['id'];
    $uname = $user['name'] ?? null;
    $pdo->prepare("UPDATE velora_users SET last_seen=NOW() WHERE id=?")->execute([$uid]);
}

session_regenerate_id(true);
$_SESSION['csrf']    = bin2hex(random_bytes(32));
$_SESSION['csrf_at'] = time();

$_SESSION['user_id']     = $uid;
$_SESSION['user_phone']  = $phone;
$_SESSION['user_at']     = time();
/* The login number is proven-owned by definition — the customer
   just entered a code sent to it — so it becomes the primary entry
   in the verified set. Without this, an account that has only ever
   signed in would have an empty phone list and checkout would have
   nothing to prefill.

   Both writes are guarded. They run *after* the session is already
   established, but an uncaught exception here would still reach the
   client as a 500 and the customer would believe the sign-in failed
   when it in fact succeeded — then they would tap the code again and
   the OTP would already be spent. A booking write must never be able
   to contradict a login that worked. */
user_phone_remember($uid, $phone);
if (velora_addressbook_ready()) {
    try {
        $pdo->prepare("UPDATE velora_user_phones SET is_primary=1, last_used_at=NOW()
                       WHERE user_id=? AND phone=?")->execute([$uid, $phone]);
    } catch (Throwable $e) {
        log_action('PHONE_PRIMARY_FAIL', ['user_id' => $uid, 'error' => $e->getMessage()]);
    }
}
log_action('USER_LOGIN', ['user_id' => $uid, 'phone' => $phone]);
jresp([
    'ok'      => true,
    'message' => 'ورود موفق',
    'user_id' => $uid,
    'phone'   => $phone,
    'name'    => $uname,
    'csrf'    => $_SESSION['csrf'],
]);
    return;
}

/* ---- logout ---- */
if ($action === 'logout') {
if (empty($_SESSION['user_id'])) {
    jresp(['ok' => true, 'message' => 'خروج موفق', 'already' => true]);
}
csrf_check();
/* session_end() is the shared implementation — contents, cookie and server-side
   file. It was written here, inline, and the admin logout never got a copy of
   it, which is how one of the two sign-outs in this application ended a session
   and the other only cleared a flag. */
session_end();
jresp(['ok' => true, 'message' => 'خروج موفق']);
    return;
}

/* ---- me ----
   200, not 401, for an anonymous visitor.

   `me` is a session PROBE, not a protected resource: the question is "is there a
   signed-in user on this session?", and "no" is a complete and successful answer
   to it. 401 means "present credentials, and they were rejected or absent" —
   which is a statement about access to a resource, and there is no resource here
   that anyone is being kept out of.

   The 401 was visible on every anonymous page load: js/auth.js and
   js/checkout.js both call sessionGet() at boot, so every visitor who is not
   signed in — that is, every first visit — got a red 401 in the console from the
   one endpoint that was answering correctly. Any monitoring or session-replay
   tool reading the browser log counts it as a failed request.

   Nothing on the client branches on this status: sessionGet() reads r.logged,
   and checkout.js wraps the call in try/catch. So this is the same JSON, the
   same meaning, and one less false error.

   The endpoints that DO protect something — my_orders, address_*, checkout —
   keep their 401, because there the status is the answer. */
if ($action === 'me') {
if (!is_user()) {
    jresp(['ok' => true, 'logged' => false]);
}
/* Signed in, and there is no handle to confirm who this is. DB_FAIL, not
   {logged:false}: the visitor IS signed in, and answering "not signed in"
   would have sessionGet() read them out of their own account the next time it
   looked. This is the branch api.php's allow-list does not cover — the list
   exists so the anonymous case above, every first page load, answers 200 with
   no connection at all. */
if (!($pdo instanceof PDO)) {
    $down = velora_db_down() ?? [
        'error'   => 'DB_FAIL',
        'message' => 'اتصال به پایگاه داده برقرار نشد.',
    ];
    jresp(['ok' => false, 'error' => $down['error'], 'message' => $down['message']], 500);
}
$st = $pdo->prepare("SELECT id, phone, name, email, created_at FROM velora_users WHERE id=?");
$st->execute([current_user_id()]);
$user = $st->fetch();
/* A session that names a user_id the table does not contain is a stale session,
   not a missing product: answering 404 told the client the account was gone,
   which is a different and much more alarming claim than "that row is gone".
   Clearing the identity and answering "not signed in" lets auth.js fall back to
   the sign-in sheet instead of surfacing a not-found state nobody can act on. */
if (!$user) {
    unset($_SESSION['user_id'], $_SESSION['user_phone'], $_SESSION['user_phone_verified']);
    jresp(['ok' => true, 'logged' => false]);
}
jresp([
    'ok'     => true,
    'logged' => true,
    'user'   => $user,
    /* Whether this session is the administrator's.

        The client reads it to decide whether to offer the «پنل مدیریت» button,
        and derived that flag from a field this response did not carry — so it was
        permanently false and the operator never saw the link to the one screen
        they could use. The value is the same is_admin() every other door checks;
        it authorises nothing on its own (admin.php gates itself again), it only
        lets the storefront stop hiding a control from the person entitled to it. */
    'admin'  => is_admin(),
]);
    return;
}

