<?php
declare(strict_types=1);
/**
 * VELORA · Session-auth helpers
 *
 * Extracted verbatim from config.php during the monolith split — same code,
 * same behaviour, one home per concern. Covers is_admin(), is_user(), current_user_id() and current_user_phone().
 */
if (!defined('VELORA_CONFIG_LOADED')) {
    http_response_code(500);
    exit('includes/auth.php requires config.php to be loaded first.');
}

/**
 * Is this session the administrator's?
 *
 * There is no clock in here, and that is the point. It used to compare
 * admin_login_at against ADMIN_SESSION_TTL, so the panel logged the operator
 * out two hours after they signed in whether or not they had ever stopped
 * working — a timeout that bought nothing, because the credential was already
 * proven and the session id had already been regenerated on login.
 *
 * A session is the administrator's from the moment admin_otp_verify() sets
 * `admin` and stops being one when «خروج امن» unsets it. ADMIN_SESSION_TTL
 * still exists, but it now bounds only what the *server* keeps (the idle
 * session file) and what the admin cookie survives — see the config notes on
 * that constant. Nothing here expires a session that nobody has abandoned.
 *
 * `admin_login_at` is still written: it is the timestamp in the login log
 * line and the one the panel shows, and it costs nothing to keep a fact.
 */
function is_admin(): bool {
    if (empty($_SESSION['admin']) || $_SESSION['admin'] !== true) return false;

    /* An ABSOLUTE cap, distinct from the idle one in is_admin_idle_expired().
       The requirement is "until they log out", and that has to mean something
       even when the operator closes the lid and comes back a week later.

       It is the cookie lifetime, so it is not decorative: without a check here,
       a session cookie stolen from an unattended machine stays a valid admin
       credential for as long as the server keeps the file — thirty days by
       default. This bounds it to the same thirty days explicitly and, more
       usefully, records the expiry so the panel can tell the operator why they
       were signed out instead of silently rendering as signed-out. */
    $age = time() - (int) ($_SESSION['admin_login_at'] ?? 0);
    if ($age > ADMIN_SESSION_TTL) {
        session_end();
        return false;
    }

    /* Idle bound, well inside the absolute one. An operator who has genuinely
       stepped away for eight hours has, in every sense that matters, left the
       panel; an unlocked laptop is the case this exists for. It is separate
       from the absolute cap because "nobody has touched this for a while" and
       "this login is old" are different questions and want different numbers. */
    $idle = time() - (int) ($_SESSION['admin_seen_at'] ?? 0);
    if ($idle > ADMIN_SESSION_IDLE_TTL) {
        session_end();
        return false;
    }

    $_SESSION['admin_seen_at'] = time();
    return true;
}

/**
 * Make the current session survive a browser restart.
 *
 * config.php issues the session cookie with `lifetime => 0`, which means
 * "this browser session" — closing the window ends the session, and an
 * operator who shuts their laptop at 18:00 and opens it at 09:00 is signed
 * out. That is correct for a customer and wrong for the one session the
 * requirement is "until they log out".
 *
 * Called before session_regenerate_id() in the admin login, so the Set-Cookie
 * that carries the new id already carries this lifetime; the explicit
 * setcookie() after it is the same values written again, because the
 * regenerate's header is the one thing this function must not leave to
 * chance. The GC window on the server side is raised to match in config.php —
 * a 30-day cookie pointing at a file PHP collected after two hours is a
 * longer cookie that does nothing.
 */
function admin_session_make_persistent(): void {
    $p    = session_get_cookie_params();
    $life = (int) ADMIN_SESSION_TTL;
    if ($life <= 0) return;

    session_set_cookie_params([
        'lifetime' => $life,
        'path'     => $p['path'] !== '' ? $p['path'] : '/',
        'domain'   => (string) $p['domain'],
        'secure'   => (bool) $p['secure'],
        'httponly' => (bool) $p['httponly'],
        'samesite' => $p['samesite'] !== '' ? $p['samesite'] : 'Lax',
    ]);
}

/** Emit the persistent cookie for the id that is current *now*. */
function admin_session_emit_cookie(): void {
    $p    = session_get_cookie_params();
    $life = (int) ADMIN_SESSION_TTL;
    if ($life <= 0) return;
    setcookie(session_name(), session_id(), [
        'expires'  => time() + $life,
        'path'     => $p['path'] !== '' ? $p['path'] : '/',
        'domain'   => (string) $p['domain'],
        'secure'   => (bool) $p['secure'],
        'httponly' => (bool) $p['httponly'],
        'samesite' => $p['samesite'] !== '' ? $p['samesite'] : 'Lax',
    ]);
}
function is_user(): bool {
    if (empty($_SESSION['user_id']) || (int) $_SESSION['user_id'] <= 0) return false;

    /* The session clock, which nothing was reading.
       `user_at` is written at every successful sign-in and this is its only
       reader. Without it SESSION_TTL — the documented two-hour storefront
       session — was a constant nothing consulted, and the real lifetime was
       whatever session.gc_maxlifetime happened to be. That is
       max(SESSION_TTL, ADMIN_SESSION_TTL), because PHP cannot collect an
       admin session differently from a customer's, so the admin's 30-day
       window silently applied to everyone: a customer who signed in on a café
       machine, a shared kiosk or a borrowed laptop was still fully
       authenticated — my_orders, address_list, checkout — for a month.

       Two bounds, because "still here after a fortnight" and "left the tab
       open overnight" are different claims. */
    $idle = time() - (int) ($_SESSION['user_at'] ?? 0);
    if ($idle > SESSION_TTL) {
        session_end();
        return false;
    }

    /* A live session slides forward. Every authenticated endpoint opens with an
       is_user() check, so putting the refresh here makes "two hours since the
       customer last did something" true by construction — no endpoint can be
       written that forgets to extend it, which is exactly the mistake a
       per-endpoint touch would invite. */
    $_SESSION['user_at'] = time();
    return true;
}

function current_user_id(): int { return (int) ($_SESSION['user_id'] ?? 0); }
function current_user_phone(): ?string { return $_SESSION['user_phone'] ?? null; }

/**
 * Push the idle window forward.
 *
 * Called at the points where a request proves the session is still in use, so
 * SESSION_TTL means "two hours since the customer last did something" rather
 * than "two hours since they logged in" — the latter logs out somebody who has
 * been reading for an evening, which is the same complaint the admin timeout
 * was removed for.
 */
function user_session_touch(): void {
    if (!empty($_SESSION['user_id'])) $_SESSION['user_at'] = time();
}

/**
 * End this session completely: contents, cookie, server-side file.
 *
 * One implementation because signing out had two, and only one of them was
 * complete.
 *
 * The customer logout emptied $_SESSION, expired the cookie and called
 * session_destroy(). The admin logout unset three keys and stopped.
 *
 * That is not equivalent when the admin session is the one being ended, because
 * admin_session_make_persistent() gave this session a cookie with a 30-day
 * expiry (ADMIN_SESSION_TTL). Unsetting the keys removes the *privilege*, but
 * leaves the session id itself valid and the cookie still scheduled to be sent
 * for a month. The session file on the server stays alive for the same window,
 * because session.gc_maxlifetime was raised to match. What «خروج امن» actually
 * produced was "your admin flag is gone" — not "this session is over".
 *
 * The gap that leaves is session-fixation-shaped rather than privilege-shaped:
 * the operator believes they signed out, the id in their browser is still
 * presented on every subsequent request, and anything that later writes `admin`
 * back into that same session — another tab, a re-auth on the storefront — is
 * promoted into the panel without a fresh login.
 *
 * Order matters here and is the same order the customer logout already used:
 * drop the contents first so nothing can read them, expire the cookie so the
 * browser stops presenting the id, then destroy the file.
 */
function session_end(): void {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }

    session_destroy();
}
