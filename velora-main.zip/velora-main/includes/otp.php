<?php
declare(strict_types=1);
/**
 * VELORA · OTP code storage
 *
 * Extracted verbatim from config.php during the monolith split — same code,
 * same behaviour, one home per concern. Covers velora_mac_key(), otp_digest() and otp_matches() — the keyed-digest storage for one-time codes.
 */
if (!defined('VELORA_CONFIG_LOADED')) {
    http_response_code(500);
    exit('includes/otp.php requires config.php to be loaded first.');
}

function velora_mac_key(string $purpose): string {
    $secret = env('VELORA_APP_KEY', '');
    if ($secret === null || $secret === '') {
        $secret = (string) DB_PASS;
    }
    return hash_hmac('sha256', 'velora:' . $purpose, $secret, true);
}

function otp_digest(string $phone, string $code): string {
    return hash_hmac('sha256', 'otp:' . $phone . ':' . $code, velora_mac_key('otp'));
}

function otp_matches(string $phone, string $code, string $storedDigest): bool {
    if ($storedDigest === '' || $code === '') return false;
    return hash_equals($storedDigest, otp_digest($phone, $code));
}

/**
 * Is this a request that is allowed to SEE the code itself?
 *
 * ONE GUARD, THREE USES — and that is the entire point of the function.
 *
 * The mint path and the response path below each used to carry their own copy
 * of "is this a development machine", and the two copies were not the same
 * test. The mint path asked for OTP_DEBUG *and* loopback; the response path
 * asked only for OTP_DEBUG. So on a machine with a real gateway configured and
 * VELORA_OTP_DEBUG left switched on — which config.php reports as a startup
 * problem rather than refusing to boot — the code was minted by MeliPayamak,
 * delivered by SMS to the account owner, and then handed back in the JSON
 * response to whoever had asked for it. Anyone could request a login for any
 * phone number and receive the code that had just been texted to its owner.
 *
 * That is not a debug affordance with a sharp edge. It is account takeover on
 * any number in the country, and the only thing standing between a production
 * build and it was a line in a startup log that nobody reads until after the
 * incident. .env.example has always promised "the dev OTP is then accepted
 * only from loopback"; this is the single place that promise is now actually
 * kept, and there is exactly one of it.
 *
 * Loopback is checked, never a header. SERVER_ADDR cannot be forged by a
 * client, and the request has to originate from the machine the app is on —
 * a build opened from another machine on the LAN, which is how most of these
 * are developed, gets nothing.
 */
function otp_debug_visible(): bool {
    return OTP_DEBUG && velora_server_is_loopback();
}

/**
 * Send a one-time code to a phone and store it — the whole SMS step, once.
 *
 * The storefront's `send_otp` and the panel's `admin_otp_send` are two doors
 * into the same room: one gateway, one table, one digest, one set of limits
 * on how often a *number* may be written to. Each door keeps its own IP
 * budget (a customer hammering the shop must not be able to spend the
 * operator's allowance, and the operator's login must not be reachable at
 * customer rates), and everything below that line is shared, because it was
 * already the same code written twice.
 *
 * It returns a status and a body instead of calling jresp(), so each caller
 * can say whatever it was going to say — the panel's answer deliberately does
 * not depend on whether the number was the administrator's (see
 * admin_otp_send), and only the caller knows that.
 *
 * @param PDO    $pdo   connection; every caller is a DB-backed action
 * @param string $phone already-normalised 09xxxxxxxxx
 * @return array{status: int, body: array<string, mixed>}
 */
function otp_deliver(PDO $pdo, string $phone): array {
    /* MeliPayamak's /api/send/otp/{token} endpoint generates the OTP itself and
       returns it in the response `code` field. There is no local code to
       compute — whoever receives it gets whatever the panel decided, and we
       store exactly that value. */
    $st = $pdo->prepare("SELECT COUNT(*) FROM velora_otp WHERE phone=? AND created_at > NOW() - INTERVAL 60 SECOND");
    $st->execute([$phone]);
    if ((int) $st->fetchColumn() > 0) {
        return ['status' => 429, 'body' => [
            'ok' => false, 'error' => 'RATE_LIMIT', 'message' => 'کد قبلاً ارسال شده است',
        ]];
    }

    /* Local development has nobody to ask. VELORA_MELI_API is empty on a fresh
       clone, and without a fallback here neither a customer nor the
       administrator can log into the thing they are developing — while the one
       step the flow exists to prove is exactly the one being withheld.
       .env.example has always promised this ("The dev OTP is then accepted
       only from loopback"); this is that promise, and it is two conditions
       deep: OTP_DEBUG, which config.php reports as a startup problem in
       production, and a request from loopback, so a dev build opened from
       another machine on the same LAN can never be logged into with a code
       printed in a response body.

       The code is minted and stored exactly like a delivered one — same
       digest, same TTL, same table, same one-live-code-per-number rule — so
       verify cannot tell that anything happened differently. */
    /* Four digits, because four is what the UI can accept.

       This minted `random_int(100000, 999999)` — six digits — and was handed
       straight back in the response body on the loopback debug path. Every OTP
       field in this application is exactly four boxes: admin.php renders four
       `.otp-box` inputs, and js/auth.js refuses to submit below four, caps a
       paste at four, and fires verifyOTPFlow the moment the fourth is filled.
       A six-digit code is un-enterable there in three separate ways, so the one
       configuration that exists precisely so a developer can log in without an
       SMS gateway could not be logged into.

       The server's own contract is `/^\d{4,10}$/` on both verify paths, so
       six digits was accepted by the verifier and rejected by the only client
       that can produce one. Meli's real codes are unaffected either way. */
    $sent = (otp_debug_visible() && MELI_API === '')
        ? ['ok' => true, 'otp' => (string) random_int(1000, 9999), 'gateway' => 'loopback']
        : meli_send_otp($phone);
    $code = (string) ($sent['otp'] ?? '');

    if (!$sent['ok']) {
        if (otp_debug_visible()) {
            log_line('[OTP_DEBUG] send failed for ' . log_safe($phone)
                . ': ' . log_safe((string) json_encode($sent, JSON_UNESCAPED_UNICODE)));
        }
        log_action('OTP_SEND_FAIL', [
            'phone'   => $phone,
            'error'   => $sent['error'] ?? 'unknown',
            'http'    => $sent['http'] ?? null,
            'status'  => $sent['status'] ?? null,
            'gateway' => $sent['gateway'] ?? null,
        ]);
        $why = 'ارسال پیامک ناموفق بود';
        if (!empty($sent['status'])) {
            $why .= ' · ' . $sent['status'];
        }
        return ['status' => 502, 'body' => ['ok' => false, 'error' => 'SMS_FAIL', 'message' => $why]];
    }

    if ($code === '') {
        log_action('OTP_EMPTY_CODE', ['phone' => $phone, 'gateway' => $sent['gateway'] ?? null]);
        return ['status' => 502, 'body' => ['ok' => false, 'error' => 'SMS_FAIL', 'message' => 'ارسال پیامک ناموفق بود']];
    }

    log_action('OTP_SENT', [
        'phone'    => $phone,
        'status'   => $sent['status'] ?? null,
        'code_len' => strlen($code),
    ]);

    /* One live code per number: issuing a second invalidates the first, so a
       resend cannot leave two valid codes in the table for the same phone. */
    $pdo->prepare("UPDATE velora_otp SET used=1 WHERE phone=? AND used=0")->execute([$phone]);

    $st = $pdo->prepare("INSERT INTO velora_otp (phone, code, ip, expires_at) VALUES (?, ?, ?, ?)");
    $st->execute([
        $phone,
        otp_digest($phone, $code),
        get_client_ip(),
        time() + OTP_TTL,
    ]);

    $body = [
        'ok'      => true,
        'message' => 'کد تأیید ارسال شد',
        'ttl'     => OTP_TTL,
    ];
    /* The code, and only ever on a loopback request in a build that asked for
       it. See otp_debug_visible(): this used to be gated on OTP_DEBUG alone,
       which meant a production build with the flag left on returned the real
       delivered code to its caller. */
    if (otp_debug_visible()) $body['debug_code'] = $code;
    return ['status' => 200, 'body' => $body];
}
