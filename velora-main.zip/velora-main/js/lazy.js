/* ═══════════════════════════════════════════════════════════════════════════
   THE DIALOG LAZY LOADER
   ═══════════════════════════════════════════════════════════════════════════
   Eight of the twenty-nine assets on the page are dialog modules: they exist to populate and
   drive one overlay that is closed when the page arrives. Loading them with the
   first paint costs 54 KB of gzip that the customer cannot see, cannot use,
   and — on a connection where the interactive time is what they are judging —
   is waiting behind everything they can.

   The rule this module implements: a dialog's code is fetched the first time
   something asks for the dialog, and awaited before that dialog is opened.

   FOUR THINGS THIS DOES NOT DO, each of which would be a regression:

   · IT DOES NOT SWAP IN A STUB. `window.AE_PDP` stays undefined until the real
     module has evaluated. A stub that answers `openPDP()` with nothing is a
     button that does nothing, which is the fault this whole refactor exists to
     remove — and main.js already guards two of its own call sites for exactly
     that shape. An absent namespace is honest; a lying one is not.

   · IT DOES NOT RACE. Every call site goes through `when(...)`, which returns
     the same promise for concurrent callers, so three quick taps on "bag" issue
     one fetch rather than three. `script` elements are idempotent in most
     engines and race in others, and a module that evaluates twice registers
     its listeners twice — which is how a dialog ends up opening two.

   · IT DOES NOT RUN BEFORE THE DOCUMENT IS READY. Modules here read the DOM at
     evaluation time. A fetch resolving before DOMContentLoaded would execute
     them against a half-built page, and the failure would surface as a dialog
     with no close button.

   · IT DOES NOT PREFETCH ON IDLE for the ones that are a click away. It does,
     once, at requestIdleCallback — which is the difference between using the
     network the browser is already sitting on and competing with the thing the
     customer is reading.

   Why these eight and not the others: core, data, bridge, state, ui, cart,
   renderers and main are needed for the first paint or for the first
   interaction. quality-gov must be early — the DPR decision it takes is read by
   everything that draws. intel is cheap and improves the first render. That
   leaves exactly the modules whose only entry point is an overlay. */

(function () {
  'use strict';

  /* One map from index.php: path → filemtime. It is one map rather than a list
     plus a versions table because the loader needs both together to build a
     URL, and two parallel structures is how a path ends up in one and not the
     other. index.php is the only place that knows the version rule, so the
     value is already the number the loader has to append. */
  var MAP = window.VELORA_LAZY_MAP || {};

  var MODULES = {
    AE_PDP:     'js/pdp-aurelle.js',
    AE_LBX:     'js/lbxaurelle.js',
    AE_CKO:     'js/checkout.js',
    AE_AUTH:    'js/auth.js',
    AE_CONC:    'js/concierge-aurelle.js',
    AE_ATELIER: 'js/atelier-aurelle.js',
  };

  var started = null;
  var domReady = false;
  var waiting = [];

  function ready() {
    if (domReady) return Promise.resolve();
    return new Promise(function (res) {
      function go() { domReady = true; res(); }
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go, { once: true });
      else go();
    });
  }

  function inject(src) {
    /* The cache-busting query, from the same source as every other asset. An
       unversioned lazy request is the one URL on the page the service worker has
       no way to revalidate, so a fixed module stays fixed for a year. */
    var v = MAP[src];
    var url = v ? src + '?v=' + v : src;
    var s = document.createElement('script');
    s.src = url;
    s.async = false;          // order within a batch must hold
    /* NO crossOrigin here — deliberately removed.

       Every lazy module is served from 'self', and the eager <script defer>
       tags in index.php correctly omit it. Setting crossOrigin='anonymous'
       puts a same-origin request into CORS mode, which changes its cache mode
       and makes the browser perform a CORS check against the response — and
       this server sends no Access-Control-Allow-Origin. So eager and lazy
       assets were being fetched under two different request modes for the same
       origin, which is exactly the preload/cors mismatch class of bug that
       index.php warns about at length for the stylesheets.

       It is also a wasted header on a same-origin request. If a module ever
       does need to come from another origin, that module needs its own
       decision, not a blanket one applied to all eight. */
    return new Promise(function (res, rej) {
      s.onload = function () { res(); };
      s.onerror = function () { rej(new Error('module failed: ' + url)); };
      document.head.appendChild(s);
    });
  }

  /* One fetch per file, ever. The promise is memoised on the map itself, so a
     second caller awaiting the same namespace gets the same in-flight promise
     and not a second <script>. */
  var inflight = {};

  function when(ns) {
    if (window[ns]) return Promise.resolve(window[ns]);
    var src = MODULES[ns];
    if (!src) return Promise.reject(new Error('no lazy module for ' + ns));

    if (!inflight[src]) {
      inflight[src] = ready()
        .then(function () { return inject(src); })
        /* The cache is cleared on failure so a later attempt can retry. Leaving
           a rejected promise in the map would make one transient network error
           permanent for the rest of the session. */
        .catch(function (err) { delete inflight[src]; throw err; });
    }
    return inflight[src].then(function () { return window[ns]; });
  }

  /* Fetch a batch, ignoring order. Used for the idle prefetch, where two dialogs
     are worth warming together and neither is waiting on the other. */
  function warm(list) {
    return Promise.all(list.map(function (ns) {
      return when(ns).catch(function () { return null; });
    }));
  }

  window.AE_LAZY = {
    when: when,
    warm: warm,
    has: function (ns) { return !!window[ns]; },
    /* Exposed for the four modules that attach behaviour with no namespace of
       their own. Nothing calls them before the customer does, and nothing on
       the first paint does either. */
    whenScript: function (src) {
      if (!inflight[src]) {
        inflight[src] = ready().then(function () { return inject(src); })
          .catch(function (err) { delete inflight[src]; throw err; });
      }
      return inflight[src];
    },
  };

  /* ── The idle prefetch ───────────────────────────────────────────────────
     One batch, at the browser's own idle moment, at low priority. The three
     named are the dialogs a customer opens by choice — the bag, the wishlist
     and their account — so they are the three most likely to be asked for. The
     PDP is deliberately NOT here: it is behind a click on a product card, which
     costs a page's worth of scrolling to reach, and its bytes are better spent
     on the first paint.

     requestIdleCallback with a timeout, because Safari has shipped it for years
     but it is still absent in enough places that its absence should degrade to
     a timeout rather than to nothing. */
  function prefetch() { warm(['AE_CKO', 'AE_AUTH', 'AE_LBX']); }

  if (typeof requestIdleCallback === 'function') {
    requestIdleCallback(prefetch, { timeout: 2500 });
  } else {
    setTimeout(prefetch, 2500);
  }

  /* The same batch, on a fast connection, as soon as the document is usable.
     requestIdleCallback above covers the desktop case where the main thread is
     busy; this covers the case where it is not and the idle callback fires
     after the customer has already clicked. */
  addEventListener('load', function () {
    if (navigator.connection && /4g|3g/.test(navigator.connection.effectiveType || '')) prefetch();
  }, { once: true });

  /* ── What this file no longer does ───────────────────────────────────────
     There was a `data-need="AE_CKO"` wiring layer here: a delegated
     capture-phase click listener and a keydown listener that would fetch a
     namespace, mark the trigger busy, then re-dispatch the click so main.js's
     own handler ran with the module present. Fifty-six lines, and it was
     correct.

     It was also unreachable. No element in index.php, admin.php, any
     renderer or any template literal has ever carried a `data-need` attribute —
     every lazy load on this site goes through an explicit need(...) in main.js,
     which is the more robust path anyway because it is typed against the
     namespace rather than against a string in the markup.

     What it cost was real: a capture-phase listener on `document` runs
     `closest()` on EVERY click and EVERY Enter/Space on the page, for the life
     of the document, in order to match an attribute that is not there. Two
     listeners, permanently, to serve nothing.

     And what it bought was a second way to spell the same thing — which is the
     drift this file's own header warns about. `AE_ATELIER` is still mapped in
     MODULES below, reachable only through this path, and therefore dead for
     the same reason.

     If the wiring is ever wanted back, it belongs as a documented extension
     rather than as infrastructure: one element with the attribute, one
     listener, and a decision about which of the two paths owns the action. */
})();
