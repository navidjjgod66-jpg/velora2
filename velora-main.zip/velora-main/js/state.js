/* ═══════════════════════════════════════════════════════════════════════
   MAISON AURELLE — state.js
   State · Persistence · Cart math · Smart score
   ═══════════════════════════════════════════════════════════════════════ */
(() => {
'use strict';
const { LS, K, clamp } = window.AE;
const { CATALOG, ORDER, PRODUCTS, PROMO, MAX_PER_LINE } = window.AE_DATA;

/* ═══ Personal profile (fit data) ═══ */
const P = Object.assign(
  { foot:null, use:null, arch:null, style:null, size:null,
    dna:{ minimal:50, classic:50, bold:50, romantic:50, casual:50 } },
  LS.get(K.dna, {})
);
const saveP = () => LS.set(K.dna, P);

/* ═══ Runtime state ═══ */
const savedPromo = LS.get(K.promo, null);
const state = {
  cart:   LS.get(K.bag, []).filter(i => CATALOG[i.id]),
  wish:   LS.get(K.wish, []).filter(id => CATALOG[id]),
  /* priceMax is null, which means "no ceiling".

     It was the literal 30000000, and that number was the catalogue's most
     expensive shoe on the day it was written. Nothing kept it true. The
     collection moved on and the constant did not, so every product priced above
     30,000,000 failed the test in main.js's apply() and was hidden — five of
     the eleven, including the four most expensive pieces the maison makes, at
     31.0M, 34.2M, 38.7M, 41.5M and 44.6M.

     Nothing in the interface reported it. There is no price control, no
     "showing 6 of 11", no empty state: the shop simply opened with the
     top half of its collection missing, and the most valuable pieces in a
     maison — the ones a customer arrived for — were the ones absent. It failed
     silently because `hidden` is silent, and it survived because the number
     was plausible: nobody reading 30000000 in a file of Toman prices suspects
     it is a stale snapshot of a business decision.

     null is the honest value for a filter nobody can change. A ceiling that no
     control moves must not be capable of hiding anything, and `!state.priceMax`
     short-circuits the comparison entirely, so there is no longer a number here
     that can disagree with the catalogue. If a real price filter is ever built,
     it sets this from a control and the test below already does the right thing. */
  /* The shop's filter state. One owner (main.js's toolbar), one consumer
     (apply()), and every field defaults to "no constraint" so a control that
     is never touched can hide nothing — the lesson of priceMax above: a
     filter default that excludes anything is a bug the interface cannot see.

       · cats    Set of category slugs ('heel','boot',…). Empty = all.
                 Multi-select, ANDed with the other facets.
       · heelMin/heelMax  Millimetre band, null = open end. Derived from the
                 live catalogue in main.js, never hard-coded.
       · colors  Set of colour keys. Empty = all.
       · sizes   Set of EU size strings. Empty = all. A product passes only if
                 it has stock in at least one selected size — the same rule
                 api.php enforces at order time, so a card that survives the
                 filter can always be bought in that size.
       · priceMin  null = no floor; otherwise keep price >= priceMin.
       · priceMax  null = no ceiling; otherwise keep price <= priceMax.
       · instock Only pieces ready in the atelier right now (stock > 0).
       · deals   Only marked-down pieces (a real oldPrice above price).
       · isNew   Only this season's reveals. */
  fam:'all', sort:'featured', q:'', priceMin:null, priceMax:null,
  cats:new Set(), heelMin:null, heelMax:null,
  colors:new Set(), sizes:new Set(),
  instock:false, deals:false, isNew:false,
  size:null, color:null, colorHex:'', pdpId:null, lastFocus:null,
  promo:  PROMO.valid(savedPromo) ? savedPromo : null,
  cmp:    []
};
if (!PROMO.valid(state.promo)) { state.promo = null; LS.set(K.promo, null); }

/* The per-line cap comes from the server (window.VELORA_MAX_LINE, published by
   index.php from MAX_LINE in config.php) because api.php clamps every order
   line to exactly that number. Taking the smaller of the two means the cart
   can never offer a quantity the server will reject.

   MAX_PER_LINE is the pre-boot / no-PHP fallback. It is validated rather than
   merely read: window.VELORA_MAX_LINE is reachable by another page on a shared
   host before our bundle parses, and a cap of 0 or a negative number silently
   produces a cart that cannot be filled. Declared before the persisted-cart
   sanitiser below, which needs it. */
const serverMax = Number(window.VELORA_MAX_LINE);
const MAX_LINE_UI = Number.isFinite(serverMax) && serverMax >= 1 && serverMax <= 999
  ? Math.floor(serverMax)
  : MAX_PER_LINE;

/* Stock helpers.

   Declared above the persisted-cart sanitiser because that sanitiser clamps to
   capFor(), and capFor is a const arrow — a const is in its temporal dead zone
   until its declaration is evaluated, so reaching for it from a block above
   throws a ReferenceError rather than returning undefined. Silently falling
   back to MAX_LINE_UI there would have looked like it worked. */
const stockOf = id => { const p = CATALOG[id]; return p ? Math.max(0, p.stock | 0) : 0; };

/* Stock for ONE size, or null when the product publishes no per-size stock.

   null and 0 are different answers and the difference decides whether the size
   can be offered at all: 0 means "this size is sold out", null means "this
   catalogue does not track sizes", which is the case for the demo fallback
   data. Callers must not conflate them.

   A cart line names a size, so a cap computed without one is a cap on the
   wrong number. See capFor(). */
const stockOfSize = (id, size) => {
  const p = CATALOG[id];
  if (!p) return 0;
  const sizes = Array.isArray(p.sizes) ? p.sizes : [];
  if (!sizes.length) return null;
  const row = sizes.find(s => s && String(s.eu != null ? s.eu : s) === String(size));
  if (!row) return 0;
  return Math.max(0, Number(row.stock) || 0);
};

/**
 * The most of this line the shop will actually sell.
 *
 * Passing the size is not an optimisation — it is the difference between a cart
 * the server accepts and one it refuses outright.
 *
 * The server checks stock per (product, eu_size) inside the checkout
 * transaction and throws INSUFFICIENT_STOCK for the whole order if any line
 * exceeds it. The cap this function used to compute ignored the size and read
 * `p.stock`, the product's TOTAL across every size. So a product with 11 pairs
 * left — 1 in size 41, 10 in size 38 — reported a cap of 5, the UI happily let
 * a customer build a 3-pair line of size 41, and the order was rejected at the
 * final request. Every other line in the basket went down with it, because the
 * server's transaction is all-or-nothing, and the customer's only remedy was to
 * find and remove the offending line by hand.
 *
 * With no size — the product-level question, used where there genuinely is no
 * size involved — the total is still the right answer.
 */
const capFor = (id, size) => {
  const s = (size === undefined || size === null) ? stockOf(id) : stockOfSize(id, size);
  if (s === null) return MAX_LINE_UI;   /* no per-size data: only the line cap applies */
  if (s <= 0) return 0;
  return Math.min(MAX_LINE_UI, s);
};

/* Sanitize persisted cart.

   Clamped to capFor(), not merely to MAX_LINE_UI: stock can have fallen since
   the cart was saved, and an order line above what is left makes api.php
   reject the ENTIRE order with INSUFFICIENT_STOCK. One stale line then costs
   the customer every other line in their basket, and the only remedy the UI
   offers is to remove the offending item by hand. Trimming it here is the
   difference between an order that goes through and a support ticket. */
/* Sanitize the cart against the current catalogue.

   Exported as a function rather than written once as an assignment, because it
   has to run again every time the catalogue is replaced — see below. */
function sanitiseCart() {
  state.cart = state.cart
    .filter(i => i && CATALOG[i.id] && typeof i.size === 'string')
    /* Lines whose stock has reached zero are DROPPED, not clamped.

       `capFor()` returns 0 when there is no stock left, and the `|| 1` that used
       to sit here turned that 0 into an upper bound of 1 — so a line for a
       product that had sold out while the basket sat in localStorage was
       quietly kept at quantity 1 instead of being removed. The customer's cart
       carried a line the shop could not fill, and api.php refused the ENTIRE
       order with INSUFFICIENT_STOCK from inside the transaction: one dead line
       cost them every other line in the basket, with nothing on screen saying
       which one was the problem.

       That is precisely the failure the block above exists to prevent, and it
       was the one case it did not prevent — a product with stock cannot be
       over the cap by much, but a product with NO stock is not "over the cap",
       it is gone. Filtering first is also what lets the clamp below lose its
       `|| 1` fallback and become the plain, honest "no more than what is left".
       The one thing lost is visibility, so the removal is announced below
       rather than being silent.

       Both the filter and the clamp are per SIZE, for the reason capFor()'s
       signature explains: the server's stock check is per (product, eu_size),
       so a line must be judged against the stock of the size it actually names. */
    .filter(i => capFor(i.id, i.size) > 0)
    .map(i => ({ ...i, qty: clamp(parseInt(i.qty, 10) || 1, 1, capFor(i.id, i.size)) }));
  state.wish = state.wish.filter(id => CATALOG[id]);
  return state.cart;
}

/* This ran once, at boot, and the one time it mattered most it was too late.

   sync-aurelle.js replaces CATALOG in place when the content hash changes —
   an admin retires a product or its stock falls while somebody has the shop
   open — and the boot-time sanitiser was never repeated. So the cart kept
   lines the new catalogue could not support:

   · a retired product stayed as a line, and itemsSum() prices an unknown id at
     0, so the bag showed the customer a 0-Toman row and api.php then refused
     the WHOLE order with INVALID_ITEM — one stale line costing every other
     line in the basket;
   · a product whose stock fell kept its quantity above the new cap. The
     stepper's "+" was correctly disabled, which is the tell: the UI knew the
     line was over the limit while the line itself was left over the limit.

   So the same two operations are re-run whenever the catalogue changes, from
   the listener below. It is deliberately a re-clamp and not a rebuild: the
   cart keeps its lines and its order, and only quantities are corrected to
   what the maison can actually make. Silently emptying somebody's basket
   because a stock figure moved would be worse than trimming one line. */
sanitiseCart();

const persBag  = () => LS.set(K.bag, state.cart);
const persWish = () => LS.set(K.wish, state.wish);
const getCustom = () => LS.get(K.custom, null);

/* ═══ Cart math ═══ */
const itemsSum = () => state.cart.reduce((s, it) => {
  const p = CATALOG[it.id];
  return s + ((p ? p.price : 0) || 0) * it.qty;
}, 0);

/* The discount honours the voucher's CAP.
   This used to be an uncapped `itemsSum() * pct / 100`, so on any basket above
   the cap it displayed a larger discount than the server would grant: VEL10
   stops at 5,000,000 and WELCOME10 at 3,000,000, and a two-pair order in this
   catalogue passes 18,000,000. The customer was shown the difference on the
   checkout summary and then charged the capped amount.
   The cap is published from velora_voucher_map(), so this arithmetic is now the
   arithmetic at the till rather than an optimistic guess at it. */
const discount = () => {
  const p = state.promo;
  if (!p || !p.pct) return 0;
  const raw = itemsSum() * p.pct / 100;
  const cap = Number(p.cap) || 0;
  return Math.round(cap > 0 ? Math.min(raw, cap) : raw);
};
const cartSum   = () => Math.max(0, itemsSum() - discount());

/* smartScore() — fifteen lines of personalisation weighting, exported, never
   called — has been removed. It was reachable from nothing: no module read
   AE_STATE.smartScore, and nothing in this file used it either.

   It is worth naming what it was, because it is a better description of a
   ranking feature than the absence of one: a score built from rating, review
   count, a `use` occasion matched against a hard-coded family list, wishlist
   membership, and a `dna` object whose keys it indexes defensively. The family
   tokens it matches on (`maryjane`, `lowheel`) are not in config.php's
   CATEGORY_SLUGS, so two of its seven inputs could never contribute to any
   product the shop actually sells. Shipping that as a suggestion engine would
   have ranked the catalogue by numbers that are half inert.

   Removed rather than left as a hook, because an exported, tested-looking,
   unread scoring function is a thing the next person wires in believing it
   works. Whoever builds ranking properly should write it against the real
   family vocabulary this shop uses. */

window.AE_STATE = {
  P, saveP, state,
  persBag, persWish, getCustom,
  itemsSum, discount, cartSum,
  stockOf, stockOfSize, capFor, sanitiseCart, MAX_LINE_UI
};
})();