/* ═══════════════════════════════════════════════════════════════════════
   VELORA AURELLE · renderers-aurelle.js
   محتوای دیالوگ‌های پوستهٔ index.php
     #sgInner  · راهنمای سایز
     #mzInner  · جادوگر اندازه‌گیری
     #profInner· پروفایل + OTP
     #ckoInner · پرداخت دوگام
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
const { $, esc, faNum, CLOSE_SVG } = window.AE;
const D = window.AE_DATA;

/* ═══════════════════════════════════════════════
   SIZE GUIDE
   ═══════════════════════════════════════════════ */
function renderSG() {
  const host = $('#sgInner');
  if (!host || host.dataset.ready === '1') return;
  host.dataset.ready = '1';

  /* SIZES, with no fallback array.

     `D.SIZES || ['37','38','39','40','41']` was in three places in this file
     and one in pdp-aurelle.js, and every one of them was unreachable:
     AE_DATA.SIZES is built in data.js from window.VELORA_SIZE_BAND, which
     index.php publishes from config.php's SIZE_BAND. The band therefore has one
     owner on the server and none on the client.

     A private copy of the list is the opposite of that. It is dead today, so it
     costs nothing — and it is exactly the kind of dead code that survives a
     change to SIZE_BAND and then silently disagrees with it, on a page that
     falls back to the stale copy only when the new value is missing. Removing
     the fallback makes the server value the only source; if it is ever absent,
     an empty band renders no sizes, which is visible, rather than a plausible
     wrong band which is not. */
  const sizes = D.SIZES;
  const conv  = D.CONV  || {};

  host.innerHTML = `
    <button class="close-btn sg__close" id="sgX" type="button" aria-label="بستن">
      ${CLOSE_SVG}
    </button>
    <span class="mono accent-txt">راهنمای سایز</span>
    <h2 class="sg-title">سایز دقیق پای خود</h2>
    <p class="sg-sub">قالب‌های خانه بر پایهٔ اندازه‌گیری طول و عرض پا ساخته می‌شوند.</p>

    <table class="sg-table">
      <thead>
        <tr>
          <th scope="col">سایز اروپایی</th>
          <th scope="col">طول پا</th>
          <th scope="col">توضیح</th>
        </tr>
      </thead>
      <tbody>
        ${sizes.map(s => `
          <tr>
            <td><b>${faNum(s)}</b></td>
            <td>${esc(conv[s] || '—')}</td>
            <td class="mono" style="font-size:.6rem;color:var(--text-4)">استاندارد خانه</td>
          </tr>`).join('')}
      </tbody>
    </table>

    <div class="tip">
      <span class="ico" aria-hidden="true">اُ</span>
      <p>اندازه‌گیری در پایان روز — که پا کمی بازتر است — دقیق‌ترین نتیجه را می‌دهد.
      اگر میان دو سایز هستید، سایز بزرگ‌تر را انتخاب کنید و کفی نیم‌سایز رایگان را درخواست دهید.</p>
    </div>

    <div style="margin-top:1.2rem;display:flex;gap:.6rem;flex-wrap:wrap">
      <button class="btn btn--gold btn--sm js-mz" type="button">اندازه‌گیری سفارشی</button>
      <button class="btn btn--ghost btn--sm js-sg-close" type="button">بستن</button>
    </div>`;

  /* A delegated close, not an inline attribute.

     This button carried onclick="this.closest('dialog').close()". The document's
     Content-Security-Policy sets `script-src-attr 'none'` — deliberately, and
     correctly, since an inline attribute is exactly the XSS sink that policy
     exists to remove. So the attribute was refused by the browser, no error was
     reported anywhere, and the one control in the size guide that says "بستن"
     did nothing. The dialog could still be dismissed by its corner ✕, by
     Escape and by the backdrop, which is exactly why it survived: every other
     exit worked.

     That is the failure mode worth naming. A CSP-blocked handler is
     indistinguishable from a handler that was never written, and this one sits
     beside a working ✕ on the same panel. An inline attribute anywhere in this
     codebase is now a bug, not a style. */
  host.querySelectorAll('.js-sg-close').forEach(b =>
    b.addEventListener('click', () => {
      ($('#sg') || b.closest('dialog'))?.close();
    }));

  host.querySelectorAll('.js-mz').forEach(b =>
    b.addEventListener('click', () => {
      $('#sg')?.close();
      document.querySelector('.js-mz:not(.js-sg)')?.click();
    }));
}

/* ═══════════════════════════════════════════════
   MEASURE WIZARD
   ═══════════════════════════════════════════════ */
function renderMZ() {
  const host = $('#mzInner');
  if (!host || host.dataset.ready === '1') return;
  host.dataset.ready = '1';

  host.innerHTML = `
    <button class="close-btn mz__x" id="mzX" type="button" aria-label="بستن">
      ${CLOSE_SVG}
    </button>
    <span class="mono accent-txt">سایز سفارشی</span>
    <h2 class="mz-title" id="mzT">هندسهٔ پای شما</h2>

    <ol class="mz__steps" aria-label="مراحل">
      <li class="is-on"><i>۰۱</i><span>طول پا</span></li>
      <li><i>۰۲</i><span>عرض پنجه</span></li>
      <li><i>۰۳</i><span>نتیجه</span></li>
    </ol>

    <div class="mz__prog">
      <i id="mzProg" style="display:block;height:100%;background:var(--accent);transform:scaleX(0.33);transform-origin:right;transition:transform .5s ease"></i>
    </div>

    <section class="mz__step is-on" data-mstep="0">
      <div class="mz__fig" aria-hidden="true">
        <svg viewBox="0 0 300 180" fill="none" stroke="var(--accent)" stroke-width="1.2">
          <path d="M60 150 C60 60, 140 40, 200 60 C240 72, 250 120, 240 150 Z" opacity=".7"/>
          <line x1="40" y1="160" x2="260" y2="160" stroke-dasharray="4 4"/>
          <line x1="60" y1="150" x2="60" y2="170"/>
          <line x1="240" y1="150" x2="240" y2="170"/>
          <text x="150" y="178" fill="var(--text-3)" font-size="10" text-anchor="middle">طول پا</text>
        </svg>
      </div>
      <p class="mz-desc">پای خود را روی کاغذ بگذارید و از پاشنه تا نوک بلندترین انگشت را بر حسب سانتی‌متر اندازه بگیرید.</p>
      <div class="field mz-field">
        <label for="mzLen">طول پا (سانتی‌متر)</label>
        <input id="mzLen" type="number" inputmode="decimal" step="0.1" min="20" max="30" placeholder="24.0">
      </div>
      <div class="fit-nav">
        <button class="btn btn--solid btn-block" id="mzNext1" type="button">ادامه</button>
      </div>
    </section>

    <section class="mz__step" data-mstep="1">
      <div class="mz__fig" aria-hidden="true">
        <svg viewBox="0 0 300 180" fill="none" stroke="var(--accent)" stroke-width="1.2">
          <path d="M60 150 C60 60, 140 40, 200 60 C240 72, 250 120, 240 150 Z" opacity=".7"/>
          <line x1="80" y1="90" x2="220" y2="90" stroke-dasharray="4 4"/>
          <line x1="80" y1="80" x2="80" y2="100"/>
          <line x1="220" y1="80" x2="220" y2="100"/>
          <text x="150" y="82" fill="var(--text-3)" font-size="10" text-anchor="middle">عرض پنجه</text>
        </svg>
      </div>
      <p class="mz-desc">پهن‌ترین نقطهٔ پنجه را اندازه بگیرید — معمولاً روی مفصل شست.</p>
      <div class="field mz-field">
        <label for="mzWid">عرض پنجه (سانتی‌متر)</label>
        <input id="mzWid" type="number" inputmode="decimal" step="0.1" min="6" max="13" placeholder="9.0">
      </div>
      <div class="fit-nav">
        <button class="btn btn--ghost" type="button" data-mz-back="0">قبلی</button>
        <button class="btn btn--solid" id="mzNext2" type="button">محاسبه</button>
      </div>
    </section>

    <section class="mz__step" data-mstep="2">
      <div class="mz__res">
        <span class="mono">سایز سفارشی شما</span>
        <div class="mz__eu" id="mzEU">—</div>
        <p class="mz__conv" id="mzConv">—</p>
        <p class="mz__note" id="mzNote">—</p>
      </div>
      <div class="fit-nav">
        <button class="btn btn--ghost" type="button" data-mz-back="1">قبلی</button>
        <button class="btn btn--gold" id="mzSave" type="button">ثبت و ذخیره</button>
      </div>
    </section>`;

  /* Back buttons — main.js doesn't wire these, so we dispatch a custom event
     that main.js can listen to (see patch note below). Fallback: naively click
     nothing if main.js doesn't handle it, leaving step unchanged. */
  host.querySelectorAll('[data-mz-back]').forEach(b => {
    b.addEventListener('click', () => {
      window.dispatchEvent(new CustomEvent('ae:mz-back', {
        detail: { to: +b.dataset.mzBack }
      }));
    });
  });
}

/* ═══════════════════════════════════════════════
   PROFILE — the account surface

   Two panes in one dialog, and every id auth.js reads is present on the
   FIRST render, because auth.js is a lazy module that binds its listeners
   once, at parse time: if the element were added later the listener would
   attach to nothing and the control would be inert forever.

     #profX · #profAuth · #[data-ps] · #profPhone · #sendOtp
     #otpPhone · .otp-box ×4 · #otpErr · #backPhone · #resendOtp
     #otpResendHint · #otpDevCode · #verifyOtp
     #profDash · #profAv · #profName · #profPhoneShow · #profSince
     #profSize · #profCst · #profMz · #profOrders · #profAdmin · #profOut

   The measure wizard is reached from a REAL button inside the custom-size
   card. The empty state used to say "start from the button below" while no
   such button existed anywhere on the panel — a sentence promising a control
   that was never rendered. The button carries .js-mz, which main.js already
   delegates document-wide, so no new wiring was needed; this file only makes
   it close the account panel first, exactly as the size guide does, so the
   customer is never looking at two stacked modals.
   ═══════════════════════════════════════════════ */
function renderProf() {
  const host = $('#profInner');
  if (!host || host.dataset.ready === '1') return;
  host.dataset.ready = '1';

  /* No private copy of the size band — see the note on the first `D.SIZES`
     above. The server publishes it; the client reads it. */
  const sizes = D.SIZES;

  host.innerHTML = `
    <button class="close-btn prof__x" id="profX" type="button" aria-label="بستن">
      ${CLOSE_SVG}
    </button>

    <!-- ── AUTH ─────────────────────────────────────────────────────── -->
    <div id="profAuth" class="prof__auth">
      <header class="prof__head">
        <span class="prof__seal" aria-hidden="true">
          <svg class="prof__seal-ring" viewBox="0 0 120 120" dir="ltr" xml:lang="en" lang="en">
            <defs>
              <path id="profSealPath"
                    d="M60 60 m-47 0 a47 47 0 1 1 94 0 a47 47 0 1 1 -94 0"/>
            </defs>
            <text direction="ltr" unicode-bidi="isolate"><textPath href="#profSealPath" startOffset="0" side="right">VELORA · MAISON DE CHAUSSURES · VELORA · </textPath></text>
          </svg>
          <b class="prof__seal-glyph">اُ</b>
        </span>

        <span class="prof__kicker mono">MAISON ACCOUNT</span>
        <h2 class="prof-title">ورود به خانهٔ اُرِل</h2>
        <p class="prof-desc">شمارهٔ همراه‌تان را وارد کنید؛ یک کد چهاررقمی یکبارمصرف برایتان می‌فرستیم. نه رمزی هست، نه حفظ‌کردنی.</p>

        <ol class="prof__track" id="profTrack">
          <li class="is-on"><i>۰۱</i><span>شماره</span></li>
          <li><i>۰۲</i><span>کد تأیید</span></li>
          <li><i>۰۳</i><span>حساب</span></li>
        </ol>
      </header>

      <div class="prof__body" data-ps="phone">
        <div class="field prof-field">
          <label for="profPhone">شمارهٔ همراه</label>
          <input id="profPhone" type="tel" inputmode="numeric" autocomplete="tel"
                 placeholder="۰۹۱۲۳۴۵۶۷۸۹" dir="ltr" maxlength="11"
                 aria-describedby="profPhoneHint">
          <p class="prof__hint" id="profPhoneHint">کد تأیید به همین شماره پیامک می‌شود — فقط یک بار، فقط برای شما.</p>
        </div>

        <button class="btn btn--gold btn--block" id="sendOtp" type="button">
          <span class="spin"></span><span>دریافت کد تأیید</span>
        </button>

        <ul class="prof__bullets">
          <li>ورود بدون رمز عبور</li>
          <li>شماره نزد خانه می‌ماند</li>
          <li>سفارش‌ها به حساب شما گره می‌خورند</li>
        </ul>
      </div>

      <div class="prof__body" data-ps="otp" hidden>
        <div class="prof__otp-top">
          <button class="linklike-muted" id="backPhone" type="button">تغییر شماره</button>
          <span class="prof__otp-to">کد به <b id="otpPhone" dir="ltr"></b> رفت</span>
        </div>

        <div class="otp-row" dir="ltr">
          <input class="otp-box" type="text" inputmode="numeric" maxlength="1" aria-label="رقم ۱" autocomplete="one-time-code">
          <input class="otp-box" type="text" inputmode="numeric" maxlength="1" aria-label="رقم ۲">
          <input class="otp-box" type="text" inputmode="numeric" maxlength="1" aria-label="رقم ۳">
          <input class="otp-box" type="text" inputmode="numeric" maxlength="1" aria-label="رقم ۴">
        </div>

        <p class="field-error prof__otp-err" id="otpErr" hidden>کد وارد شده درست نیست — دوباره تلاش کنید.</p>

        <!-- Shown by auth.js ONLY when the runtime says this is a test
             environment (a local demo with no server, or a server answering
             with debug_code). It carries [hidden] by default and the JS sets
             it to visible — the previous copy was written as "hidden unless
             the response says demo", and the real server never says demo,
             so the chip was on for every customer on every login. -->
        <div class="devchip prof__dev" hidden>
          <span>حالت آزمایشی · کد</span><b id="otpDevCode">۱۲۳۴</b>
        </div>

        <button class="btn btn--gold btn--block prof__verify" id="verifyOtp" type="button">
          <span class="spin"></span><span>تأیید و ورود</span>
        </button>

        <div class="otp-actions">
          <button class="linklike-accent" id="resendOtp" type="button" disabled>ارسال دوبارهٔ کد</button>
        </div>

        <!-- The countdown lives here rather than inside the button: a disabled
             control whose label changes is read as "exists, unusable", which
             is exactly backwards for a wait that is about to end. This line is
             a live region because the change from waiting to available is the
             only signal the resend has come back. -->
        <p class="otp-hint" id="otpResendHint" role="status"></p>
      </div>
    </div>

    <!-- ── DASHBOARD ────────────────────────────────────────────────── -->
    <div id="profDash" class="prof__dash" hidden>
      <header class="prof__id">
        <span class="prof-av" id="profAv" aria-hidden="true">اُ</span>
        <div class="prof__id-b">
          <div class="field prof__name-f">
            <label for="profName">نام شما</label>
            <input id="profName" type="text" autocomplete="name" placeholder="نام و نام خانوادگی">
          </div>
          <p class="prof__id-meta">
            <span class="prof__tick" aria-hidden="true">
              <svg viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor"
                   stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 12.5 9.2 17.5 20 6.5"/>
              </svg>
            </span>
            <span>شمارهٔ تأییدشده</span>
            <span class="mono" dir="ltr" id="profPhoneShow"></span>
          </p>
          <p class="prof__since mono" id="profSince" hidden></p>
        </div>
      </header>

      <ul class="prof__strip">
        <li class="prof__stat"><b id="profOrderN">—</b><span>سفارش ثبت‌شده</span></li>
        <li class="prof__stat"><b id="profWishN">—</b><span>علاقه‌مندی</span></li>
        <li class="prof__stat"><b id="profSizeN">—</b><span>سایز اروپایی</span></li>
      </ul>

      <div class="prof__cards">
        <section class="prof-card">
          <h5>سایز شما</h5>
          <label class="sr-only" for="profSize">سایز اروپایی</label>
          <select id="profSize" class="select select--full">
            <option value="">— انتخاب نشده —</option>
            ${sizes.map(s => `<option value="${s}">${faNum(s)}</option>`).join('')}
          </select>
          <p class="ps2">پیش‌فرض شما برای هر سفارش بعدی.</p>
        </section>

        <section class="prof-card">
          <h5>سایز سفارشی</h5>
          <div id="profCst"><p class="ps2">هنوز ثبت نشده.</p></div>
          <button class="btn btn--ghost btn--sm prof__cta js-mz" id="profMz" type="button">
            شروع اندازه‌گیری
          </button>
        </section>

        <section class="prof-card prof-card--full">
          <div class="prof-card__hd">
            <h5>سفارش‌های شما</h5>
            <button class="linklike-accent prof__guide js-sg" type="button">راهنمای سایز</button>
          </div>
          <div id="profOrders"><p class="ps2">در حال بارگذاری…</p></div>
        </section>
      </div>

      <div class="prof__acts">
        <button class="btn btn--ghost" id="profAdmin" type="button" hidden>پنل مدیریت</button>
        <button class="btn btn--ghost" id="profOut" type="button">خروج از حساب</button>
      </div>
    </div>`;

  /* Both of these open ANOTHER modal dialog. Leaving this one open behind
     them stacks two top-layer dialogs and traps the customer's focus between
     them, so the account panel closes first — and _opener is cleared before
     the close so auth.js does not yank focus back to the header button the
     instant the wizard takes it. */
  const handOff = () => {
    const p = $('#profile');
    if (!p || !p.open) return;
    p._opener = null;
    p.close();
  };
  host.querySelectorAll('.js-mz, .js-sg').forEach(b =>
    b.addEventListener('click', handOff));
}

/* ═══════════════════════════════════════════════
   CHECKOUT
   ═══════════════════════════════════════════════ */
function renderCko() {
  const host = $('#ckoInner');
  if (!host || host.dataset.ready === '1') return;
  host.dataset.ready = '1';

  /* ── TWO STEPS, NOT THREE ─────────────────────────────────────────
     Contact and address used to be two steps, which is one screen of
     scrolling and one round of focus moves to collect fields that are
     asked together on every form that has ever shipped. They are one
     step now — «اطلاعات و نشانی» — and the payment step follows it.

     Every REQUIRED control carries the star. The star is aria-hidden
     because `required` on the input is what assistive technology reads;
     the mark is for the eye, and reading it aloud before each label
     would say the same thing twice in a different word. The one optional
     field on the panel (واحد) says اختیاری instead of taking a star,
     because a legend where everything is marked marks nothing.

     رایانامه حذف شد: نه سرور آن را می‌خواند (velora-bridge.js آن را به
     api.php نمی‌فرستد) و نه جایی در سفارش هست — یک فیلد الزامی که هیچ
     سیستمی نمی‌پرسد، فقط جایی است که مشتری می‌ماند. */
  host.innerHTML = `
    <div class="cko__head">
      <h2 class="cko-title" id="ckoT">پرداخت</h2>
      <button class="close-btn" id="ckoX" type="button" aria-label="بستن">
        ${CLOSE_SVG}
      </button>
    </div>

    <ol class="cko__steps" id="ckoSteps" aria-label="مراحل">
      <li class="is-on"><i>۰۱</i><span>اطلاعات و نشانی</span></li>
      <li><i>۰۲</i><span>پرداخت</span></li>
    </ol>

    <div class="cko__prog"><i id="ckoProg"></i></div>

    <form id="ckoForm" autocomplete="on" novalidate style="margin-top:1.5rem">

      <fieldset class="cko__step is-on" data-step="0">
        <p class="cko__sub"><span>گیرنده</span></p>

        <div class="cko__row">
          <div class="field">
            <label for="ckName">نام و نام خانوادگی<i class="req" aria-hidden="true">*</i></label>
            <input id="ckName" name="name" autocomplete="name" required aria-describedby="ckNameErr">
            <p class="f-errmsg" id="ckNameErr" hidden>نام و نام خانوادگی را کامل بنویسید.</p></div>
          <div class="field">
            <label for="ckPhone">شمارهٔ همراه<i class="req" aria-hidden="true">*</i></label>
            <input id="ckPhone" name="phone" type="tel" autocomplete="tel" inputmode="numeric"
                   placeholder="۰۹۱۲۳۴۵۶۷۸۹" required aria-describedby="ckPhoneErr">
            <p class="f-errmsg" id="ckPhoneErr" hidden>شمارهٔ همراه باید ۱۱ رقم و با ۰۹ آغاز شود.</p></div>
        </div>

        <p class="cko-note" id="ckoAuthNote" hidden></p>

        <p class="cko__sub"><span>نشانی تحویل</span></p>

        <div class="cko__row">
          <div class="field">
            <label for="ckProvince">استان<i class="req" aria-hidden="true">*</i></label>
            <select id="ckProvince" name="province" autocomplete="address-level1" required data-unset aria-describedby="ckProvinceErr"><option value="">انتخاب کنید…</option>
            </select>
            <p class="f-errmsg" id="ckProvinceErr" hidden>استان را از فهرست انتخاب کنید.</p>
          </div>
          <div class="field">
            <label for="ckCity">شهر<i class="req" aria-hidden="true">*</i></label>
            <select id="ckCity" name="city" autocomplete="address-level2" required disabled data-unset aria-describedby="ckCityErr"><option value="">ابتدا استان</option>
            </select>
            <p class="f-errmsg" id="ckCityErr" hidden>شهر را از فهرست انتخاب کنید.</p>
          </div>
        </div>
        <div class="field">
          <label for="ckDistrict">محله<i class="req" aria-hidden="true">*</i></label>
          <input id="ckDistrict" name="district" autocomplete="address-level3" required aria-describedby="ckDistrictErr">
          <p class="f-errmsg" id="ckDistrictErr" hidden>محله را بنویسید.</p></div>
        <div class="field">
          <label for="ckAddr">نشانی<i class="req" aria-hidden="true">*</i></label>
<textarea id="ckAddr" name="address" autocomplete="street-address" required
                    placeholder="خیابان، کوچه، پلاک" aria-describedby="ckAddrErr"></textarea>
          <p class="f-errmsg" id="ckAddrErr" hidden>نشانی را کامل بنویسید — خیابان، کوچه و پلاک.</p>
        </div>
        <div class="cko__row">
          <div class="field">
            <label for="ckPlaque">پلاک<i class="req" aria-hidden="true">*</i></label>
            <input id="ckPlaque" name="plaque" inputmode="numeric" required aria-describedby="ckPlaqueErr">
            <p class="f-errmsg" id="ckPlaqueErr" hidden>شمارهٔ پلاک را بنویسید.</p></div>
          <div class="field">
            <label for="ckUnit">واحد<em class="opt">اختیاری</em></label>
            <input id="ckUnit" name="unit" inputmode="numeric" aria-describedby="ckUnitErr">
            <p class="f-errmsg" id="ckUnitErr" hidden>واحد، اختیاری است.</p></div>
        </div>
        <div class="field">
          <label for="ckZip">کد پستی<i class="req" aria-hidden="true">*</i></label>
          <input id="ckZip" name="postal-code" autocomplete="postal-code" inputmode="numeric"
                 maxlength="10" required aria-describedby="ckZipMsg">
          <p class="field-error" id="ckZipMsg" hidden></p>
        </div>
      </fieldset>

      <fieldset class="cko__step" data-step="1">
        <p class="cko__sub"><span>پرداخت</span></p>

        <div class="paymock" role="note">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
            <rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18"/>
          </svg>
          <b>درگاه پرداخت امن زرین‌پال</b>
          <span>پرداخت در صفحهٔ درگاه انجام می‌شود؛ شمارهٔ کارت و رمز آن هرگز در این سایت وارد نمی‌شود.
            <span class="mocktag">امن</span></span>
        </div>

        <p class="payhandoff">
          با زدن دکمهٔ «پرداخت»، سفارش ثبت می‌شود و به درگاه بانکی منتقل می‌شوید.
          پس از پرداخت، به همین صفحه بازگردانده می‌شوید و وضعیت سفارش را می‌بینید.
        </p>
      </fieldset>

      <div class="cko__sum">
        <div class="r"><span>تعداد اقلام</span><b id="ckoCount">۰</b></div>
        <div class="r"><span>جمع جزء</span><b id="ckoSub">۰ تومان</b></div>
        <div class="r disc" id="ckoDiscRow" hidden>
          <span>تخفیف · <b class="accent-txt" id="ckoDiscCode">—</b></span>
          <b class="accent-txt" id="ckoDisc">—</b>
        </div>
        <!-- The "شامل مالیات" row is gone. The server has no VAT term at all:
             api.php computes $total = ($subtotal - $discount) + SHIPPING_FLAT and
             SHIPPING_FLAT is 0. This row rendered a figure derived by dividing
             the total by 1.2 — arithmetic that implies the price is VAT-inclusive
             and that a tax exists inside it. Neither is true, so it was a number
             on screen that no system computed and nobody could reconcile. -->
        <div class="r"><span>هزینهٔ ارسال</span><b>رایگان</b></div>
        <div class="r"><span>ارسال اکسپرس</span><b style="color:var(--verd)">رایگان</b></div>
        <div class="r total"><span>پرداخت نهایی</span><b id="ckoTotal">۰ تومان</b></div>
      </div>

      <div class="promo">
        <label class="sr-only" for="promoInput">کد تخفیف</label>
        <input id="promoInput" type="text" dir="ltr" placeholder="کد تخفیف">
        <button class="btn btn--ghost" id="promoApply" type="button">اعمال</button>
      </div>
      <p class="promo-msg" id="promoMsg"></p>

      <div class="cko__nav">
        <button class="btn btn--ghost" id="ckoBack" type="button" disabled>قبلی</button>
        <button class="btn btn--gold" id="ckoNext" type="button">
          <span class="spin"></span>
          <span id="ckoNextT">ادامه</span>
        </button>
      </div>
    </form>

    <div class="cko__done" id="ckoDone" hidden style="text-align:center;padding:2rem 0">
      <div class="sealok">✓</div>
      <h3 style="font-family:var(--serif-d);font-size:var(--t-2xl);margin-bottom:.6rem">سفارش شما ثبت شد</h3>
      <p class="cko-done-txt">شمارهٔ پیگیری:</p>
      <b class="ref" id="ckoRef">—</b>
      <p class="cko-done-txt">میزبان ظرف ۲۴ ساعت تأیید می‌کند و سفارش به صف تولید می‌رود.</p>
        <p class="cko-done-local" id="ckoLocalWarn" hidden>
          <b>هشدار:</b> سرور در دسترس نبود، پس این سفارش فقط روی همین دستگاه ثبت شده است
          و به میزبان نرسیده. لطفاً با پشتیبانی تماس بگیرید یا بعداً دوباره تلاش کنید.
        </p>
      <div class="fit-nav" style="margin-top:1.5rem;justify-content:center">
        <button class="btn btn--solid" id="ckoDoneX" type="button">بازگشت به خانه</button>
      </div>
    </div>`;
}

/* ═══════════════════════════════════════════════
   Boot — همه را یک‌بار اجرا کن
   ═══════════════════════════════════════════════ */
function renderAll() {
  try { renderSG(); }   catch (e) { console.error('[renderSG]', e); }
  try { renderMZ(); }   catch (e) { console.error('[renderMZ]', e); }
  try { renderProf(); } catch (e) { console.error('[renderProf]', e); }
  try { renderCko(); }  catch (e) { console.error('[renderCko]', e); }
}

renderAll();

window.AE_RENDERERS = { renderAll, renderSG, renderMZ, renderProf, renderCko };
})();