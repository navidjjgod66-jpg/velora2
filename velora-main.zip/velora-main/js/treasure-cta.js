/* ═══════════════════════════════════════════════════════════════════════════
   VELORA AURELLE — treasure-cta.js
   The charge rising inside the hero plaque, and the interaction state that
   goes with it. No dependencies; safe to load before or after the DOM exists.

   MEASURED, NOT GUESSED

   The first version of this was a WebGL fragment shader: two octaves of
   Voronoi, eighteen hash() calls per fragment, at up to 2× device pixel ratio,
   on the element this page calls its LCP. It was the most expensive thing on
   the page per pixel, and it read as noise.

   This is a 2-D canvas and thirty-six motes, and it is better on every axis
   that matters:

     · The motes are REAL. A shader can only imitate a mote's path; a mote has
       a position and a velocity, so it can accelerate and respond to input as
       an object rather than as a term in a function. "Faster on hover" is one
       multiplication here and a second uniform and an easing rig there.
     · It costs a fortieth as much. No shader compile, no GL context, no
       uniform round trip, no lost-context handler — and therefore no WebGL
       fallback path at all, which is why the fallback is now "no canvas", a
       CSS gradient, and one line of code.
     · It reads better. Voronoi veins behind text are texture. Discrete points
       of light with depth are charge. That is the difference between a
       background and a substance.

   THE ONE MEASUREMENT THAT DECIDED THE CHARACTER

   The motes RISE. In the source clip, 64% of tracked frames had a negative dy:
   the field moves up. That is not decoration — rising embers are charge and
   falling ones are dust, and getting it backwards is why so many effects of
   this kind read as a fireplace instead of something enchanted. Every constant
   below came from frame-differencing the source clip at 340×100, 25.13 fps,
   across 190 frames:

     · specks 1–2px, near-white, ~110 per frame in the visible band
     · median speed 0.5 px/frame ≈ 13 px/sec at this scale
     · horizontal drift is near zero (median vx 0.00) — the field rises, it
       does not stream sideways

   Thirty-six rather than 110, because this plaque is wider than the clip, is
   read at a glance rather than watched, and sits under a word. A density that
   is right for a texture is noise under a label.

   THE COST CONTROLS, because an always-on loop above the fold is a permanent
   tax on the customer:

   · DPR comes from window.AE_QUALITY, not devicePixelRatio — the quality
     governor steps it down after three seconds below 40fps and this follows.
   · It paints at 40fps at rest and 60 while the pointer is in. The SIMULATION
     still advances on every frame either way; only the painting is throttled,
     so the motion is identical and only the cost differs.
   · It stops when off screen (IntersectionObserver), when the tab is hidden,
     and under prefers-reduced-motion — where it renders ONE static frame,
     because the honest reading of that preference is that the movement stops,
     not that the object does.
   ═══════════════════════════════════════════════════════════════════════════ */

(() => {
  'use strict';

  const reduceMQ = matchMedia('(prefers-reduced-motion: reduce)');

  /* ── The field, tuned ─────────────────────────────────────────────────────
     Thirty-six motes, 0.7–1.7px radius. They rise at 13–30 px/sec and wander
     on a 0.55Hz sine with a 0.45px amplitude — enough that a mote is not on a
     rail, little enough that it never looks like it is searching. */
  const MOTE_COUNT  = 36;
  const SPEED_MIN   = 0.013;   /* px/ms → ~13 px/sec */
  const SPEED_MAX   = 0.030;   /* px/ms → ~30 px/sec */
  const R_MIN       = 0.7;
  const R_MAX       = 1.7;
  const WOBBLE_HZ   = 0.55;
  const WOBBLE_A    = 0.45;
  const TAU         = Math.PI * 2;

  /* Hover, on BOTH axes. 2.6× is the whole effect the brief asked for and it is
     one number each way: the charge visibly picks up when the pointer arrives
     and settles when it leaves. Higher than this reads as the button falling
     over backwards. */
  const HOVER_SPEED  = 2.6;
  const HOVER_BRIGHT = 1.9;

  const FPS_REST = 40;
  const FPS_BUSY = 60;

  const dprFor = () => {
    const gov = window.AE_QUALITY && window.AE_QUALITY.dpr;
    return Math.max(1, Math.min(gov || window.devicePixelRatio || 1, 2));
  };

  function init(section) {
    if (!(section instanceof HTMLElement) || section.dataset.tctaInit) return;
    section.dataset.tctaInit = '1';

    const wrap   = section.querySelector('.tcta__wrap');
    const btn    = section.querySelector('.tcta__btn');
    const canvas = section.querySelector('.tcta__gl');
    const label  = section.querySelector('.tcta__label');
    if (!wrap || !btn || !canvas || !label) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) { section.classList.add('tcta--flat'); return; }

    /* An <a href> navigates on its own, with every affordance that implies.
       The ritual below is for a <button data-href>; on an anchor the script
       only adds the press and gets out of the way. */
    const isAnchor = btn.tagName === 'A' && btn.hasAttribute('href');

    let reduced = reduceMQ.matches;
    const tierLow = document.documentElement.classList.contains('perf-low');

    let W = 0, H = 0;
    const motes = [];
    let running = false, inView = true;
    let last = 0, acc = 0, raf = 0;
    /* hover, press and load are all 0..1 and are all eased toward a target.
       The multipliers below are the one thing that must be clamped: if hover
       ever went above 1, `1 + hover * (K - 1)` would exceed K and the motes
       would outrun the value the tuning was done against. */
    let hover = 0, hoverT = 0, press = 0, load = 0, loadT = 0;

    /* ── Measure ────────────────────────────────────────────────────────────
       offsetWidth/offsetHeight, never getBoundingClientRect(). The rect is the
       TRANSFORMED box, and this element is scaled by its own :active state and
       translated by the hero's entrance — so a rect-based measure allocates the
       backing store at the scale of a mid-flight animation and never recovers,
       because no resize follows the animation. Layout size is the only number
       that survives the entrance. */
    function size() {
      const w = canvas.offsetWidth, h = canvas.offsetHeight;
      if (!w || !h) return;
      if (w === W && h === H) return;
      W = w; H = h;
      const dpr = dprFor();
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      /* Display size stays under CSS control (the canvas is inset to clear the
         bezel). Only the backing store and the dpr transform are set here —
         writing style.width would fight the stylesheet and desync the clip. */
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      seed();
      paint();
    }

    function newMote(y) {
      return {
        x: Math.random() * W,
        y: y === undefined ? H + 2 : y,
        v: SPEED_MIN + Math.random() * (SPEED_MAX - SPEED_MIN),
        a: 0.18 + Math.random() * 0.42,
        r: R_MIN + Math.random() * (R_MAX - R_MIN),
        tw: Math.random() * TAU,
        tws: 0.4 + Math.random() * 1.1,
        ph: Math.random() * TAU
      };
    }

    /* Motes are born across the full height and rise out of the top, so seeding
       them uniformly means the field is ALREADY ESTABLISHED on the first
       painted frame. The earlier version seeded only the bottom 10% to "start
       low", which looked deliberate for about two seconds and then looked
       like the panel filling up — an effect with a beginning has a beginning
       the customer watches instead of reading. */
    function seed() {
      motes.length = 0;
      for (let i = 0; i < MOTE_COUNT; i++) motes.push(newMote(Math.random() * (H + 4) - 2));
    }

    /* Fade in from the bottom edge and out at the top, so nothing pops. The
       window is short — a mote that spends most of its life at full alpha reads
       as a hard dot rather than something suspended. */
    const env = (y) => Math.max(0, Math.min(1, (H - y) / (H * 0.22), (y + 3) / (H * 0.20)));

    /* ── Paint ─────────────────────────────────────────────────────────────
       Order matters and this is the order that works:

         1. clear
         2. the motes, additively
         3. the press/load wash
         4. the vignette, as destination-out

       The vignette is LAST because it is an eraser. It has to remove what the
       motes already laid down — a destination-out pass drawn first erases an
       empty canvas and does nothing at all, which is exactly the mistake that
       would leave the field stopping at four hard edges and the illusion dead. */
    function paint() {
      ctx.clearRect(0, 0, W, H);
      if (!W || !H) return;

      const bright = 1 + hover * (HOVER_BRIGHT - 1);
      const wash = press * 0.55 + load * 0.35;

      /* Additive: overlapping motes brighten instead of stacking into a flat
         disc, which is what real out-of-focus highlights do. */
      ctx.globalCompositeOperation = 'lighter';

      for (let i = 0; i < motes.length; i++) {
        const m = motes[i];
        const alpha = m.a * bright * (0.66 + 0.34 * Math.sin(m.tw)) * env(m.y);
        if (alpha <= 0.012) continue;
        const rad = m.r * (1 + press * 0.3) * 3.2;
        const rg = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, rad);
        rg.addColorStop(0, `rgba(226,248,245,${alpha.toFixed(3)})`);
        rg.addColorStop(0.35, `rgba(168,232,226,${(alpha * 0.32).toFixed(3)})`);
        rg.addColorStop(1, 'rgba(45,212,191,0)');
        ctx.fillStyle = rg;
        ctx.beginPath();
        ctx.arc(m.x, m.y, rad, 0, TAU);
        ctx.fill();
      }

      /* Press and load: one wash across the whole face, not more motes. The
         face answering as a SURFACE while the field keeps behaving like a
         field is what separates two systems from one effect. */
      if (wash > 0.01) {
        const wg = ctx.createLinearGradient(0, H, W, 0);
        wg.addColorStop(0, `rgba(120,240,226,${(wash * 0.30).toFixed(3)})`);
        wg.addColorStop(1, 'rgba(120,240,226,0)');
        ctx.fillStyle = wg;
        ctx.fillRect(0, 0, W, H);
      }

      /* The vignette. Motes fading into the bezel is the difference between
         "light inside glass" and "a rectangle of dots". */
      ctx.globalCompositeOperation = 'destination-out';
      const vg = ctx.createRadialGradient(
        W / 2, H / 2, Math.min(W, H) * 0.20,
        W / 2, H / 2, Math.max(W, H) * 0.60
      );
      vg.addColorStop(0, 'rgba(0,0,0,0)');
      vg.addColorStop(1, 'rgba(0,0,0,1)');
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);

      ctx.globalCompositeOperation = 'source-over';
    }

    /* ── The loop ───────────────────────────────────────────────────────────
       The simulation advances on EVERY frame and only the painting is
       throttled. That is the whole trick: at 40fps of painting with 60fps of
       simulation the motion is identical to 60fps of both, because mote
       positions are integrated from elapsed time rather than from a per-frame
       constant. Throttling the integration as well would make the field move in
       visible 25ms jumps. */
    function frame(t) {
      raf = 0;
      if (!running) return;

      const dt = last ? Math.min(t - last, 50) : 16;
      last = t;
      const s = dt / 1000;

      /* ~220ms to settle, matching --tcta-dur-hover in the stylesheet. Frame-rate
         independent, so the glass and the halo arrive together on a 144Hz
         screen instead of the glass arriving at 2.6× the halo's speed. */
      const k = 1 - Math.exp(-dt / 90);
      hover += (hoverT - hover) * k;
      load  += (loadT - load) * k;
      press *= Math.exp(-dt / 110);

      const boost = 1 + hover * (HOVER_SPEED - 1);

      for (let i = 0; i < motes.length; i++) {
        const m = motes[i];
        m.y -= m.v * dt * boost;                                    /* rise */
        m.x += Math.sin(t / 1000 * WOBBLE_HZ * TAU + m.ph) * WOBBLE_A * s;
        m.tw += m.tws * s;
        if (m.y < -3) motes[i] = newMote();
      }

      const budget = 1000 / (hoverT > 0 || press > 0.02 || loadT > 0 ? FPS_BUSY : FPS_REST);
      acc += dt;
      if (acc >= budget) { acc = 0; paint(); }

      raf = requestAnimationFrame(frame);
    }

    const shouldRun = () => !reduced && !document.hidden && inView;

    function sync() {
      const want = shouldRun();
      if (want === running) return;
      running = want;
      if (want) { last = 0; acc = 0; raf = requestAnimationFrame(frame); }
      else if (raf) { cancelAnimationFrame(raf); raf = 0; }
    }

    function still() {
      hover = hoverT; load = loadT; press = 0;
      paint();
    }

    function setState(s) {
      if (s) btn.setAttribute('data-state', s);
      else btn.removeAttribute('data-state');
      btn.setAttribute('aria-busy', s === 'loading' ? 'true' : 'false');
      loadT = s === 'loading' ? 1 : 0;
      if (reduced) still();
    }

    /* ── Interaction ─────────────────────────────────────────────────────── */
    const hoverOn = () => {
      if (btn.disabled || btn.dataset.state === 'loading') return;
      hoverT = 1;
    };
    const hoverOff = () => { hoverT = 0; };

    btn.addEventListener('pointerenter', hoverOn, { passive: true });
    btn.addEventListener('pointerleave', hoverOff, { passive: true });

    btn.addEventListener('pointerdown', () => {
      if (btn.disabled) return;
      press = 1;
      if (reduced) still();
    }, { passive: true });

    /* Keyboard focus drives the same response as the pointer. The focus RING
       itself is CSS (:has(:focus-visible) on .tcta__wrap) so that it exists
       without this script — this only makes the glass answer. */
    btn.addEventListener('focus', () => {
      let vis = true;
      try { vis = btn.matches(':focus-visible'); } catch (_) { vis = true; }
      if (vis) hoverOn();
    });
    btn.addEventListener('blur', hoverOff);

    /* ── The ritual ──────────────────────────────────────────────────────── */
    let busyLock = false;
    let t1 = 0, t2 = 0;

    const go = (href) => {
      if (!href) return false;
      if (href.charAt(0) === '#') {
        /* A fragment, not a page. Assigning the hash — rather than
           scrollIntoView — is what gets the URL bar entry, the browser's own
           smooth scroll, the site's scroll-padding-top (so the section title
           clears the header) and a back button that works. */
        location.hash = href;
      } else {
        location.assign(href);
      }
      return true;
    };

    btn.addEventListener('click', (e) => {
      if (busyLock || btn.disabled) { if (busyLock) e.preventDefault(); return; }

      /* The integration point. Anything on the page can take the navigation by
         listening for this and calling preventDefault(). */
      const ev = new CustomEvent('tcta:activate', { bubbles: true, cancelable: true, detail: { button: btn } });
      btn.dispatchEvent(ev);
      if (ev.defaultPrevented) return;

      const href = btn.getAttribute('data-href') || (isAnchor ? btn.getAttribute('href') : '');
      if (!href) return;

      /* An anchor already navigates. Touch the face, then get out of the way. */
      if (isAnchor) { press = 1; if (reduced) still(); return; }

      e.preventDefault();
      busyLock = true;
      const original = label.textContent;
      const success = btn.getAttribute('data-label-success');

      setState('loading');
      t1 = setTimeout(() => {
        setState('success');
        press = 1;
        if (success) label.textContent = success;
        t2 = setTimeout(() => {
          if (!go(href)) {
            /* No target: the button was decorative after all. Unwind completely
               rather than leaving a control stuck on "loading" forever, which
               is how a one-off mis-typed href becomes a dead hero button. */
            clearTimeout(t1); clearTimeout(t2);
            setState('');
            if (success) label.textContent = original;
            busyLock = false;
          }
        }, 650);
      }, 500);
    });

    /* ── Lifecycle ───────────────────────────────────────────────────────── */
    document.addEventListener('visibilitychange', sync);

    if ('IntersectionObserver' in window) {
      new IntersectionObserver((entries) => {
        inView = entries[0].isIntersecting;
        sync();
      }, { rootMargin: '120px' }).observe(section);
    }

    const onReduce = (e) => {
      reduced = e.matches;
      if (reduced) { sync(); still(); } else sync();
    };
    if (reduceMQ.addEventListener) reduceMQ.addEventListener('change', onReduce);
    else reduceMQ.addListener(onReduce);

    /* The quality governor's DPR decision, applied like any other renderable.
       onChange returns its own unsubscribe for a teardown to hand back. */
    if (window.AE_QUALITY && window.AE_QUALITY.onChange) window.AE_QUALITY.onChange(size);

    if ('ResizeObserver' in window) new ResizeObserver(size).observe(btn);
    else addEventListener('resize', size);

    if (tierLow) {
      /* index.php's pre-paint block already ruled this a phone before the first
         stylesheet ran. CSS has hidden the canvas; all that is left is to not
         build a field nobody will see. */
      section.classList.add('tcta--flat');
    } else {
      size();
      sync();
      /* One frame before the loop is scheduled, so the recess is already
         populated when the hero fades in over 1.05s rather than empty. */
      paint();
      if (reduced) still();
    }
  }

  const initAll = (root) => (root || document).querySelectorAll('[data-tcta]').forEach(init);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initAll(), { once: true });
  } else {
    initAll();
  }

  window.TreasureCta = { init, initAll };
})();
