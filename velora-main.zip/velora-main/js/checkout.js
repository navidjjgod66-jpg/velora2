/* ═══════════════════════════════════════════════════════════════════════
   MAISON AURELLE — checkout.js
   Two-step checkout flow · Validators · Promo · Order persistence
   ═══════════════════════════════════════════════════════════════════════ */
(() => {
'use strict';
const {
  $, $$, html, body, reduced, TIMERS, LS, K,
  faNum, moneyT, esc, toast, haptic,
  dlStop, dlStart, wireDialog
} = window.AE;
const { CATALOG, PROMO } = window.AE_DATA;
const { state, itemsSum, discount, cartSum } = window.AE_STATE;
const { recordOrder, completeCheckout } = window.AE_CART;
const api = window.aeApi || null;

const cko = $('#cko');
const ckoStepsL = $$('#ckoSteps li');
const ckoProg = $('#ckoProg');
const ckoBack = $('#ckoBack'), ckoNext = $('#ckoNext');
const ckoNextT = $('#ckoNextT'), ckoDone = $('#ckoDone');
let ckoStep = 0;
/* True from the moment the final step's request leaves until it settles. See the
   note at the guard: the button is re-enabled by the request's own outcome and
   by nothing else. */
let ckoSubmitting = false;

/* ═══ Validators ═══ */
/* Persian and Arabic-Indic digits fold to ASCII before any length or pattern
   test. Otherwise `ckZip` counts two bytes per Persian digit, a 10-digit code
   reads as 20 "characters" and the shape check is meaningless — which is how
   an invalid code gets stored and a parcel comes back.

   This was a second copy of the same helper; velora-bridge.js had a third.
   Both now call the one in core.js, because a fourth, broken, copy in auth.js
   used /\D/g and made OTP login impossible to complete on a Persian keyboard.
   See the foldDigits note in core.js. */
const asciiDigits = window.AE.asciiDigits;

const ckoValidators = {
  ckName: v => v.trim().length >= 2,
  /* api.php normalizes then requires a real mobile: 09 + 9 digits. The client
     check exists to avoid a round trip, so it mirrors the server's rule
     rather than guessing at one. */
  ckPhone: v => /^09\d{9}$/.test(asciiDigits(v)),
  ckAddr: v => v.trim().length >= 5,
  ckCity: v => v.trim().length >= 2,
  ckProvince: v => v.trim().length >= 2,
  ckDistrict: v => v.trim().length >= 2,
  ckPlaque: v => asciiDigits(v).length >= 1,
  /* Ten digits. A checksum would be wrong here: velora_address_in() enforces
     the shape only, because the post office's own lookup is better evidence
     than our arithmetic — so the client must not be stricter than the server
     it is talking to, or it refuses codes the server would have accepted. */
  ckZip:  v => asciiDigits(v).length === 10
};

/* Two steps: the merged «اطلاعات و نشانی» screen, then the payment handoff.

   The contact fields and the address fields used to be validated as two
   separate steps, which is why they were two separate screens. Merging the
   markup without merging this table would have left the address fields
   unreachable — step 0 would have validated only the contact trio and then
   advanced past a form the customer had never seen.

   Step 1 has NO fields, and that is the whole of the fix.

   It used to be ['ckHolder','ckCard','ckExp','ckCvc'] — a full card form: PAN,
   expiry and CVV2, with `autocomplete="cc-number"` and `inputmode="numeric"`,
   validated in the browser and required to advance. None of it was ever sent.
   The payload built on submit carries items, promo, contact and address and
   nothing else; velora-bridge.js's checkoutBody() has no card parameter; and
   includes/api/checkout.php has no card column. The values the customer typed
   sat in this origin's tab and were then discarded.

   That is a real defect with two costs, not one.

   PCI-DSS asks who may store, process or transmit a PAN — and a page the
   merchant controls, on the merchant's origin, in which the customer types a
   PAN is enough to pull the whole cardholder data environment into scope,
   with an audit that a decorative form cannot satisfy. Worse, the note directly
   above the fields claimed the opposite: «اطلاعات کارت نزد درگاه باقی می‌ماند و
   هرگز در سرور ما ذخیره نمی‌شود» — the card stays at the gateway and is never
   stored on our server — while the fields sat in this document.

   And a customer who believed they had paid by card did not: the order was
   placed and redirected to the gateway either way, so the form was a required
   obstacle to a redirect that never used its contents.

   Card data belongs to the gateway's page and nowhere else. Step 1 says so. */
const STEP_FIELDS = [
  ['ckName', 'ckPhone', 'ckProvince', 'ckCity', 'ckDistrict', 'ckAddr', 'ckPlaque', 'ckZip'],
  []
];

/* Validate one field and say what is wrong with it, in words.

   It used to set `.invalid` and `aria-invalid` and stop there, which produced a
   1px red underline and nothing else. The form rendered no error element for any
   field, so there was no text to reveal and no aria-describedby to point at one:
   a customer who failed validation was told *that* a field was wrong and never
   *what* about it, and a screen-reader customer heard "invalid" with no
   explanation attached.

   The message itself lives in the markup, next to the input, rather than in this
   map. That is deliberate — a message written here is a message that has to be
   translated, escaped, kept in step with the validator above it, and delivered
   through a `hidden` attribute that can only be cleared from here. Putting the
   Persian sentence in the DOM means it is read by the same template that renders
   the label, and it is available to assistive technology without JavaScript
   having run at all. */
const ckCheck = id => {
  const el = $('#' + id);
  const ok = ckoValidators[id](el.value);
  const field = el.closest('.field');
  field.classList.toggle('invalid', !ok);
  el.setAttribute('aria-invalid', String(!ok));
  const msg = $('#' + id + 'Err');
  if (msg) msg.hidden = ok;
  return ok;
};

/* Labels for the server's per-field rejection codes, so a refusal lands on the
   input that caused it. api.php returns `field` alongside every message; the
   ids below are the ones that currently exist in the form. */
const CKO_FIELD_HINT = {
  GEO_INVALID:        ['ckProvince', 'استان و شهر را از فهرست انتخاب کنید.'],
  DISTRICT_INVALID:   ['ckDistrict',  'محله را وارد کنید.'],
  PLAQUE_INVALID:     ['ckPlaque',    'شمارهٔ پلاک را وارد کنید.'],
  LINE_INVALID:       ['ckAddr',      'نشانی را کامل‌تر بنویسید.'],
  POSTAL_INVALID:     ['ckZip',       'کدپستی باید ۱۰ رقم باشد.'],
  RECEIVER_INVALID:   ['ckName',      'نام گیرنده را کامل بنویسید.'],
  PHONE_INVALID:      ['ckPhone',     'شمارهٔ همراه معتبر نیست.'],
  PHONE_UNVERIFIED:   ['ckPhone',     'این شماره هنوز تأیید نشده است.'],
  INVALID_SIZE:       null,
  PRODUCT_NOT_FOUND:  null,
  /* A rejected voucher is not a form field, but it is a specific thing the
     customer can fix, and the sheet has a box for it. The server now refuses an
     invalid code outright instead of quietly charging full price — these three
     are what it refuses with, and each maps to the sentence that explains it. */
  INVALID_CODE:       ['promoInput', 'کد تخفیف معتبر نیست.'],
  MIN_NOT_MET:        ['promoInput', 'برای این کد تخفیف، مبلغ سفارش باید بیشتر باشد.'],
  FIRST_ONLY:         ['promoInput', 'این کد تخفیف فقط برای اولین خرید است و قبلاً استفاده شده.'],
  DB_UNAVAILABLE:     ['promoInput', 'بررسی کد تخفیف ممکن نشد — لطفاً دوباره تلاش کنید.'],
};

Object.keys(ckoValidators).forEach(id => {
  const el = $('#' + id); if (!el) return;
  el.addEventListener('input', () => {
    el.closest('.field').classList.remove('invalid');
    el.removeAttribute('aria-invalid');
    /* The message goes with the red underline. Leaving it up after the customer
       has started fixing the field is the worst of both: it asserts something
       about the current value that is no longer true, and it pushes the rest of
       the form down by a line while they are typing into this one. */
    const msg = $('#' + id + 'Err');
    if (msg) msg.hidden = true;
    /* asciiDigits FIRST, then strip.

       `\D` means "not [0-9]", so on a Persian keyboard it deletes the digits
       along with the separators: `replace(/\D/g,'')` applied to «۶۲۱۹ …» yields
       the empty string and the field empties itself under the customer's
       fingers. Every numeric field here declares `inputmode="numeric"`, so an
       Iranian keyboard is the expected keyboard — this is not an edge case, it
       is the main one.

       The same trap is documented at includes/addresses.php (normalize first,
       strip second) and handled once for all three remaining fields below. */
    /* Live-normalize the numeric fields as they are typed, so what is
       submitted is what the server's own digit normalizer would produce.
       Applying it on input rather than on submit means the length check runs
       against the same string the server will see. */
    if (id === 'ckZip') {
      const d = asciiDigits(el.value).slice(0, 10);
      if (d !== el.value) el.value = d;
      const msg = $('#ckZipMsg');
      if (msg) { msg.hidden = d.length === 10; msg.textContent = `کدپستی باید ۱۰ رقم باشد (${faNum(d.length)} از ۱۰).`; }
    }
    if (id === 'ckPhone' || id === 'ckPlaque') {
      const d = asciiDigits(el.value);
      if (d !== el.value) el.value = d;
    }
  });
});

/* ─── Geo: province → city ─────────────────────────────────────────────
     Both lists come from api.php's geo_regions action, which is the same
     table velora_geo_valid() checks against on the server. The picker and the
     validator therefore cannot disagree about which city belongs to which
     province, which is the failure free-text entry allows: "تهران، اصفهان"
     passes any two independent length checks and names a city in the wrong
     province. */
let ckoGeo = null;   /* { province: [city, ...] } */
let ckoGeoTried = false;

/* Marks a select as unchosen so it renders in the muted placeholder colour —
   see the `select[data-unset]` rule in components.css. Cleared as soon as a
   real value is selected, which is what makes the field look filled in. */
function ckoMarkSet(sel, hasValue) {
  if (!sel) return;
  if (hasValue) sel.removeAttribute('data-unset');
  else sel.setAttribute('data-unset', '');
}

async function ckoLoadGeo() {
  if (ckoGeo) return ckoGeo;
  /* One attempt per dialog-open. Without the flag, every call to openCko()
     re-requests the map on a network failure, which for a customer on a flaky
     connection means the province list is never usable. */
  if (ckoGeoTried) return null;
  ckoGeoTried = true;
  const sel = $('#ckProvince');
  if (!sel) return null;
  try {
    const r = api ? await api.geoRegions() : null;
    const map = r && r.map;
    if (!map || typeof map !== 'object') throw new Error('no-map');
    ckoGeo = map;
    const frag = document.createDocumentFragment();
    Object.keys(map).forEach(prov => {
      const o = document.createElement('option');
      o.value = prov; o.textContent = prov;
      frag.appendChild(o);
    });
    sel.appendChild(frag);
    ckoMarkSet(sel, !!sel.value);
  } catch (_) {
    /* Release the latch on failure.

       `ckoGeoTried` is set before the request and was never cleared, so the
       intent — do not re-request the map on every dialog-open — was implemented
       as "never request it again, for the rest of the session". One transient
       failure on a mobile connection therefore latched the province picker
       shut for good: every later open returned null silently, the select kept
       only its placeholder, `ckCheck('ckProvince')` could never pass, and the
       customer was stuck on step 0 with no retry and no message. Only a full
       page reload recovered it.

       "Don't hammer the endpoint" and "give up permanently" are different
       policies. The first is what the flag is for and it still holds: a
       successful load sets `ckoGeo`, and the early return above short-circuits
       every later call. What must not persist is a FAILED attempt. */
    ckoGeoTried = false;
    ckoGeo = null;
    toast('فهرست استان‌ها بارگذاری نشد — لطفاً دوباره تلاش کنید.', 'err');
  }
  return ckoGeo;
}

function ckoFillCities(province) {
  const city = $('#ckCity');
  if (!city) return;
  city.innerHTML = province
    ? '<option value="">انتخاب کنید…</option>'
    : '<option value="">ابتدا استان</option>';
  city.disabled = !province;
  ckoMarkSet(city, false);
  if (!province || !ckoGeo || !ckoGeo[province]) return;
  const frag = document.createDocumentFragment();
  ckoGeo[province].forEach(c => {
    const o = document.createElement('option');
    o.value = c; o.textContent = c;
    frag.appendChild(o);
  });
  city.appendChild(frag);
}

$('#ckProvince') && $('#ckProvince').addEventListener('change', e => {
  ckoFillCities(e.target.value);
  ckoMarkSet(e.target, !!e.target.value);
  const city = $('#ckCity');
  if (city) { city.value = ''; city.closest('.field').classList.remove('invalid'); }
});
$('#ckCity') && $('#ckCity').addEventListener('change', e => ckoMarkSet(e.target, !!e.target.value));

/* ─── Postal lookup ────────────────────────────────────────────────────
     Optional convenience, never a gate. If the operator has configured a token
     the post office fills province, city and district in for them; with no
     token the field is skipped entirely. A lookup failure must never become a
     checkout failure, so nothing here blocks the next step. */
let ckoPostalTimer = null;
$('#ckZip') && $('#ckZip').addEventListener('input', e => {
  clearTimeout(ckoPostalTimer);
  const code = asciiDigits(e.target.value);
  if (code.length !== 10 || !api || !api.postalLookup) return;
  ckoPostalTimer = setTimeout(async () => {
    try {
      const r = await api.postalLookup(code);
      if (!r || !r.ok || !r.province) return;
      await ckoLoadGeo();
      const prov = $('#ckProvince'), city = $('#ckCity'), dist = $('#ckDistrict');
      if (prov && ckoGeo && ckoGeo[r.province]) {
        prov.value = r.province;
        ckoMarkSet(prov, true);
        ckoFillCities(r.province);
        if (city && (r.city || '')) {
          city.value = r.city;
          ckoMarkSet(city, true);
        }
      }
      /* Only fill the district when it is empty — a customer who has already
         typed a more specific name than the post office returns keeps theirs. */
      if (dist && !dist.value.trim() && r.district) dist.value = r.district;
    } catch (_) { /* convenience only */ }
  }, 500);
});

/* ─── Auth state ────────────────────────────────────────────────────────
     api.php's checkout action requires a signed-in user with a verified phone,
     and refuses anything else with LOGIN_REQUIRED or PHONE_UNVERIFIED. The
     client never checked either, so an anonymous customer filled in the whole
     form and was told the order failed at the very last moment. The gate is
     moved to the front of the flow, where it can be acted on. */
/* `known` is a tri-state on purpose.

   `auth: false` has two completely different causes and the sheet must not
   treat them the same. A genuine anonymous session is answered by the `me`
   probe as `{logged:false}` — that is the server saying "no". A dropped
   connection, a 25-second timeout or a 5xx throws instead, and the old code
   caught it into the same `{auth:false}`, so a momentary network blip told a
   signed-in customer they were signed out, closed the checkout sheet
   mid-order, and opened the sign-in dialog over it. They would then have to
   re-enter their address.

   `known:false` says "we do not know", and the caller waits rather than
   concluding. The server remains the authority — nothing is decided from the
   absence of an answer. */
let ckoSession = { auth: false, phone: '', known: false };
async function ckoRefreshSession() {
  if (!api) return ckoSession;
  try {
    const s = await api.sessionGet(true);
    ckoSession = { auth: !!(s && s.auth), phone: (s && s.phone) || '', known: true };
  } catch (_) {
    /* Unknown, not signed out. Leave the previous answer alone — if a previous
       probe succeeded, the session is still the best evidence we have. */
    ckoSession = { ...ckoSession, known: false };
  }
  const note = $('#ckoAuthNote');
  const tel  = $('#ckPhone');
  if (note) {
    if (!ckoSession.known) {
      /* No answer yet: say nothing. The alternatives are both lies — telling a
         signed-in customer to sign in, or telling an anonymous one that all is
         well. The submit path handles the unknown case explicitly. */
      note.hidden = true;
    } else if (!ckoSession.auth) {
      note.hidden = false;
      note.textContent = 'برای ثبت سفارش باید وارد حساب خود شوید.';
    } else if (!ckoSession.phone) {
      note.hidden = false;
      note.textContent = 'حساب شما شمارهٔ تأییدشده ندارد — برای ارسال سفارش باید شمارهٔ همراه خود را تأیید کنید.';
    } else {
      note.hidden = true;
    }
  }
  if (tel && ckoSession.phone && !tel.value.trim()) tel.value = ckoSession.phone;
  return ckoSession;
}
addEventListener('ae:profile-close', () => { ckoRefreshSession(); });

/* ═══ Paint / summary ═══ */
function ckoPaint() {
  ckoStepsL.forEach((li, i) => {
    li.classList.toggle('is-on', i === ckoStep);
    li.classList.toggle('is-done', i < ckoStep);
  });
  ckoProg.style.transform = `scaleX(${(ckoStep+1)/2})`;
  $$('.cko__step', cko).forEach(fs => fs.classList.toggle('is-on', +fs.dataset.step === ckoStep));
  ckoBack.disabled = ckoStep === 0;
  ckoNextT.textContent = ckoStep === 1 ? 'پرداخت و ثبت سفارش' : 'ادامه';
}
function ckoSummary() {
  const count = state.cart.reduce((s, i) => s + i.qty, 0);
  const sub = itemsSum(), disc = discount(), total = cartSum();
  $('#ckoCount').textContent = faNum(count);
  $('#ckoSub').textContent = moneyT(sub);
  $('#ckoTotal').textContent = moneyT(total);
  const discRow = $('#ckoDiscRow');
  if (discRow) {
    discRow.hidden = disc <= 0;
    if (disc > 0) {
      $('#ckoDiscCode').textContent = state.promo.code;
      $('#ckoDisc').textContent = '−' + moneyT(disc);
    }
  }
  if (state.promo) $('#promoInput').value = state.promo.code;
}

/* ═══ Open ═══ */
function openCko() {
  const bag = $('#bag');
  if (bag && bag.open) bag.close();
  if (!state.cart.length) { toast('سبد شما خالی است.', 'err'); return; }
  ckoStep = 0; ckoPaint(); ckoSummary(); ckoDone.hidden = true;
  $('#ckoForm').style.display = '';
  $('.cko__sum', cko).style.display = '';
  $('.cko__nav', cko).style.display = '';
  /* Re-arm the submit button.

     This dialog is reused for every checkout in the session, and the one state
     it used to inherit is a dead «ادامه». finishLocal() — the offline
     fallback, taken when the server could not be reached at all — deliberately
     leaves `ckoNext.disabled = true` and clears the loading class, because at
     that moment the form is hidden behind the confirmation screen and a live
     button would be meaningless.

     openCko() re-showed that form and reset the step, but never re-armed the
     button. So one order placed with no network in front of the customer
     disabled checkout for the rest of the session, with no visible cause: the
     sheet opened on step 0, validated, and «ادامه» simply did nothing. The
     only recovery was a full page reload.

     A dialog that can be re-opened must return the controls to their resting
     state, and the resting state of the submit button is "enabled" — the same
     reason ckoStep is reset two lines above.

     BUT `ckoSubmitting = false` here was a duplicate-order bug wearing that
     same fix's clothes. The sheet stays dismissible while a submit is in flight
     (Escape, #ckoX, wireDialog), so a customer could press «پرداخت», close the
     sheet, reopen it and press again — and reopening cleared the only guard
     against placing a second order. The first request is still awaiting the
     gateway at that point, so both were live.

     The button is still re-armed here, because that much is correct. The guard
     is not the button's: it belongs to the request, and it is only cleared by
     that request's own outcome (see reEnable/failWith). */
  if (!ckoSubmitting) ckoNext.classList.remove('loading');
  ckoNext.disabled = ckoSubmitting;
  ckoBack.disabled = ckoSubmitting;
  cko._opener = document.activeElement;
  if (!cko.open) cko.showModal();
  dlStop();
  requestAnimationFrame(() => $('#ckName').focus());
  /* Geo and session are both network reads. Fire them after the dialog is on
     screen so the sheet paints immediately instead of waiting on either. */
  ckoLoadGeo();
  ckoRefreshSession();
}
$('#ckoX') && $('#ckoX').addEventListener('click', () => cko.close());
wireDialog(cko);
ckoBack && ckoBack.addEventListener('click', () => { if (ckoStep > 0) { ckoStep--; ckoPaint(); } });

/* ═══ Promo ═══
   The resolved definition is what gets stored — code, percentage, cap and
   minimum together — so state.js can compute the same number the server will.

   Two bugs here. `state.promo = { code: PROMO.code, ... }` stored the HOUSE
   code, not the one that was typed: entering VIP20 and being offered a 20%
   discount produced a basket priced with VEL10's 10%. And `PROMO.pct` was read
   as though PROMO were a flat object, which it is not — it is a table with a
   lookup, so the success message read "undefined٪ تخفیف".

   `min` is checked here too, so a customer is told the threshold is unmet
   before they fill in an address, rather than at the last request. It is still
   enforced server-side; this is a courtesy, not a gate. */
$('#promoApply') && $('#promoApply').addEventListener('click', () => {
  const inp = $('#promoInput'), msg = $('#promoMsg');
  const v = PROMO.lookup(inp.value);
  const sub = itemsSum();
  if (v && sub >= v.min) {
    state.promo = v;
    LS.set(K.promo, v);
    inp.value = v.code;
    msg.className = 'promo-msg ok';
    const capped = v.cap > 0 && Math.round(sub * v.pct / 100) > v.cap;
    msg.textContent = capped
      ? `${v.code} اعمال شد — ${faNum(v.pct)}٪ تا سقف ${moneyT(v.cap)}.`
      : `${v.code} اعمال شد — ${faNum(v.pct)}٪ تخفیف روی جمع کل.`;
    haptic('add');
  } else if (v && sub < v.min) {
    msg.className = 'promo-msg err';
    msg.textContent = `این کد از ${moneyT(v.min)} به بالا معتبر است.`;
    haptic('warn');
  } else if (v && v.firstOnly) {
    /* Refused here rather than at the till.

       The server decides this one (it is the only party that knows whether this
       account has a paid order), and it still decides it — this branch exists
       so the sheet does not quote a discount that is about to be refused. The
       wording is the server's, so the customer reads the same sentence in both
       places. `hasPaidOrder` comes from the account's own order list; when it is
       unknown, the code is accepted and the server has the final word. */
    state.promo = null;
    LS.set(K.promo, null);
    msg.className = 'promo-msg err';
    msg.textContent = 'این کد تخفیف فقط برای اولین خرید است و قبلاً استفاده شده.';
    haptic('warn');
  } else {
    state.promo = null;
    LS.set(K.promo, null);
    msg.className = 'promo-msg err';
    msg.textContent = 'این کد معتبر نیست. کد خانه: ' + PROMO.code;
    haptic('warn');
  }
  ckoSummary();
});
$('#promoInput') && $('#promoInput').addEventListener('input', () => {
  const m = $('#promoMsg'); if (m) m.textContent = '';
});
$('#promoInput') && $('#promoInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') { e.preventDefault(); $('#promoApply').click(); }
});

/* ═══ Next / Submit ═══ */
/* Puts the error on the field the server named, so a refusal is actionable
   instead of a toast that disappears. Returns true if the error was shown. */
function ckoShowServerError(e) {
  const code = (e && e.code) || '';
  const hint = CKO_FIELD_HINT[code];
  if (hint) {
    const [id, text] = hint;
    const el = $('#' + id);
    if (el) {
      /* `.field` is not guaranteed: the promo input is not wrapped in one, it is
         a bare input beside a button with its own `#promoMsg`. Calling
         `.classList` on the result of closest() would throw inside the error
         handler, which is the worst place to throw — the customer would see a
         generic failure instead of the reason their order was refused. */
      el.closest('.field')?.classList.add('invalid');
      el.setAttribute('aria-invalid', 'true');
      /* Put the server's own words on the field, not only in a toast.

         A toast is a transient, screen-edge message that a screen reader may not
         announce at all, and it disappears. The server refused an order and this
         is the sentence explaining why — it belongs on the field that caused it,
         where the customer is looking and where it stays until they fix it. The
         static message under the input is replaced rather than shown, because
         the server's is the more specific of the two. */
      const msg = $('#' + id + 'Err') || (id === 'promoInput' ? $('#promoMsg') : null);
      if (id === 'promoInput') {
        /* Clear the code rather than leaving a refused one in the box to be
           resubmitted; and drop it from state so the summary stops quoting a
           discount the server has already rejected. */
        state.promo = null;
        LS.set(K.promo, null);
        ckoSummary();
      }
      if (msg) {
        if ('hidden' in msg) { msg.textContent = text; msg.hidden = false; }
        else { msg.textContent = text; msg.className = 'promo-msg err'; }
      }
      const want = STEP_FIELDS.findIndex(step => step.includes(id));
      if (want >= 0 && ckoStep !== want) { ckoStep = want; ckoPaint(); }
      el.focus();
      toast(text, 'err');
      return true;
    }
  }
  return false;
}

ckoNext && ckoNext.addEventListener('click', async () => {
  /* The very first statement, before validation. A guard placed after the
     checks it is meant to prevent is a guard that does not prevent: Enter
     pressed twice on the phone field, or a click that lands while the first is
     still inside an await, arrives here identically, and anything the guard is
     protecting has already been requested. */
  if (ckoSubmitting) return;

  /* Which step this click was aimed at, captured before any await.

     `ckoSubmitting` is not enough on its own here, because it is only armed on
     the submit branch — the branch *after* the step-0 `await` below. A second
     click arriving while the first is suspended inside `ckoRefreshSession()`
     therefore passes that guard (it is still false), re-runs step-0
     validation, and awaits as well. Both then resume; whichever got there
     first has already advanced ckoStep to 1, so the second one finds
     `ckoStep < 1` false at the advance and falls straight through into the
     submit path.

     The order is then placed from the ADDRESS step, with the address fields
     never validated and filled from whatever the browser still held in them —
     an empty or stale address, sent to the server, which validates it and
     refuses with a GEO_INVALID the customer cannot connect to the cause of.

     Re-checking the step after the await turns that into a no-op, which is the
     correct behaviour for a duplicate click: the first click already did the
     work, so the second has nothing left to do. */
  const stepAtEntry = ckoStep;

  const fields = STEP_FIELDS[ckoStep]; let firstBad = null;
  fields.forEach(id => { if (!ckCheck(id) && !firstBad) firstBad = id; });
  if (firstBad) {
    $('#' + firstBad).focus();
    toast('یک فیلد هنوز منتظر شماست.', 'err');
    return;
  }

  /* Both of these are checked before the customer is asked to pay, not after.
     api.php rejects an anonymous session (LOGIN_REQUIRED) and a phone that this
     account has not verified by OTP (PHONE_UNVERIFIED); discovering that on the
     final step means the form has been filled in for nothing. */
  if (ckoStep === 0 && api) {
    await ckoRefreshSession();

    /* Another click already advanced the step while this one was suspended. */
    if (ckoStep !== stepAtEntry) return;

    /* Unknown means unknown. The probe did not answer — a timeout, a dropped
       mobile connection, a 5xx — and none of those is evidence that the session
       ended. Closing the sheet and opening the sign-in dialog here threw a
       signed-in customer out of a half-completed checkout over a network blip,
       with everything they had typed still on screen and nothing to show for
       it. Say what happened, change nothing, and let them press the button
       again: the next attempt either succeeds or gives a real answer. */
    if (!ckoSession.known) {
      toast('ارتباط با سرور برقرار نشد — لطفاً دوباره تلاش کنید.', 'err');
      return;
    }

    if (!ckoSession.auth) {
      toast('برای ثبت سفارش ابتدا وارد حساب خود شوید.', 'err');
      cko.close(); dlStart();
      if (window.AE_AUTH) AE_AUTH.openProfile(true);
      else toast('از منوی حساب کاربری وارد شوید.', 'err');
      return;
    }
    const typed = asciiDigits($('#ckPhone').value);
    const known = asciiDigits(ckoSession.phone || '');
    if (!known) {
      toast('حساب شما شمارهٔ تأییدشده ندارد.', 'err');
      cko.close(); dlStart();
      if (window.AE_AUTH) AE_AUTH.openProfile(true);
      return;
    }
    if (typed !== known) {
      const el = $('#ckPhone');
      el.closest('.field').classList.add('invalid');
      el.setAttribute('aria-invalid', 'true');
      el.focus();
      toast('این شماره برای حساب شما تأیید نشده است — همان شمارهٔ حساب را وارد کنید.', 'err');
      return;
    }
  }

  if (ckoStep < 1) {
    ckoStep++; ckoPaint();
    /* Step 1 has no fields any more — it is the gateway handoff — so there is
       nothing to focus there. Move focus to the control that actually continues
       the flow instead of leaving it on a control that is now behind the step
       change; a keyboard customer would otherwise have to tab blind to find
       their way out. */
    const firstField = STEP_FIELDS[ckoStep][0];
    const next = firstField ? $('#' + firstField) : ckoNext;
    if (next) next.focus();
    return;
  }
  /* An in-flight guard, in the client, for the one request in this application
     that creates something.

     withLoad(ckoNext, 1000) was the only protection, and it worked against
     itself: withLoad arms a 1000ms timer that re-enables the button whether or
     not the request has come back. On a connection slower than one second —
     which is the normal case for the request that talks to a payment gateway —
     the button came back while the first request was still running, and a
     second click produced a second order. The server does have fingerprint
     idempotency, but it keys on the session and the browser sends both
     requests on the same session, so the duplicate was caught at the *claim*
     layer only if the first had not yet settled; a genuine double-click that
     straddled the settle boundary placed two orders.

     Nothing re-enables the button while a submit is live. It is re-enabled by
     exactly two things: the request finishing (success or a real failure), and
     the flow leaving this step. Nothing else, and no timer. */
  ckoSubmitting = true;
  ckoNext.classList.add('loading');
  ckoNext.disabled = true;
  ckoBack.disabled = true;
  const paidTotal = cartSum();
  const count = state.cart.reduce((s, i) => s + i.qty, 0);
  const itemsSnap = state.cart.map(i => ({
    id:i.id, name:CATALOG[i.id] ? CATALOG[i.id].name : null,
    size:i.size, color:i.color, qty:i.qty
  }));
  /* ─── گام آخر: پرداخت سمت سرور ───
     مبلغ هرگز از مرورگر باور نمی‌شود؛ api.php آن را از کاتالوگ سرور
     محاسبه می‌کند. نگاشت فیلدها به شکلی که سرور انتظار دارد در
     velora-bridge.js انجام می‌شود، نه اینجا. */
  const profile = LS.get(K.profile, {}) || {};
  const payload = {
    items: state.cart.map(i => ({ id:i.id, size:i.size, color:i.color, qty:i.qty })),
    promo: state.promo ? state.promo.code : null,
    contact: {
      name:  $('#ckName').value.trim(),
      phone: asciiDigits($('#ckPhone').value)
    },
    address: {
      receiver:  $('#ckName').value.trim(),
      province:  $('#ckProvince').value,
      city:      $('#ckCity').value,
      district:  $('#ckDistrict').value.trim(),
      line:      $('#ckAddr').value.trim(),
      plaque:    asciiDigits($('#ckPlaque').value),
      unit:      asciiDigits($('#ckUnit').value),
      postal_code: asciiDigits($('#ckZip').value)
    }
  };

  const reEnable = () => {
    ckoSubmitting = false;
    ckoNext.classList.remove('loading');
    ckoNext.disabled = false;
    ckoBack.disabled = false;
  };

  /* Only reached when the server genuinely could not be reached at all — see
     the note at the call site. A local-only order is not a real order, so it is
     labelled as one on the confirmation screen rather than dressed up as a
     placed order. */
  /* The order did NOT reach the server, and nothing about the basket changes.

     This function used to call commitOrder(), which clears the cart and writes a
     local order record — so the one path taken when the server was unreachable
     was the one that destroyed the customer's basket. It also announced
     «سفارش جدید … به صف تولید پیوست» to the atelier log, telling the operator a
     parcel was queued for an order that exists nowhere but this tab.

     Both are wrong in the same direction: an order that failed to be placed is
     exactly the order whose basket must be preserved. The customer retries, and
     the retry is the whole point.

     So this is now purely a message. The basket, the address draft and the
     promo all stay exactly as they were, and the customer is told, in words,
     that nothing was charged and nothing was lost. */
  const finishLocal = (ref, total) => {
    /* Terminal, but the flag is still cleared. Leaving ckoSubmitting latched
       because "the form is hidden now" is how a guard becomes a landmine the
       next time this dialog is reused. */
    ckoSubmitting = false;
    ckoNext.classList.remove('loading');
    ckoNext.disabled = false;
    ckoBack.disabled = false;
    ckoBack.focus();
    toast('ارتباط با سرور برقرار نشد — سفارشی ثبت نشد و سبد شما دست‌نخورده باقی ماند.', 'err', null, 7000);
  };

  /* The one thing this flow must never do is answer "سفارش ثبت شد" when the
     server refused the order.

     It used to. Every throw from paymentStart was caught, and anything that
     did not come back with a `ref` fell through to finishLocal() with a
     locally-generated reference — so GEO_INVALID, LOGIN_REQUIRED,
     RATE_LIMIT, INSUFFICIENT_STOCK and CHECKOUT_FAIL all ended on the same
     green "order placed" screen, the cart emptied, and the order existed
     nowhere but in this browser's localStorage. The customer had paid nothing
     and been told the parcel was queued.

     So the two conditions are separated. A response we received is an answer,
     even when the answer is no: it is shown, on the field that caused it, and
     the cart is left alone. Only an absent or silent server — no api bridge at all, or a
     transport failure before any reply — is reported as not-placed, and it says
     so plainly. */
  const failWith = (e) => {
    reEnable();
    if (ckoShowServerError(e)) return;
    /* Never surface a raw exception message.

       `e.message` here is whatever the failure produced: for a network fault
       that used to be the browser's own "Failed to fetch", in English, on a
       Persian page, describing an implementation detail rather than anything the
       customer can act on. Codes are the contract; this maps the ones that can
       reach this far to a sentence, and falls back to one that at least tells
       the truth — the order was not placed and the basket is intact. */
    const MESSAGES = {
      NETWORK:    'ارتباط با سرور برقرار نشد — سفارشی ثبت نشد و سبد شما حفظ شده است.',
      BAD_BODY:   'پاسخ سرور قابل خواندن نبود — سفارشی ثبت نشد و سبد شما حفظ شده است.',
      NO_PAY_URL: 'پاسخ ناقص از سرور — سفارشی ثبت نشد و سبد شما حفظ شده است.',
    };
    const code = (e && e.code) || '';
    toast(MESSAGES[code] || 'ثبت سفارش ممکن نشد — سبد شما حفظ شده است.', 'err');
  };

  (async () => {
    if (!api) {
      finishLocal('V-' + Date.now().toString(36).toUpperCase().slice(-6), paidTotal);
      return;
    }
    try {
      const r = await api.paymentStart(payload);
      if (r && r.url) {
        /* نشانهٔ تراکنش در-flight — برای تشخیص بازگشت مبهم از درگاه */
        LS.set(K.payPend, { ref:r.ref, at:Date.now() });
        api.paymentGo(r.url);
        return; /* صفحه به درگاه می‌رود؛ اینجا کاری نداریم */
      }
      /* ok:true with no pay_url is not a success the client can act on, and it
         is not a rejection either. Treat it as an unanswered request. */
      failWith(Object.assign(new Error('پاسخ ناقص از سرور'), { code: 'NO_PAY_URL' }));
      return;
    } catch (e) {
      /* Branch on `code`, not on the message. velora-bridge.js normalises every
         transport failure — including the ones that used to arrive as a raw
         TypeError — onto these codes precisely so this decision can be made here
         without string-matching a browser's own wording. */
      const code = (e && e.code) || '';
      if (code === 'NETWORK' || code === 'BAD_BODY') {
        finishLocal('', paidTotal);
        return;
      }
      failWith(e);
    }
  })();
});

/* ═══ بازگشت از درگاه: #/checkout?status=success|failed&ref=…&open=1 ═══
   payment_verify.php پس از تأیید زرین‌پال کاربر را همین‌جا می‌آورد.
   این هندلر دیالوگ نتیجه را باز می‌کند، سبد را خالی می‌کند و رکورد
   سفارش را در لیست محلی می‌گذارد تا با پنل «حساب من» هم‌خوان بماند.
   اعتبار: فقط وقتی نشانهٔ in-flight (K.payPend) تازه باشد نتیجه پذیرفته
   می‌شود — لینک bookmark شدهٔ قدیمی دیگر سفارش جعلی نمی‌سازد. */
let payReturnSeen = false;
const PAY_PEND_TTL = 30 * 60 * 1000;
function ckoHandlePaymentReturn() {
  if (!api || payReturnSeen) return false;
  const ret = api.paymentReturn();
  if (!ret) return false;
  payReturnSeen = true;
  const pend = LS.get(K.payPend, null);
  LS.del(K.payPend); /* یک‌بار مصرف — هرگز دوباره پردازش نشود */
  const pendFresh = !!(pend && pend.at && (Date.now() - Number(pend.at)) < PAY_PEND_TTL);
  const openDlg = (location.hash.match(/[?&]open=1/) !== null);
  if (!pendFresh) {
    /* بازگشت بدون درخواست in-flight → پیام هشدار، بدون تغییر سبد/سفارش */
    toast('بازگشت مبهم از درگاه — سفارشی ثبت نشد.', 'err');
    ckoClearHash();
    return true;
  }
  if (ret.status === 'success') {
    const ref = ret.ref || '';
    /* ویژگی ۷ — بازگشت موفق از درگاه: پیش‌نویس پاک می‌شود */
    commitOrder({ ref, total: ret.amount || 0, count: 0, items: [],
                  date: new Date().toISOString(), phone: '', paid: true });
    if (openDlg || ref) {
      $('#ckoRef').textContent = ref || '—';
      $('#ckoForm').style.display = 'none';
      $('.cko__sum', cko).style.display = 'none';
      $('.cko__nav', cko).style.display = 'none';
      ckoDone.hidden = false;
      if (!cko.open) cko.showModal();
      dlStop();
      requestAnimationFrame(() => $('#ckoDoneX').focus());
    }
    toast('پرداخت تأیید شد — سفارش ' + (ref || '') + ' ثبت شد.');
  } else if (ret.status === 'confirming') {
    /* The order exists, its stock is held, and the gateway did not answer.
       This is the one state that must NOT clear the bag and must NOT invite a
       retry: the customer very likely has been charged, and a second attempt
       would be a second order for one pair of shoes.

       So: the bag is left exactly as it was, and the message says what is
       actually true — we have the order, we are confirming the payment, and
       nothing is required from them. No countdown, no "try again", because
       both would invite the retry.

       Then it resolves on its own. api.php already leaves the order
       `pending` and the operator already has a log row to reconcile from, but
       a log row is not an answer the customer can see — so the page asks the
       order what it thinks every few seconds and reports the verdict. Almost
       every indeterminate settles this way, because the cause is nearly always
       a blip rather than a declined card. */
    toast('سفارش شما ثبت شد و پرداخت در حال تأیید است. اگر مبلغی از حساب شما کسر شد، تا چند دقیقه دیگر وضعیت نهایی ثبت می\u200cشود. نیازی به اقدام نیست.', '', null, 9000);
    /* Deliberately not completeCheckout(), and deliberately no error toast. */
    watchPaymentOutcome(ret.ref);
  } else {
    toast(ret.message || 'پرداخت تکمیل نشد. سبد شما حفظ شده است.', 'err');
  }
  /* پاک کردن query از آدرس تا refresh دوباره هندل را اجرا نکند */
  ckoClearHash();
  return true;
}
function ckoClearHash(){ try{ history.replaceState(null,'','#/'); }catch(_){} }

/* ═══ انتظار نتیجهٔ پرداختِ نامعلوم ═══════════════════════════════════════
   وقتی درگاه پاسخ نداد، سفارش «در انتظار تأیید» می‌ماند. اینجا خودِ سفارش
   را می‌پرسیم تا مشتری نتیجه را ببیند، بدون اینکه مجبور شود پیگیری کند.

   چرا محدود و با فاصلهٔ فزاینده:
   · شروع از ۴ ثانیه و دو برابر شدن — تا اگر درگاه واقعاً برگشته، مشتری زود
     خبردار شود؛ و اگر برنگشته، هر ده ثانیه یک درخواست بی‌نتیجه نفرستیم.
   · سقف ۸ تلاش ⇒ حدود ۴ دقیقه. بیشتر از این، خبر دیگری است: نه «در حال
     تأیید»، بلکه «با ما تماس بگیرید» — و این را صریح می‌گوییم به‌جای اینکه
     بی‌صدا متوقف شویم.
   · با هر پاسخ ناموفق شمارنده یک واحد کم می‌شود و بازه کمی بلندتر می‌شود،
     پس یک شبکهٔ ضعیف هم به همان سقف می‌رسد بدون اینکه ۸ بار پشت‌سرهم
     درخواست بدهد.
   · اگر صفحه پنهان شود، تا برگشتنش صبر می‌کنیم. polling در پس‌زمینهٔ یک
     تب باز اما نامرئی فقط مصرف است.
   · اگر مشتری خودش همین سفارش را در «حساب من» ببیند و ببندد، باز هم resolve
     می‌شود — این فقط مکمل است، نه جایگزینِ آن صفحه. */
const PAY_WATCH_STEPS = [4000, 8000, 10000, 12000, 15000, 20000, 25000, 30000];
let payWatchTimer = null;

function watchPaymentOutcome(orderId) {
  if (!orderId || !api || typeof api.paymentStatus !== 'function') return;
  let step = 0;

  const stop = () => { if (payWatchTimer) { clearTimeout(payWatchTimer); payWatchTimer = null; } };

  const settle = (paid, ref) => {
    stop();
    if (paid) {
      /* ویژگی ۷ — پرداخت موفق: پیش‌نویس پاک می‌شود */
      commitOrder({ ref: ref || orderId, total: 0, count: 0, items: [],
                    date: new Date().toISOString(), phone: '', paid: true });
      toast('پرداخت تأیید شد — سفارش ' + (ref || orderId) + ' ثبت شد.', '', null, 7000);
    } else {
      toast('پرداخت ناموفق بود. سبد شما حفظ شده است.', 'err');
    }
  };

  const tick = async () => {
    if (document.hidden) { payWatchTimer = setTimeout(tick, 4000); return; }
    try {
      const s = await api.paymentStatus(orderId);
      if (s.isPaid) { settle(true, s.paymentRef); return; }
      /* failed / cancelled are the only terminal non-paid states the order can
         hold. Anything else — unpaid, pending, unknown, or a status this build
         has never heard of — is still undecided, so it keeps waiting rather
         than being guessed at. */
      if (s.paymentStatus === 'failed' || s.paymentStatus === 'cancelled') { settle(false); return; }
    } catch (_) {
      /* یک تلاش ناموفق یعنی کمی زودتر؛ نه پایان کار. */
    }
    step++;
    if (step >= PAY_WATCH_STEPS.length) {
      stop();
      toast('تأیید پرداخت طول کشید. سفارش شما ثبت شده است — اگر تا یک ساعت دیگر وضعیت نهایی ثبت نشد، با ما تماس بگیرید و شمارهٔ سفارش را بگویید.', '', null, 12000);
      return;
    }
    payWatchTimer = setTimeout(tick, PAY_WATCH_STEPS[step]);
  };

  payWatchTimer = setTimeout(tick, PAY_WATCH_STEPS[0]);
  /* رفتن به تب دیگر و برگشتن، دوباره پرس‌وجو می‌کند — مشتری ممکن است همین
     لحظه برگشته باشد و نباید تا پایان بازه صبر کند. */
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && payWatchTimer) { clearTimeout(payWatchTimer); payWatchTimer = setTimeout(tick, 600); }
  }, { once: true });
}

/* اگر کاربر با URL بازگشت لند کرد (بعد از boot main.js) */
addEventListener('load', () => setTimeout(ckoHandlePaymentReturn, 300));
/* اگر hashchange در همان نشست رخ داد */
addEventListener('hashchange', () => { setTimeout(ckoHandlePaymentReturn, 60); });

$('#ckoDoneX') && $('#ckoDoneX').addEventListener('click', () => cko.close());

/* ═══ Draft-Persisting Forms (ویژگی ۷) — ae.draft.v1 ═══════════════════
   هر keystroke در فیلدهای مرحلهٔ ۰۱ (تماس + نشانی) چک‌اوت، debounce ۴۰۰ms روی
   localStorage می‌نشیند. بازگشت کاربر (refesh/بستن dialog/رفتن و برگشتن)
   پیش‌نویس را با یک toast دوشاخه برمی‌گرداند: «بازیابی» مقدارها را می‌گذارد،
   «دور ریختن» کلید را پاک می‌کند. سفارش موفق → پاک‌شدن قطعی.

   textarea نشانی شمارندهٔ کاراکتر زنده هم می‌گیرد؛ بالای ۱۰۰۰ کاراکتر
   هشدار رنگی (مطابق سقف سرور در includes/addresses.php). */
const DRAFT_KEY = K.draft;

/* ثبت قطعی سفارش — سه مسیر موفق (پذیرش محلی، بازگشت از درگاه، polling
   پرداخت) باید دقیقاً همین سه کار را بکنند: سفارش در دفتر بماند، checkout
   بسته شود، پیش‌نویس آدرس پاک شود. سه رونوشتِ دستی یعنی مسیر چهارمی که یکی
   را فراموش کند — و فراموش‌شدنِ پاک‌کردن، پیش‌نویسِ دیروز را فردا دوباره
   جلوی مشتری می‌گذارد. */
function commitOrder(rec) {
  recordOrder(rec);
  completeCheckout();
  LS.del(DRAFT_KEY);
}
const DRAFT_IDS = ['ckName', 'ckPhone', 'ckProvince', 'ckCity',
                   'ckDistrict', 'ckAddr', 'ckPlaque', 'ckUnit', 'ckZip'];

/* How long a draft address may sit in storage.

   A draft is the customer's name, phone number and street address in
   cleartext localStorage, and it was only ever removed by commitOrder() — that
   is, on a successful order. Abandon the checkout and it stayed: indefinitely,
   with no expiry, readable by anything running on this origin.

   Twenty-four hours is the window the feature actually needs. It covers the
   realistic case — a customer who filled the address in and came back to it
   later the same evening — and bounds the exposure of the one that isn't, a
   browser left on a shared machine for a week. */
const DRAFT_TTL_MS = 24 * 60 * 60 * 1000;

let draftTimer = null, draftOffered = false;

function draftSave() {
  clearTimeout(draftTimer);
  draftTimer = setTimeout(() => {
    const d = {};
    DRAFT_IDS.forEach(id => { const el = $('#' + id); if (el && el.value) d[id] = el.value; });
    /* Stored wrapped in a timestamp rather than bare, so the age is knowable at
       read time. A bare object cannot be aged: `DRAFT_IDS.some()` over a wrapper
       would see `savedAt` and treat the envelope as a field. */
    if (!Object.keys(d).length) return;
    LS.set(DRAFT_KEY, { savedAt: Date.now(), fields: d });
  }, 400);
}

function charCountPaint(ta) {
  let cc = $('#ckAddrCC');
  if (!cc) {
    cc = document.createElement('span');
    cc.id = 'ckAddrCC'; cc.className = 'charcount'; cc.setAttribute('aria-live', 'polite');
    ta.insertAdjacentElement('afterend', cc);
  }
  const n = [...ta.value].length; /* code-point نه UTF-16 */
  cc.textContent = faNum(n) + ' / ۱۰۰۰';
  cc.classList.toggle('is-warn', n > 1000);
}

function draftTryRestore() {
  if (draftOffered) return;
  const raw = LS.get(DRAFT_KEY, null);
  if (!raw || typeof raw !== 'object') return;

  /* Age it out. A draft is a name, a phone number and a street address; the
     TTL is what stops an abandoned checkout from leaving one readable in
     localStorage forever. An unrecognised shape (a bare object written by an
     older build) is discarded rather than guessed at — restoring it would mean
     assuming a field layout this version no longer uses. */
  const envelope = raw.fields && typeof raw.fields === 'object' ? raw : null;
  if (!envelope) { LS.del(DRAFT_KEY); return; }
  const age = Date.now() - (Number(envelope.savedAt) || 0);
  if (!age || age < 0 || age > DRAFT_TTL_MS) { LS.del(DRAFT_KEY); return; }

  const d = envelope.fields;
  if (!Object.keys(d).length) return;
  draftOffered = true;
  toast('پیش‌نویس نشانی از بازدید پیشین یافت شد.', 'ok', {
    label: 'بازیابی',
    fn: () => {
      DRAFT_IDS.forEach(id => {
        const el = $('#' + id);
        if (el && d[id] != null) {
          el.value = d[id];
          /* selectهای وابسته (شهر بعد از استان) باید cascade شوند:
             تغییر برنامه‌ای change را خودکار نمی‌زند؛ dispatch می‌کنیم
             تا هندلر موجودِ province→city اجرا شود. */
          el.dispatchEvent(new Event('input',  { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
      const addr = $('#ckAddr'); if (addr) charCountPaint(addr);
      toast('پیش‌نویس بازیابی شد.', 'ok');
    }
  }, 12000);
  /* اگر دکمه فشرده نشود، toast منقضی می‌شود و پیش‌نویس دست‌نخورده می‌ماند؛
     دفعهٔ بعد دوباره پیشنهاد می‌شود چون offer فقط با بازیابی واقعی done است. */
  setTimeout(() => { if ($('#' + 'ckName')?.value === '') draftOffered = false; }, 13000);
}

/* Enter must never submit this form.

   `#ckoForm` carries `name` attributes on every address field (name, phone,
   district, address, plaque, unit, postal-code) and `#ckoNext` is
   `type="button"`, so the form has no submit button and nothing listened for
   `submit`. Per HTML's implicit-submission rule that is exactly the combination
   that makes Enter in a text field submit the form element itself — as a GET to
   the current URL. So a customer who pressed Enter after typing their street
   address put their full delivery address into the query string, which lands in
   browser history, in the address bar, in the Referer of anything the page
   later loads, and in any proxy log between here and there.

   The default is prevented unconditionally and Enter is routed to the same
   control the button uses, so the key does what the customer sees it should do
   and nothing else. */
const ckoForm = $('#ckoForm');
if (ckoForm) {
  ckoForm.addEventListener('submit', e => {
    e.preventDefault();
    if (ckoNext && !ckoNext.disabled) ckoNext.click();
  });
}

cko.addEventListener('input', e => {
  if (!e.target.closest('#ckoForm')) return;
  if (e.target.matches('input,select,textarea')) {
    draftSave();
    if (e.target.id === 'ckAddr') charCountPaint(e.target);
  }
});
/* پیشنهاد در همان لحظهٔ باز شدن فرم — بعد از paint تا focus ندزدد.
   openCko یک function declaration است و hoist می‌شود؛ wrapper همین‌جا
   تعریف می‌شود و تنها export پایین، نسخهٔ بسته‌بندی‌شده را می‌برد. */
const _openCko = openCko;
function openCkoWithDraft() {
  _openCko();
  if (cko.open) requestAnimationFrame(draftTryRestore);
}

/* ═══ Exports ═══ */
window.AE_CKO = { openCko: openCkoWithDraft };
})();