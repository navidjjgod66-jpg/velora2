<?php
declare(strict_types=1);
/**
* VELORA · Maison de Chaussures
* Core Configuration · v9.5 Aetherion (Hardened & Optimized)
* PHP 8.4+ · MySQL 8 / MariaDB 10.6+ · strict_types
*/

if (defined('VELORA_CONFIG_LOADED')) {
    return;
}
define('VELORA_CONFIG_LOADED', true);

require_once __DIR__ . '/includes/env.php';

/**
 * Define a constant exactly once, and complain loudly if it already exists
 * with a *different* value.
 *
 * The project used two idioms for the same thing and mixed them freely:
 * `define('X', …)` in config.php and `defined('X') or define('X', …)` in
 * config.php, totp.php and includes/uploads.php. Both are silent about the
 * case that actually matters — a second define() of the same name with
 * another value. PHP keeps the first one and says nothing, so two modules can
 * disagree about MAX_LINE or SIZE_MAX and the second one's belief is simply
 * never true. That failure is invisible until it is load-bearing.
 *
 * This makes the disagreement observable: the first definition wins (so no
 * include order can change a value mid-request) and a conflicting one is
 * written to the error log with both values named.
 *
 * @param string $name  Constant name.
 * @param mixed  $value Value to define.
 */
function velora_define(string $name, mixed $value): void {
    if (defined($name)) {
        if (constant($name) !== $value) {
            error_log('[VELORA CONFIG] Constant ' . $name . ' is already defined as '
                . var_export(constant($name), true) . '; the second definition ('
                . var_export($value, true) . ') was ignored. Two modules disagree about this value.');
        }
        return;
    }
    define($name, $value);
}

/* ═══════════════════════════════════════════════════════════════════════════
APPLICATION CONSTANTS
═══════════════════════════════════════════════════════════════════════════ */
define('APP_ENV',   strtolower(env('VELORA_ENV', 'production')));
define('APP_DEBUG', APP_ENV !== 'production');
define('APP_URL',   rtrim(env('VELORA_APP_URL', 'https://velora.maison'), '/'));
$__app_url_parts = parse_url(APP_URL) ?: [];
define('APP_HOST',   $__app_url_parts['host'] ?? 'localhost');
define('APP_ORIGIN', ($__app_url_parts['scheme'] ?? 'https') . '://' . ($__app_url_parts['host'] ?? 'localhost') . (isset($__app_url_parts['port']) ? ':' . $__app_url_parts['port'] : ''));
unset($__app_url_parts);

define('ADMIN_UPLOAD_MAX_BYTES', 10 * 1024 * 1024);
define('ADMIN_UPLOAD_MAX_LABEL', '۱۰ مگابایت');

/* The ceiling the code enforces, and the ceiling the interpreter enforces, are
   two different numbers, and only one of them is ours.

   ADMIN_UPLOAD_MAX_BYTES is checked in api.php. But PHP itself refuses a
   larger body before any of our code runs, and its limit comes from php.ini.
   On a shared host where that file says upload_max_filesize = 2M, the admin
   panel advertises ۱۰ مگابایت, the operator picks a 6 MB photo, and PHP
   discards the request body without ever populating $_FILES — so the failure
   arrives as NO_FILE, which reads as "the upload did not happen" and points at
   the endpoint rather than at the limit.

   So the two are reconciled here, in the only place that can still influence
   it. ini_set() is honoured for these directives when they are PHP_INI_ALL,
   which is the case under mod_php; under PHP-FPM it is PHP_INI_PERDIR and the
   call is correctly a no-op, so it is wrapped rather than assumed.

   What this cannot do is raise a limit the host operator has deliberately set
   lower. That is why admin.php also reads the effective values back at runtime
   and shows them, rather than assuming this block succeeded: an operator who
   sees the real number can act on it, and one who sees the panel's number has
   no way to know which ceiling they actually hit. */
if (function_exists('ini_set')) {
    /* post_max_size must exceed upload_max_filesize, or the whole request body
       is truncated at the smaller of the two and no file ever arrives. */
    @ini_set('upload_max_filesize', (string) ADMIN_UPLOAD_MAX_BYTES);
    @ini_set('post_max_size', (string) (ADMIN_UPLOAD_MAX_BYTES + (1 << 20)));
}

velora_define('SIZE_MIN', 37);
velora_define('SIZE_MAX', 41);
/* The single list, used everywhere the band is needed.
   It used to be `range(SIZE_MIN, SIZE_MAX)` in three places, which is three
   chances to spell the bounds differently. Raising the range is now one edit,
   on these two lines, and the browser learns about it on the next page render
   (index.php publishes this to data.js, which builds its size sheet from it).

   That publication is what removed a real order-blocking bug: the client
   offered '36'…'46' from a hand-written array while api.php rejected anything
   outside SIZE_MIN…SIZE_MAX with INVALID_SIZE, failing the whole order at the
   last request after three completed checkout steps. */
velora_define('SIZE_BAND', range(SIZE_MIN, SIZE_MAX));

/* ─── Category vocabulary ───────────────────────────────────────────────────
   The slugs products.json stores, and the Persian names the maison shows for
   them. Two lists because they answer two different questions and conflating
   them is how the wrong one gets used.

   CATEGORY_SLUGS is the closed vocabulary: the admin's category <select> is
   built from it, api.php validates against it, and a product whose `cat` is not
   in it cannot be reached by any filter. It is a whitelist, and a whitelist that
   only exists in one place is a whitelist; it used to be a hand-written <option>
   list in admin.php, which is a second place nothing kept in step.

   CATEGORY_LABELS is the display name. This is the list that should not have
   needed to exist: without it, every surface that shows a product's category
   shows the slug, and the slugs are English machine identifiers. So the shop
   opened onto eleven cards labelled `heel`, `boot`, `sandal`, `flat`, `loafer`,
   `bridal` — on a Persian storefront, in the most prominent position on the
   card, directly above the price. The product page's breadcrumb did the same.

   That is not a translation gap, it is unfinished work: the Persian names were
   already written and already in use. data.js holds them, in FAM, keyed by the
   *family* token the filters use (`highheel`, `ballet`) rather than by the
   catalogue slug (`heel`, `flat`) — a second vocabulary layered on the first,
   and the display path happened to read the raw slug from neither.

   The maison's own register is used, matching the wording its product copy
   already uses: «باله تخت» rather than «تخت», «پاشنه بلند» rather than «پاشنه‌دار». */
velora_define('CATEGORY_SLUGS', [
    'heel', 'flat', 'boot', 'sandal', 'loafer', 'bridal',
]);
velora_define('CATEGORY_LABELS', [
    'heel'   => 'پاشنه بلند',
    'flat'   => 'باله تخت',
    'boot'   => 'بوت',
    'sandal' => 'صندل',
    'loafer' => 'لوفر',
    'bridal' => 'عروس',
]);

/** The Persian name for a category slug, or the slug itself if the vocabulary
     grew on disk — an unrecognised key should be visible as a key rather than
    silently folded into a category it is not in. */
function velora_category_label(string $slug): string {
    return CATEGORY_LABELS[$slug] ?? $slug;
}

date_default_timezone_set(env('VELORA_TZ', 'Asia/Tehran'));

/* ─── Filesystem anchors ────────────────────────────────────────────────────
   Every runtime-writable path used to be spelled from __DIR__ at its point of
   use, which silently encodes "which directory is this file in". Three of the
   five spellings were written as if the file still lived at the project root
   after the includes/ extraction — net.php's rate-limit reset, net.php's log
   writer, and zarinpal.php's breaker file all pointed at includes/storage/, a
   directory that does not exist. The failures were quiet by construction:
   every one sits behind an @ or a failed fopen on a best-effort path.

   One anchor, defined once, cannot be wrong twice. */
define('VELORA_ROOT', __DIR__);
define('STORAGE_DIR', VELORA_ROOT . '/storage');

/* Product-upload storage layout — the single home for these three facts.
   They used to live in includes/uploads.php, which made them the only
   application constants declared outside config.php (the static census in
   tests/smoke.php forbids exactly that). Values unchanged; they are defined
   here before includes/uploads.php is required further down, which reads all
   three at load time and inside its helpers.

   The layout is spelled as TWO halves, because the filesystem half and the
   URL half are anchored at different roots:

     · VELORA_UPLOAD_SUBDIR  is relative to STORAGE_DIR (the filesystem), so
       product_upload_dir() = STORAGE_DIR . '/' . VELORA_UPLOAD_SUBDIR.
     · VELORA_UPLOAD_URL_PATH is relative to APP_URL (the web root), so
       product_upload_url_base() = APP_URL . '/' . VELORA_UPLOAD_URL_PATH.

   One constant for both was wrong twice for the disk (it created a nested
   /storage/storage/uploads/products); see the header of uploads.php.

   VELORA_UPLOAD_EXT is the single allowed extension: lower-case, no leading
   dot, because it is both compared against and concatenated into a filename. */
velora_define('VELORA_UPLOAD_SUBDIR', 'uploads/products');
velora_define('VELORA_UPLOAD_URL_PATH', 'storage/uploads/products');
velora_define('VELORA_UPLOAD_EXT', 'webp');

$__req = env_require_all([
    'VELORA_DB_NAME',
    'VELORA_DB_USER',
    'VELORA_DB_PASS',
]);
define('DB_NAME',    $__req['VELORA_DB_NAME']);
define('DB_USER',    $__req['VELORA_DB_USER']);
define('DB_PASS',    $__req['VELORA_DB_PASS']);
unset($__req);

/* ─── The administrator's number ────────────────────────────────────────
   The panel has no username and no password any more: the operator types a
   phone number, the SMS gateway sends a one-time code to it, and possession
   of that number is the whole credential. That makes this value the entire
   access-control list — one row, in .env, where a change is a config edit
   rather than a deploy.

   There is deliberately no default, and that is a change of policy rather than
   a tidiness fix. This constant used to ship with a real Iranian mobile number
   as its fallback, which meant two separate failures:

   · the credential was in the source. Anyone who has read the repository knows
     which handset opens the panel — not a way in by itself (the OTP still has to
     arrive), but the exact thing to aim a SIM-swap or an SMS-interception
     attempt at, and the one account whose compromise is total;
   · and worse, an install that simply forgot to set VELORA_ADMIN_PHONE did not
     fail. It inherited a working credential from the codebase. The comment above
     this line used to call that a feature ("a panel somebody can still open"); it
     is the opposite — it is a default that defeats the point of the setting.

   So it fails closed, exactly like the database credentials four lines above: the
   name of the missing key is logged and named to the client, and no value is
   ever guessed. An operator who has not set it gets a clear 500 instead of a
   panel opened by a phone number that belongs to somebody else. */
$__adminPhone = env('VELORA_ADMIN_PHONE');
if ($__adminPhone === null || !preg_match('/^09\d{9}$/', $__adminPhone)) {
    error_log('[VELORA CONFIG] VELORA_ADMIN_PHONE is unset or not an 09xxxxxxxxx number — the admin panel is unreachable.');
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }
    exit(json_encode([
        'ok'      => false,
        'error'   => 'CONFIG_INCOMPLETE',
        'message' => 'تنظیم کامل نیست — در فایل .env مقدار VELORA_ADMIN_PHONE را وارد کنید (مثال: 09123456789)',
    ], JSON_UNESCAPED_UNICODE));
}
define('ADMIN_PHONE', $__adminPhone);
unset($__adminPhone);

define('DB_HOST',    env('VELORA_DB_HOST', '127.0.0.1'));
define('DB_PORT',    (int) env('VELORA_DB_PORT', '3306'));
define('DB_CHARSET', 'utf8mb4');
/* ─── How long an admin session may live ────────────────────────────────
   The panel does not time out while the operator is using it: is_admin() has
   no clock in it any more, and a session ends at the «خروج امن» button or
   when this many seconds pass with no request at all. This constant bounds
   the two things that have to be the same number for that to be true —
   how long the server keeps an idle session file (session.gc_maxlifetime in
   the hardening block below) and how long the cookie the admin login
   re-issues survives a browser restart.

   30 days. It used to be 7200 and it was the *only* thing is_admin()
   checked, so the operator was logged out two hours into a session they had
   never left — which is the whole reason this number moved. */
define('ADMIN_SESSION_TTL', (int) env('VELORA_ADMIN_SESSION_TTL', '2592000'));

/* How long the panel survives with no request at all.
   A separate constant from ADMIN_SESSION_TTL because the two answer different
   questions: that one is "how long may this login live", this one is "how long
   may an unattended screen stay an admin session". The second is the one that
   protects a laptop in a café, and it was previously unbounded — every admin
   session was valid until the server's garbage collector collected the file,
   which is why gc_maxlifetime had to be raised to the full 30 days for the whole
   install. Eight hours is an operator's day with room to spare. */
define('ADMIN_SESSION_IDLE_TTL', (int) env('VELORA_ADMIN_SESSION_IDLE_TTL', '28800'));
define('MELI_API',  env('VELORA_MELI_API', ''));
define('MELI_FROM', env('VELORA_MELI_FROM', '50002220022'));
define('OTP_TTL',   (int) env('VELORA_OTP_TTL', '120'));
define('OTP_DEBUG', env_bool('VELORA_OTP_DEBUG', false));
define('ZARINPAL_MERCHANT', trim((string) env('VELORA_ZARINPAL_MERCHANT', '')));
define('ZARINPAL_SANDBOX',  env_bool('VELORA_ZARINPAL_SANDBOX', false));

/* ZarinPal is the only gateway.
   There used to be two (ZarinPal + Zibal) behind ACTIVE_GATEWAY, which meant
   three things a single-gateway shop does not need: a switch to be
   misconfigured, a second code path through checkout and through the callback
   that had to be kept correct in parallel, and a merchant id in .env that
   nothing read. Zibal is gone — payment.php deleted, its functions and
   constants gone, its branch removed from the callback — so there is now one
   gateway, one path, one merchant id, and no switch that can be left pointing
   at a gateway the code no longer contains.

   The switch itself is retained as a constant so that a deployment with
   VELORA_ACTIVE_GATEWAY still set in .env reads correctly and says something
   useful if it names anything but zarinpal, rather than silently changing the
   behaviour of a shop that never asked for it. */
define('ACTIVE_GATEWAY', 'zarinpal');
define('INSTALL_TOKEN', env('VELORA_INSTALL_TOKEN', ''));
/* The per-line quantity ceiling, as one number the client and the server both
   read.

   api.php clamps every line to MAX_LINE (api.php, canonicalisation step). The
   cart used to allow MAX_PER_LINE = 20 in data.js while the server allowed 5,
   so a customer could build a cart of six of one design, watch the UI accept
   it, fill in the whole checkout, and be refused at the last request with
   INVALID_ITEM — with nothing on screen to say why.

   The mismatch was possible because the number lived twice, in PHP and in
   JavaScript, and nothing kept them together. There is no second constant
   here now: MAX_PER_LINE in data.js is a local-only fallback for when no
   server value has been published, and index.php emits this one to the
   browser, so the cap the cart enforces is the cap the server enforces.

   Raising it is one edit, in this line, and takes effect on both sides at
   once. */
define('MAX_LINE',              5);
define('SESSION_TTL',       7_200);
define('APPOINTMENT_HORIZON_DAYS', 90);

/* Shipping is a house promise, not a threshold: every order ships free, in
   every province, with no minimum. The charge used to be SHIP_FEE 680,000
   toman waived only above FREE_SHIP_MIN 50,000,000, which meant a real cart
   quietly gained 680,000 at the till and the cart sheet had to sell a
   progress bar to make the waiver feel earned. There is nothing left to
   earn, so both constants are gone and every quote is simply zero.

   velora_orders.shipping stays in the schema and is still written, as 0. It
   is a historical record of what was charged on the day: a 2024 order must
   keep saying 680,000 even though today's carts never produce that number. */
define('SHIPPING_FLAT',        0);

/* ═══════════════════════════════════════════════════════════════════════════
ADMIN TOTP PARAMETERS · RFC 6238
═══════════════════════════════════════════════════════════════════════════
   Moved here from includes/totp.php, where they were declared a second time
   behind `defined() or define()`. They were the only application constants in
   the codebase with two owners, and two owners is two chances to change one
   without the other — a TOTP window quietly widened in one file and not the
   other produces logins that pass on one code and fail on the next.

   WINDOW is the number of periods either side of now that a code is accepted
   for. 1 tolerates roughly 30 s of clock drift in each direction; anything
   larger meaningfully widens the brute-force window for a 6-digit code. */
define('VELORA_TOTP_PERIOD', 30);
define('VELORA_TOTP_DIGITS', 6);
define('VELORA_TOTP_WINDOW', 1);

/* ═══════════════════════════════════════════════════════════════════════════
ACTIONS THAT NEED NO DATABASE
═══════════════════════════════════════════════════════════════════════════
   The gate in api.php refuses every action when there is no connection, which
   is right for the twenty-odd actions that read or write rows and wrong for
   the ones that answer entirely from this codebase's own literals.

   geo_regions is the one that matters: its data is a literal in
   includes/geo.php, it is the source velora_geo_valid() validates an address
   against, and it is what fills the checkout's province picker. Refusing it
   meant a database outage emptied step two of checkout with an error that said
   "database" rather than anything about addresses.

   Declared here rather than in api.php so the list has one owner and can be
   read next to the database configuration it qualifies.

   me — the session probe js/auth.js fires twice before the page has finished
   booting. For a visitor who is not signed in it reads $_SESSION and answers
   {logged:false}, no table, and that is the case on every first visit; gating
   it turned a perfectly good page load into two red 500s in the console whose
   body said "database". The signed-in branch DOES read velora_users, so
   includes/api/auth.php answers DB_FAIL itself when the handle is null — the
   exemption carries that branch's anonymous case, not the query, and the guard
   there is what keeps the promise below true.

   Only actions that provably touch no table belong here. Adding to this list
   is a promise that the action will not quietly start depending on a query. */
define('VELORA_DB_INDEPENDENT_ACTIONS', ['geo_regions', 'me']);

/* ═══════════════════════════════════════════════════════════════════════════
POSTAL CODE LOOKUP (s.api.ir)
═══════════════════════════════════════════════════════════════════════════
   The token lives in .env and never leaves the server. It is not in app.js, not
   in index.php, not in any response body, and not in a log line. api.php's
   postal_lookup action reads the constants below and returns province, city,
   district, line and address — a parsed subset, never the raw upstream body,
   which would carry the Authorization header's sibling fields along with it.

   With no token, POSTAL_ENABLED is false and the address form simply skips the
   verification step. A customer can still save an address, the server still
   validates province/city and the postal checksum, and the only thing missing
   is the confirmation. That is deliberate: the lookup is a convenience that
   raises accuracy, not a gate. A lookup outage must not become an address book
   outage, and a form that cannot be submitted because a third party is slow is
   worse than a form that trusts its own customer. */
define('POSTAL_API_URL', (string) env('VELORA_POSTAL_API_URL', 'https://s.api.ir/api/sw1/PostalCodeInfo'));
define('POSTAL_API_TOKEN', trim((string) env('VELORA_POSTAL_API_TOKEN', '')));
define('POSTAL_ENABLED', POSTAL_API_TOKEN !== '');
/* Seven days. Long enough to absorb the repeat lookups a real storefront
   generates from one popular building, short enough that a correction at the
   post office is picked up inside a working week. */
define('POSTAL_CACHE_TTL', 7 * 24 * 3600);
/* Seconds. Eight is past the point where the customer has already decided the
   field is broken; a slower answer is not an answer. */
define('POSTAL_HTTP_TIMEOUT', 8);
define('POSTAL_HTTP_CONNECT_TIMEOUT', 5);

/* ═══════════════════════════════════════════════════════════════════════════
   PASSWORD VERIFICATION — removed with the login it served
   ═══════════════════════════════════════════════════════════════════════════
   Gone: is_password_hash(), verify_password(), ADMIN_HASH_CONFIGURED, and the
   VELORA_ADMIN_USER / VELORA_ADMIN_PASS pair in .env.

   The panel authenticates by an SMS one-time code sent to ADMIN_PHONE
   (includes/api/admin.php admin_otp_send / admin_otp_verify). There is no
   username to type and no password to store, so a hash nobody can present is
   not a fallback — it is a secret in a file with no reader, and a startup
   audit that congratulates an install for hashing it is auditing a credential
   the application no longer has.

   Nothing else called these: verify_password() had no caller at all, and the
   bcrypt-cost check in the startup audit below was the only other user.
*/

/* ═══════════════════════════════════════════════════════════════════════════
SESSION HARDENING
═══════════════════════════════════════════════════════════════════════════ */
/* Loaded here, ahead of the block below, because that block asks is_https().

   http.php and net.php are only function declarations — no top-level
   statements — and both are `require_once`, so pulling them forward defines
   them earlier and leaves the later requires no-ops. What changed is that
   `Secure` on the session cookie, HSTS and upgrade-insecure-requests now all
   come from ONE function that applies the trusted-proxy rule, instead of a
   second copy of the test written inline here.

   That copy believed X-Forwarded-Proto from any client. See is_https(). */
require_once __DIR__ . '/includes/http.php';        // is_https() — jresp · CSP · esc · error pages
require_once __DIR__ . '/includes/net.php';         // velora_peer_is_trusted_proxy() — client IP · rate limits · logging

if (session_status() === PHP_SESSION_NONE) {
    $https = is_https();
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_secure', $https ? '1' : '0');
    ini_set('session.cookie_samesite', 'Lax');
    /* The larger of the two windows, not the storefront's alone.

       session.gc_maxlifetime is one number for every session on the install —
       PHP cannot collect an admin session differently from a customer's — so
       a 7200 here would still have the server deleting an idle operator's
       session file out from under a login that no longer expires by time.
       SESSION_TTL remains the floor for the case where the admin window is
       configured shorter than the storefront's. */
    ini_set('session.gc_maxlifetime', (string) max(SESSION_TTL, ADMIN_SESSION_TTL));
    if (PHP_VERSION_ID < 80400) {
        ini_set('session.sid_length', '48');
        ini_set('session.sid_bits_per_character', '5');
    }
    session_name('VELORA_SID');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'domain' => '', 'secure' => $https, 'httponly' => true, 'samesite' => 'Lax']);
    session_start();

    /* There was a periodic re-key here: every 30 minutes, regenerate the id
       and delete the old session file. It looked like defence in depth and was
       in fact a data-loss bug.

       session_regenerate_id(true) deletes the old file. The storefront fires
       requests in parallel — the account view alone issues account_profile,
       my_orders and address_list at the same moment — so a burst arriving on
       the other side of the re-key does this: the first request regenerates
       and destroys the file the second request is still holding a cookie for,
       use_strict_mode mints that second request a fresh empty session, it sees
       no user_id, and answers 401. Worse, each response carries a different
       Set-Cookie, so the browser keeps whichever arrived last — an empty
       session. The customer is signed out permanently, while the user object in
       localStorage still claims they are signed in, and every later request
       keeps 401ing against that stale belief.

       The re-key that matters already happens where privilege changes:
       api.php regenerates immediately after a verified OTP, before
       user_id is written. That is the moment a fixated id could be promoted
       to an authenticated one, so it is the only moment worth paying for.
       OWASP's own guidance agrees — regenerate on authentication, not on a
       timer — and it is the version that cannot race with itself. */
}

/* ═══════════════════════════════════════════════════════════════════════════
DATABASE
═══════════════════════════════════════════════════════════════════════════ */
/* Both are always defined: $pdo on failure is null rather than unset, so a
   `global $pdo` in a page cannot fatal, and $velora_db_error is how the rest
   of the application asks *why* without re-trying the connection. */
$pdo = null;
$velora_db_error = null;
try {
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', DB_HOST, DB_PORT, DB_NAME, DB_CHARSET);
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_STRINGIFY_FETCHES  => false,
        PDO::ATTR_PERSISTENT         => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci, time_zone='+03:30', sql_mode='STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION'",
    ]);
    $pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED');
} catch (PDOException $e) {
    error_log('[VELORA DB] ' . $e->getMessage());
    /* Used to end the request here, with a JSON 500. That made a database
       outage blank the *storefront* — a page that reads products.json and
       never touches $pdo — so a dead database took the window down with it,
       and the customer saw an empty white page instead of the catalogue they
       came for. The connection is not the page.

       So the failure is recorded and the include continues. The three
       consumers each decide for themselves: the storefront prints one banner
       and renders, api.php refuses every action with the sentence below, and
       the startup audit writes the cause to the log. Nothing re-tries the
       connection, because nothing here can fix it. */
    $pdo = null;
    $velora_db_error = [
        'error'   => 'DB_FAIL',
        'message' => velora_db_fail_message($e),
    ];
}

/**
 * Why the database is not there, or null when it is.
 *
 * Returns the array rather than a boolean because the whole point of this is
 * the sentence — "check VELORA_DB_HOST and VELORA_DB_PORT" and "import db.sql"
 * are different afternoons, and a bare true cannot carry either.
 */
function velora_db_down(): ?array {
    global $velora_db_error;
    return is_array($velora_db_error) ? $velora_db_error : null;
}

/**
 * What to tell the customer, given a database failure.
 *
 * Covers both kinds: the connection that never opened (config.php's catch) and
 * the query that ran against it (api.php's catch, where a table that was never
 * imported is the common case and is reported as a bare 500 "خطای سرور" in
 * production).
 *
 * Deliberately does not include the exception's own message: a PDO exception
 * carries the username and sometimes the password, and this leaves the server.
 * It carries only a classification, and the classification is what decides the
 * fix — which is also the whole point: none of these four is "try again".
 */
function velora_db_fail_message(PDOException $e): string {
    $m   = $e->getMessage();
    $sql = (int) ($e->getCode() ?: 0);
    $driver = is_array($e->errorInfo ?? null) ? (int) ($e->errorInfo[1] ?? 0) : 0;

    /* ── Connection ── */
    if (stripos($m, 'getaddrinfo') !== false || stripos($m, 'Name or service not known') !== false
        || stripos($m, 'php_network_getaddresses') !== false) {
        return 'دامنهٔ سرور پایگاه داده پیدا نشد — مقدار VELORA_DB_HOST را بررسی کنید.';
    }
    if ($sql === 1045 || $driver === 1045 || stripos($m, 'Access denied') !== false) {
        return 'نام کاربر یا گذرواژهٔ پایگاه داده درست نیست — مقدار VELORA_DB_USER و VELORA_DB_PASS را بررسی کنید.';
    }
    if ($sql === 1049 || $driver === 1049 || stripos($m, 'Unknown database') !== false) {
        return 'پایگاه داده ساخته نشده یا نام آن با VELORA_DB_NAME نمی‌خواند.';
    }
    if ($sql === 1040 || $driver === 1040 || stripos($m, 'Too many connections') !== false) {
        return 'اتصال‌های سرور پر است؛ چند لحظه بعد دوباره تلاش کنید.';
    }
    /* Nothing is listening. This is the failure a local or freshly provisioned
       server actually produces, and its text is "No connection could be made
       because the target machine actively refused it" — which contains neither
       "Connection refused" nor any word the branches above look for, so it used
       to fall through to the neutral fallback and tell the operator nothing.
       2002 is also what MySQL reports when VELORA_DB_HOST says localhost but the
       socket path is wrong, which is a different fix from a bad password. */
    if ($sql === 2002 || $driver === 2002 || $sql === 2003 || $driver === 2003
        || stripos($m, 'actively refused') !== false
        || stripos($m, 'No connection could be made') !== false
        || stripos($m, 'Connection refused') !== false) {
        return 'به سرور پایگاه داده وصل نشد — مقدار VELORA_DB_HOST و VELORA_DB_PORT را بررسی کنید.';
    }

    /* ── Query ── */

    /* The one that matters: the schema was never imported, so every write and
       most reads fail with "table doesn't exist" and are reported in production
       as a generic 500. That is indistinguishable from a bug in the save, and
       it is exactly what a half-installed site looks like. The fix is a single
       import, so the message says that and names the table. */
    if ($sql === 42 || $driver === 42 || $driver === 1146 || stripos($m, "doesn't exist") !== false
        || stripos($m, 'Base table or view not found') !== false) {
        $table = preg_match('/(?:Table or view[^`]*\s|[`\x27])([A-Za-z0-9_]+)\.(?:[`\x27])?([A-Za-z0-9_]+)/',
                            $m, $tm) ? $tm[0] : '';
        $table = preg_replace('/^[`\x27]|[`\x27]$/', '', $table);
        $table = preg_replace('/^[A-Za-z0-9_]+\./', '', $table);
        return 'جدولی از جدول‌های سایت ساخته نشده'
             . ($table !== '' ? ' (جدول «' . $table . '»)' : '')
             . ' — فایل db.sql را در phpMyAdmin وارد کنید.';
    }
    if ($driver === 1062) return 'این رکورد قبلاً ثبت شده است.';
    if ($driver === 1451 || $driver === 1452) {
        return 'رکورد وابسته به آن وجود ندارد یا حذف شده است — صفحه را تازه کنید.';
    }
    if ($driver === 1213 || $driver === 1205) {
        return 'همزمان‌یک نوشته دیگر در حال ثبت است؛ چند لحظه بعد دوباره تلاش کنید.';
    }
    if (stripos($m, 'unable to open') !== false || stripos($m, 'server has gone away') !== false
        || stripos($m, 'Connection refused') !== false) {
        return 'سرور پایگاه داده پاسخ نمی‌دهد؛ چند لحظه بعد دوباره تلاش کنید.';
    }
    return 'خطا در ارتباط با پایگاه داده.';
}

/* ═══════════════════════════════════════════════════════════════════════════
PRODUCT CATALOGUE · products.json
═══════════════════════════════════════════════════════════════════════════ */
require_once __DIR__ . '/includes/catalog.php';

/* The response/HTTP helpers are loaded here, ahead of the startup audit below,
   because the audit calls is_https() — defined in http.php — while it runs at
   include time. They used to be required only further down, so every CLI entry
   point (and any request that reached the audit) fataled on
   "Call to undefined function is_https()" before the rest of config.php ever
   executed. require_once below makes the original position a no-op, so the
   load order stays exactly as the split-include comment describes: net.php
   still precedes the files that use it at load time, and each of them still
   precedes the API handlers api.php dispatches into. */
require_once __DIR__ . '/includes/http.php';        // jresp · CSP headers · esc · 404/410/503

/* Upload helpers load here, ahead of the startup audit below, for two reasons.

   The first is dependency order: product_upload_url_base() reads APP_URL and
   product_upload_dir() reads STORAGE_DIR, both defined above, and
   product_upload_rel_base() reads velora_local_path() from http.php.

   The second is that the audit should be able to ask product_upload_health() a
   question. An installation without ext-gd, without WebP, or without a
   writable uploads directory cannot accept a single product photograph, and
   finding that out from a 500 in the middle of an operator's catalogue edit is
   far too late to be the first sign. It is one line here and one line in the
   audit below.

   This is also the module whose functions were called from four different
   entry points and defined in none of them: product_upload_dir(),
   is_safe_upload_filename() and product_upload_url_base() everywhere, and
   product_image_url() — behind function_exists() at three call sites and
   unguarded at sitemap.php:74, which made /sitemap.xml fatal for any product
   with a gallery entry. One home for all of them is the fix. */
require_once __DIR__ . '/includes/uploads.php';     // upload dir/filename validation · image URL resolution

/* ═══════════════════════════════════════════════════════════════════════════
STARTUP CONFIG AUDIT
═══════════════════════════════════════════════════════════════════════════ */
/* The database argument is nullable: the audit runs on a server whose
   connection failed too, and it is precisely then that the gateway, catalogue
   and permission problems below are worth writing down. */
(static function (?PDO $pdo, ?array $dbError): void {
    if (APP_ENV !== 'production') return;

    $problems = [];

    if ($dbError !== null) {
        $problems[] = 'The database is unreachable: ' . $dbError['message']
                    . ' The storefront still renders from products.json, but sign-in, '
                    . 'addresses, orders and the admin panel cannot work until it connects.';
    }

    /* A leftover VELORA_ACTIVE_GATEWAY in .env is not an error any more —
       there is only one gateway — but it is worth saying out loud, because an
       operator who set it to "zibal" will otherwise wonder why their change
       had no effect. */
    $gwEnv = strtolower(trim((string) env('VELORA_ACTIVE_GATEWAY', '')));
    if ($gwEnv !== '' && $gwEnv !== ACTIVE_GATEWAY) {
        $problems[] = 'VELORA_ACTIVE_GATEWAY is "' . $gwEnv . '" but ZarinPal is the only gateway '
                    . 'this build supports; the setting is ignored. Remove it from .env.';
    }
    if (is_placeholder_merchant(ZARINPAL_MERCHANT)) {
        $problems[] = 'VELORA_ZARINPAL_MERCHANT is still a placeholder ("'
                    . substr(ZARINPAL_MERCHANT, 0, 24) . '"). EVERY checkout will fail with '
                    . 'PAYMENT_INIT_FAILED. This is a hard revenue outage, not a degraded mode.';
    }

    /* This one used to say "every one-time login code is being returned in the
       API response", and it was true: includes/otp.php gated the code that was
       HANDED BACK on OTP_DEBUG alone, while the path that MINTED one also
       checked loopback. With a gateway configured, a production build that
       left this flag on returned the code that had just been texted to the
       account owner to whoever asked for it. otp_debug_visible() now requires
       loopback on both paths, so the exposure is closed at the source rather
       than warned about here — which is the only order that fixes anything.

       The message is now a housekeeping note, not an incident: on a public
       server the flag now does nothing at all, and an operator who set it
       expecting dev codes should know that rather than keep it set forever. */
    if (OTP_DEBUG) {
        $problems[] = 'VELORA_OTP_DEBUG is set but this server is not loopback, so it does nothing '
                    . 'here and no code will ever be printed. It is harmless; clear it anyway so '
                    . 'it is unambiguous whether a build is a development build.';
    }

    if (INSTALL_TOKEN !== '') {
        $problems[] = 'VELORA_INSTALL_TOKEN is still set. Clear it (set to "") once installation is '
                    . 'finished — it is a secret sitting in the document root.';
    }

    /* The one credential the panel has. Everything else about the login —
       the SMS, the code, the session — fails safe if it is wrong; this is the
       only misconfiguration that locks an operator out of their own shop with
       a response that looks identical to a wrong number. */
    if (preg_match('/^09\d{9}$/', ADMIN_PHONE) !== 1) {
        $problems[] = 'VELORA_ADMIN_PHONE ("' . substr(ADMIN_PHONE, 0, 16)
                    . '") is not an 11-digit Iranian mobile number starting 09. The admin '
                    . 'panel cannot be signed in to: every code is sent to a number the '
                    . 'gateway will reject. Fix it in .env.';
    }

    if (!is_https()) {
        $problems[] = 'Request did not arrive over HTTPS. The session cookie is being issued without the '
                    . 'Secure flag and no HSTS is sent. Check the TLS terminator and APP_URL.';
    }

    /* Product photography. The catalogue can be perfectly healthy and the shop
       can sell every product in it while the admin panel is nonetheless unable
       to attach a single photograph — three independent ways that happens, all
       of them silent until an operator presses "upload". */
    $uploadProblem = product_upload_health();
    if ($uploadProblem !== null) {
        $problems[] = $uploadProblem;
    }

    $catalogFile = velora_catalog_path();
    if (!is_file($catalogFile)) {
        $problems[] = 'products.json not found at ' . $catalogFile
                    . '. The storefront will render an empty catalogue and every checkout will fail. '
                    . 'Restore the file from version control.';
    } elseif (!is_writable($catalogFile)) {
        $problems[] = 'products.json at ' . $catalogFile . ' is NOT writable by the web user. Every checkout, '
                    . 'order cancellation and admin save will fail with CATALOG_LOCK_FAIL. Fix the owner/'
                    . 'group and the mode (0640 for the file, 0750 for its directory) on the file, and on '
                    . dirname($catalogFile) . ' for the temp-file rename path.';
    } elseif (!is_writable(dirname($catalogFile))) {
        $problems[] = 'The directory holding products.json (' . dirname($catalogFile) . ') is not writable by '
                    . 'the web user, so the atomic temp-file + rename used by velora_catalog_commit() cannot '
                    . 'complete, and products.json.lock cannot be created. The data file itself is writable, '
                    . 'which is why the storefront still reads and checkout can still lock — but every write '
                    . 'will fail, and checkout degrades to session-only idempotency. Adjust permissions on '
                    . 'the directory.';
    }

    /* Skipped when the connection failed — $dbError above already says so, and
       asking a null handle for information_schema would fatal the include and
       take the storefront back down with it. */
    if ($pdo instanceof PDO) {
        try {
            $st = $pdo->prepare(
                'SELECT 1 FROM information_schema.TABLES
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1'
            );
            $st->execute(['velora_checkout_attempts']);
            if ($st->fetchColumn() === false) {
                $problems[] = 'Table velora_checkout_attempts does not exist. Checkout is still correct, but '
                            . 'duplicate-submit protection has fallen back to the session-only path, which cannot '
                            . 'see a second device. Apply the CREATE TABLE in db_schema.sql (SECTION 1).';
            }
            unset($st);
        } catch (Throwable $e) {
            $problems[] = 'Could not verify velora_checkout_attempts: ' . $e->getMessage()
                        . ' The storefront is unaffected; checkout falls back to session-only idempotency.';
        }
    }

    foreach ($problems as $p) {
        error_log('[VELORA CONFIG AUDIT] ' . $p);
    }
})($pdo, $velora_db_error);



/* ═══════════════════════════════════════════════════════════════════════════
SPLIT-INCLUDE HELPERS · one home per concern
═══════════════════════════════════════════════════════════════════════════
   Every file below guards on VELORA_CONFIG_LOADED, which is defined above, so
   they can rely on the constants and the PDO handle while still being loadable
   exactly once. Order matters only where a helper calls another helper at load
   time: net.php (logging/IP) precedes the files that use it, and each of them
   precedes the API handlers api.php dispatches into.

   http.php is not repeated in this list: it is already required above, ahead
   of the startup audit (which calls its is_https() at include time). The two
   lines used to be duplicated here and there; require_once made one of them a
   silent no-op, but two lines claiming to load the same helper invite someone
   to "fix" the wrong one. One line per file, one home per concern. */
require_once __DIR__ . '/includes/input.php';       // req_*() request accessors
require_once __DIR__ . '/includes/formatting.php';  // fa_num · fa_pad · digit/phone normalizers
require_once __DIR__ . '/includes/net.php';         // client IP · admin allow-list · log_action
require_once __DIR__ . '/includes/auth.php';        // session identity helpers
require_once __DIR__ . '/includes/csrf.php';        // token + origin checks
require_once __DIR__ . '/includes/orders.php';      // vouchers · order ids · secure tokens
require_once __DIR__ . '/includes/otp.php';         // OTP digest/HMAC helpers
require_once __DIR__ . '/includes/sms.php';         // MeliPayamak OTP sender
require_once __DIR__ . '/includes/totp.php';        // admin TOTP (encrypted secret)

/* Presentation helpers come last among the split-includes: they have no
   callers until a storefront document runs, and they lean on the catalogue
   helpers above (product_image_url()). index.php used to carry its own inline
   copies of velora_product_plate(), $VELORA_HEX and $product_img; this module
   was extracted from that file and then never required, so the "single home"
   existed on disk while the duplication stayed live. Requiring it here means
   every entry point gets the same presentation vocabulary, exactly like every
   other split-include. */
require_once __DIR__ . '/includes/presentation.php'; // colour table · monogram plate · image resolver · JSON escaper

/* uploads.php is NOT repeated here: it is already required above, ahead of the
   startup audit. One line per file, one home per concern. */